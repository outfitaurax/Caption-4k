#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")/.."

if ! command -v flutter >/dev/null 2>&1; then
  echo "Flutter SDK is required. Install Flutter before running this script."
  exit 1
fi

flutter create --platforms=android,ios --org com.caption4k --project-name caption_4k .
flutter pub get

# flutter_local_notifications 19.x requires core library desugaring on Android.
python3 - <<'PYCODE'
from pathlib import Path

kotlin = Path("android/app/build.gradle.kts")
groovy = Path("android/app/build.gradle")
if kotlin.exists():
    p = kotlin
    s = p.read_text()
    if "isCoreLibraryDesugaringEnabled = true" not in s:
        if "compileOptions {" in s:
            s = s.replace("compileOptions {", "compileOptions {\n        isCoreLibraryDesugaringEnabled = true", 1)
        else:
            marker = "android {"
            if marker not in s:
                raise SystemExit("Could not find android block in build.gradle.kts")
            s = s.replace(marker, marker + "\n    compileOptions {\n        isCoreLibraryDesugaringEnabled = true\n    }", 1)
    if 'coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.5")' not in s:
        if "dependencies {" not in s:
            s += "\ndependencies {\n    coreLibraryDesugaring(\"com.android.tools:desugar_jdk_libs:2.1.5\")\n}\n"
        else:
            s = s.replace("dependencies {", "dependencies {\n    coreLibraryDesugaring(\"com.android.tools:desugar_jdk_libs:2.1.5\")", 1)
    p.write_text(s)
elif groovy.exists():
    p = groovy
    s = p.read_text()
    if "coreLibraryDesugaringEnabled true" not in s:
        if "compileOptions {" in s:
            s = s.replace("compileOptions {", "compileOptions {\n        coreLibraryDesugaringEnabled true", 1)
        else:
            marker = "android {"
            if marker not in s:
                raise SystemExit("Could not find android block in build.gradle")
            s = s.replace(marker, marker + "\n    compileOptions {\n        coreLibraryDesugaringEnabled true\n    }", 1)
    if "coreLibraryDesugaring 'com.android.tools:desugar_jdk_libs:2.1.5'" not in s:
        if "dependencies {" not in s:
            s += "\ndependencies {\n    coreLibraryDesugaring 'com.android.tools:desugar_jdk_libs:2.1.5'\n}\n"
        else:
            s = s.replace("dependencies {", "dependencies {\n    coreLibraryDesugaring 'com.android.tools:desugar_jdk_libs:2.1.5'", 1)
else:
    raise SystemExit("Flutter did not generate android/app/build.gradle(.kts)")
p.write_text(s)
PYCODE

android_manifest="android/app/src/main/AndroidManifest.xml"
if [[ -f "$android_manifest" ]]; then
  python3 - "$android_manifest" <<'PYCODE'
from pathlib import Path
import sys
p = Path(sys.argv[1])
s = p.read_text()
permission = '    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />\n'
if permission.strip() not in s:
    s = s.replace('<application', permission + '<application', 1)
s = s.replace('android:label="caption_4k"', 'android:label="Caption 4K"')
p.write_text(s)
PYCODE
fi

ios_plist="ios/Runner/Info.plist"
if [[ -f "$ios_plist" ]]; then
  python3 - "$ios_plist" <<'PYCODE'
from pathlib import Path
import sys
p = Path(sys.argv[1])
s = p.read_text()
if 'NSPhotoLibraryUsageDescription' not in s:
    entry = '\t<key>NSPhotoLibraryUsageDescription</key>\n\t<string>Caption 4K needs photo access so you can select product images.</string>\n'
    s = s.replace('</dict>', entry + '</dict>', 1)
if '<key>CFBundleDisplayName</key>' not in s:
    entry = '\t<key>CFBundleDisplayName</key>\n\t<string>Caption 4K</string>\n'
    s = s.replace('</dict>', entry + '</dict>', 1)
p.write_text(s)
PYCODE
fi

dart run flutter_launcher_icons
dart run flutter_native_splash:create

echo "Android and iOS project scaffolding, launcher icons, and splash screens are prepared."
