# Caption 4K

Caption 4K is a local-first Flutter application for organizing product images, caption templates, operation history, and local analytics. The app is designed to work independently on-device; external AI generation and cloud services are intentionally not part of this build.

## Included app features

- Product creation and editing, with multiple local images, category, platform selection, and optional description.
- Local product image copies stored in the app documents directory.
- Per-image upload timestamps and automatic cleanup after 30 days from each image’s own saved timestamp. Android WorkManager schedules a daily background sweep, with startup/resume sweeps as fallbacks. Product text and operation history are retained independently until the three-month record-retention limit.
- Caption templates for OUTFIT, DECOR, PROMPT, and PRODUCTS, with platform-specific defaults, separate image/video template types, and user-editable templates.
- Local operation queue, operation details, manual caption entry/editing, retry/cancel controls, and searchable/filterable history. Deleting a product removes pending tasks but preserves completed/failed operation history.
- Local analytics calculated from saved products and processing jobs, using completion timestamps for completed/failed/cancelled period counts.
- Light, dark, and system appearance modes.
- Device-local notifications for completed or failed operations; tapping a notification opens that operation's detail page.
- Minimal black-C launcher icon and matching splash assets.

## Intentionally not included in this app-only build

- Tout agent, AI models, remote API, backend, cloud sync, or remote push notifications.
- Automatic AI caption generation. The app stores real captions when supplied by a future integration; it does not fabricate sample AI output.

## Prepare Android and iOS project folders

This source archive may not contain generated native platform folders. With Flutter installed, run from the `caption_4k` directory:

```bash
bash scripts/bootstrap_platforms.sh
```

The script generates Android/iOS runners, retrieves packages, adds the Android 13 notification permission and iOS photo-library usage description, then generates launcher icons and splash screens. iOS builds still require macOS and Xcode.

## Analyze, test, and build

Requires Flutter 3.47+ and Dart 3.13+. Run `flutter pub get` first to resolve the newly added `simple_icons` dependency and refresh `pubspec.lock`.

```bash
flutter analyze
flutter test
flutter build apk --release
```

For iOS (on macOS with Xcode):

```bash
flutter build ios --release
```

## Important verification note

The source changes in this archive must be validated with the Flutter SDK after package resolution. A successful archive creation is not proof that Android/iOS builds or device notifications work; run the commands above and test on a real device before release.
