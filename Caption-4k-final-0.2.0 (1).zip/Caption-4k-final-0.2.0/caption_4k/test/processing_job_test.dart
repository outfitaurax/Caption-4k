import 'package:flutter_test/flutter_test.dart';
import 'package:caption_4k/domain/analytics.dart';
import 'package:caption_4k/features/operations/data/processing_job.dart';
import 'package:caption_4k/features/operations/domain/caption_character_count.dart';

void main() {
  test('processing job serializes status and caption result', () {
    final job = ProcessingJob(
      id: 'p1_instagram', productId: 'p1', productName: 'Sample product',
      category: ContentCategory.outfit, platform: SocialPlatform.instagram,
      status: JobStatus.completed, createdAt: DateTime(2026, 10, 31),
      caption: 'Cream sneakers with mocha stripes.',
    );
    final restored = ProcessingJob.fromJson(job.toJson());
    expect(restored.status, JobStatus.completed);
    expect(restored.caption, 'Cream sneakers with mocha stripes.');
    expect(restored.platform, SocialPlatform.instagram);
  });

  test('copyWith changes status without losing job identity', () {
    final job = ProcessingJob(
      id: 'p1_x', productId: 'p1', productName: 'Sample product',
      category: ContentCategory.decor, platform: SocialPlatform.x,
      status: JobStatus.waitingForAi, createdAt: DateTime(2026, 10, 31),
    );
    final cancelled = job.copyWith(status: JobStatus.cancelled);
    expect(cancelled.id, job.id);
    expect(cancelled.status, JobStatus.cancelled);
  });
  test('processing job persists lifecycle timestamps and retry count', () {
    final started = DateTime(2026, 10, 31, 10, 0);
    final finished = DateTime(2026, 10, 31, 10, 2);
    final job = ProcessingJob(
      id: 'p2_pinterest', productId: 'p2', productName: 'Desk',
      category: ContentCategory.decor, platform: SocialPlatform.pinterest,
      status: JobStatus.completed, createdAt: DateTime(2026, 10, 31, 9),
      startedAt: started, completedAt: finished, caption: 'Minimal oak desk.',
      attemptCount: 1,
    );
    final restored = ProcessingJob.fromJson(job.toJson());
    expect(restored.startedAt, started);
    expect(restored.completedAt, finished);
    expect(restored.attemptCount, 1);
    expect(restored.processingDuration, const Duration(minutes: 2));
  });

  test('old saved jobs without lifecycle fields remain readable', () {
    final restored = ProcessingJob.fromJson({
      'id': 'old_x', 'productId': 'old', 'productName': 'Old product',
      'category': 'outfit', 'platform': 'x', 'status': 'waitingForAi',
      'createdAt': '2026-10-30T10:00:00.000',
    });
    expect(restored.startedAt, isNull);
    expect(restored.completedAt, isNull);
    expect(restored.attemptCount, 0);
  });

  test('status labels are human readable', () {
    expect(JobStatus.waitingForAi.label, 'Waiting for AI connection');
    expect(JobStatus.cancelled.label, 'Cancelled');
  });

  test('keeps a separate caption title through JSON round trip', () {
    final job = ProcessingJob(
      id: 'title-job', productId: 'p1', productName: 'Desk',
      category: ContentCategory.decor, platform: SocialPlatform.pinterest,
      status: JobStatus.completed, createdAt: DateTime(2026, 1, 1),
      captionTitle: 'Minimal Oak Desk', caption: 'A full description of the desk.',
    );
    final restored = ProcessingJob.fromJson(job.toJson());
    expect(restored.captionTitle, 'Minimal Oak Desk');
    expect(restored.caption, 'A full description of the desk.');
  });


  test('caption instructions remain separate and survive JSON round trip', () {
    final createdAt = DateTime(2026, 11, 21, 12);
    final job = ProcessingJob(
      id: 'caption-instructions', productId: 'p1', productName: 'Lamp',
      category: ContentCategory.decor, platform: SocialPlatform.instagram,
      status: JobStatus.completed, createdAt: createdAt,
      caption: 'Original caption.',
      captionInstructions: [
        CaptionInstruction(
          id: 'i1', mode: 'extend',
          instruction: 'Increase length without removing existing text.',
          createdAt: createdAt,
        ),
        CaptionInstruction(
          id: 'i2', mode: 'regenerate',
          instruction: 'Create a new premium version.',
          createdAt: createdAt.add(const Duration(minutes: 1)),
        ),
      ],
    );
    final restored = ProcessingJob.fromJson(job.toJson());
    expect(restored.caption, 'Original caption.');
    expect(restored.captionInstructions, hasLength(2));
    expect(restored.captionInstructions.first.mode, 'extend');
    expect(restored.captionInstructions.last.mode, 'regenerate');
  });

  test('old jobs default to an empty caption instruction history', () {
    final restored = ProcessingJob.fromJson({
      'id': 'old-instructions', 'productId': 'p1', 'productName': 'Old item',
      'category': 'outfit', 'platform': 'instagram', 'status': 'completed',
      'createdAt': '2025-01-01T00:00:00.000', 'caption': 'Existing caption',
    });
    expect(restored.captionInstructions, isEmpty);
  });

  test('loads older jobs without a separate caption title', () {
    final restored = ProcessingJob.fromJson({
      'id': 'old-job', 'productId': 'p1', 'productName': 'Old item',
      'category': 'outfit', 'platform': 'instagram', 'status': 'completed',
      'createdAt': '2025-01-01T00:00:00.000', 'caption': 'Old caption',
    });
    expect(restored.captionTitle, isNull);
    expect(restored.caption, 'Old caption');
  });
  test('caption version history survives JSON round trip', () {
    final at = DateTime(2026, 11, 21, 13);
    final job = ProcessingJob(
      id: 'versions', productId: 'p1', productName: 'Lamp',
      category: ContentCategory.products, platform: SocialPlatform.instagram,
      status: JobStatus.completed, createdAt: at, caption: 'Current version',
      captionVersions: [
        CaptionVersion(id: 'v1', number: 1, caption: 'Original version', createdAt: at),
        CaptionVersion(id: 'v2', number: 2, caption: 'Current version', createdAt: at.add(const Duration(minutes: 1)), changeType: 'edited'),
      ],
    );
    final restored = ProcessingJob.fromJson(job.toJson());
    expect(restored.captionVersions, hasLength(2));
    expect(restored.captionVersions.first.caption, 'Original version');
    expect(restored.captionVersions.last.number, 2);
  });

  test('legacy jobs without caption versions remain compatible', () {
    final restored = ProcessingJob.fromJson({
      'id': 'legacy', 'productId': 'p1', 'productName': 'Old',
      'category': 'outfit', 'platform': 'instagram', 'status': 'completed',
      'createdAt': '2026-01-01T00:00:00.000', 'caption': 'Old caption',
    });
    expect(restored.captionVersions, isEmpty);
  });

  test('caption character counter counts visible graphemes including emoji', () {
    expect(captionCharacterCount('A b!'), 4);
    expect(captionCharacterCount('👨‍👩‍👧‍👦'), 1);
    expect(captionCharacterCount('👍🏽'), 1);
    expect(captionCharacterCount('e\u0301'), 1);
  });

}

// Backward compatibility and lifecycle metadata coverage.

