import 'dart:convert';
import 'dart:io';

import 'package:caption_4k/core/storage/preferences.dart';
import 'package:caption_4k/domain/analytics.dart';
import 'package:caption_4k/features/upload/data/product.dart';
import 'package:caption_4k/features/upload/data/product_repository.dart';
import 'package:caption_4k/features/operations/data/processing_job.dart';
import 'package:caption_4k/features/operations/data/processing_job_repository.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  test('product survives JSON serialization', () {
    final original = Product(
      id: 'p1', name: 'Cream sneakers', description: 'Off-white leather sneakers',
      specialInstructions: 'Focus on university outfits and a natural tone', category: ContentCategory.outfit,
      imagePaths: const ['/local/a.jpg', '/local/b.jpg'],
      platforms: const [SocialPlatform.instagram, SocialPlatform.pinterest],
      createdAt: DateTime(2026, 10, 31),
    );
    final restored = Product.fromJson(original.toJson());
    expect(restored.name, original.name);
    expect(restored.description, original.description);
    expect(restored.specialInstructions, original.specialInstructions);
    expect(original.copyWith(specialInstructions: 'New direction').specialInstructions, 'New direction');
    expect(restored.imageAddedAt.keys.toSet(), original.imagePaths.toSet());
    expect(restored.imagePaths, original.imagePaths);
    expect(restored.platforms, original.platforms);
    expect(restored.category, original.category);
    expect(original.copyWith(name: 'Updated').name, 'Updated');
  });

  test('older saved products load with empty special instructions', () {
    final restored = Product.fromJson({
      'id': 'legacy', 'name': 'Legacy item', 'description': 'Old description',
      'category': 'outfit', 'imagePaths': <String>[], 'platforms': <String>['instagram'],
      'createdAt': DateTime(2026, 1, 1).toIso8601String(),
    });
    expect(restored.specialInstructions, isEmpty);
  });

  test('30-day retention removes old image files but keeps product text', () async {
    final directory = await Directory.systemTemp.createTemp('caption4k_retention_');
    addTearDown(() => directory.delete(recursive: true));
    final image = File('${directory.path}/old.jpg');
    await image.writeAsBytes([1, 2, 3]);

    SharedPreferences.setMockInitialValues({});
    final prefs = await SharedPreferences.getInstance();
    final container = ProviderContainer(overrides: [
      sharedPreferencesProvider.overrideWithValue(prefs),
    ]);
    addTearDown(container.dispose);
    final repository = container.read(productRepositoryProvider);
    await repository.save(Product(
      id: 'old-product', name: 'Saved product', description: 'Keep this description',
      category: ContentCategory.decor, imagePaths: [image.path],
      platforms: const [SocialPlatform.instagram], createdAt: DateTime(2026, 1, 1),
    ));

    final deleted = await repository.expireOldImages(
      retention: const Duration(days: 30), now: DateTime(2026, 2, 1),
    );
    final restored = (await repository.getAll()).single;
    expect(deleted, 1);
    expect(await image.exists(), isFalse);
    expect(restored.name, 'Saved product');
    expect(restored.description, 'Keep this description');
    expect(restored.imagePaths, isEmpty);
  });

  test('editing a product detaches removed images without deleting them early', () async {
    final directory = await Directory.systemTemp.createTemp('caption4k_detach_');
    addTearDown(() => directory.delete(recursive: true));
    final image = File('${directory.path}/removed.jpg');
    await image.writeAsBytes([1, 2, 3]);

    SharedPreferences.setMockInitialValues({});
    final prefs = await SharedPreferences.getInstance();
    final container = ProviderContainer(overrides: [
      sharedPreferencesProvider.overrideWithValue(prefs),
    ]);
    addTearDown(container.dispose);
    final repository = container.read(productRepositoryProvider);
    final addedAt = DateTime(2026, 1, 1);
    final original = Product(
      id: 'edited-product', name: 'Original', category: ContentCategory.outfit,
      imagePaths: [image.path], imageAddedAt: {image.path: addedAt},
      platforms: const [SocialPlatform.instagram], createdAt: addedAt,
    );
    await repository.save(original);
    await repository.save(original.copyWith(imagePaths: const [], imageAddedAt: const {}));

    expect(await image.exists(), isTrue);
    expect(prefs.getString('caption4k_orphan_images_v1'), contains(image.path));
    final deleted = await repository.expireOldImages(
      now: DateTime(2026, 2, 1),
    );
    expect(deleted, 1);
    expect(await image.exists(), isFalse);
  });

  test('detached image remains while its deleted product is processing', () async {
    final directory = await Directory.systemTemp.createTemp('caption4k_detach_active_');
    addTearDown(() => directory.delete(recursive: true));
    final image = File('${directory.path}/active.jpg');
    await image.writeAsBytes([1, 2, 3]);

    SharedPreferences.setMockInitialValues({});
    final prefs = await SharedPreferences.getInstance();
    final container = ProviderContainer(overrides: [
      sharedPreferencesProvider.overrideWithValue(prefs),
    ]);
    addTearDown(container.dispose);
    final products = container.read(productRepositoryProvider);
    final jobs = container.read(processingJobRepositoryProvider);
    final created = DateTime(2026, 1, 1);
    final product = Product(
      id: 'active-product', name: 'Active', category: ContentCategory.outfit,
      imagePaths: [image.path], imageAddedAt: {image.path: created},
      platforms: const [SocialPlatform.instagram], createdAt: created,
    );
    await products.save(product);
    await jobs.createForProduct(product);
    final jobId = (await jobs.getAll()).single.id;
    await jobs.start(jobId);
    await products.delete(product.id);
    await jobs.deleteForProduct(product.id);

    final deletedWhileActive = await products.expireOldImages(now: DateTime(2026, 2, 5));
    expect(deletedWhileActive, 0);
    expect(await image.exists(), isTrue);

    await jobs.updateStatus(jobId, JobStatus.cancelled);
    final deletedAfterCancel = await products.expireOldImages(now: DateTime(2026, 2, 6));
    expect(deletedAfterCancel, 1);
    expect(await image.exists(), isFalse);
  });

  test('images needed by a waiting operation are kept past 30 days until it is resolved', () async {
    final directory = await Directory.systemTemp.createTemp('caption4k_pending_');
    addTearDown(() => directory.delete(recursive: true));
    final image = File('${directory.path}/pending.jpg');
    await image.writeAsBytes([1, 2, 3]);

    SharedPreferences.setMockInitialValues({});
    final prefs = await SharedPreferences.getInstance();
    final container = ProviderContainer(overrides: [
      sharedPreferencesProvider.overrideWithValue(prefs),
    ]);
    addTearDown(container.dispose);
    final repository = container.read(productRepositoryProvider);
    final product = Product(
      id: 'pending-product', name: 'Pending product',
      category: ContentCategory.outfit, imagePaths: [image.path],
      platforms: const [SocialPlatform.instagram], createdAt: DateTime(2026, 1, 1),
    );
    await repository.save(product);
    final pendingJob = ProcessingJob(
      id: 'pending-product_instagram', productId: product.id,
      productName: product.name, category: product.category,
      platform: SocialPlatform.instagram, status: JobStatus.waitingForAi,
      createdAt: DateTime(2026, 1, 10),
    );
    await prefs.setString('caption4k_processing_jobs_v1', '[${jsonEncode(pendingJob.toJson())}]');

    var deleted = await repository.expireOldImages(
      retention: const Duration(days: 30), now: DateTime(2026, 2, 1),
    );
    expect(deleted, 0);
    expect(await image.exists(), isTrue);
    expect((await repository.getAll()).single.imagePaths, [image.path]);

    // Once the operation is cancelled, the normal 30-day rule applies again.
    final cancelled = pendingJob.copyWith(
      status: JobStatus.cancelled, completedAt: DateTime(2026, 2, 1),
    );
    await prefs.setString('caption4k_processing_jobs_v1', '[${jsonEncode(cancelled.toJson())}]');
    deleted = await repository.expireOldImages(
      retention: const Duration(days: 30), now: DateTime(2026, 2, 2),
    );
    expect(deleted, 1);
    expect(await image.exists(), isFalse);
  });

  test('three-month cleanup keeps a product that still has a waiting operation', () async {
    SharedPreferences.setMockInitialValues({});
    final prefs = await SharedPreferences.getInstance();
    final container = ProviderContainer(overrides: [
      sharedPreferencesProvider.overrideWithValue(prefs),
    ]);
    addTearDown(container.dispose);
    final repository = container.read(productRepositoryProvider);
    final product = Product(
      id: 'waiting-product', name: 'Waiting product',
      category: ContentCategory.decor, imagePaths: const [],
      platforms: const [SocialPlatform.website], createdAt: DateTime(2025, 10, 1),
    );
    await repository.save(product);
    final waiting = ProcessingJob(
      id: 'waiting-job', productId: product.id, productName: product.name,
      category: product.category, platform: SocialPlatform.website,
      status: JobStatus.waitingForAi, createdAt: DateTime(2026, 1, 20),
    );
    await prefs.setString('caption4k_processing_jobs_v1', '[${jsonEncode(waiting.toJson())}]');

    final removed = await repository.expireOldRecords(now: DateTime(2026, 2, 1));
    expect(removed, 0);
    expect((await repository.getAll()).single.id, 'waiting-product');
    expect(prefs.getString('caption4k_processing_jobs_v1'), contains('waiting-job'));
  });

  test('three-month cleanup removes old product text and history but keeps recent image until day 30', () async {
    final directory = await Directory.systemTemp.createTemp('caption4k_three_months_');
    addTearDown(() => directory.delete(recursive: true));
    final image = File('${directory.path}/recent-image.jpg');
    await image.writeAsBytes([1, 2, 3]);

    SharedPreferences.setMockInitialValues({});
    final prefs = await SharedPreferences.getInstance();
    final container = ProviderContainer(overrides: [
      sharedPreferencesProvider.overrideWithValue(prefs),
    ]);
    addTearDown(container.dispose);
    final repository = container.read(productRepositoryProvider);
    final created = DateTime(2025, 10, 1);
    final imageAdded = DateTime(2026, 1, 15);
    final product = Product(
      id: 'old-product', name: 'Old product text', description: 'Old description',
      category: ContentCategory.decor, imagePaths: [image.path],
      imageAddedAt: {image.path: imageAdded},
      platforms: const [SocialPlatform.instagram], createdAt: created,
    );
    await repository.save(product);
    final job = ProcessingJob(
      id: 'old-job', productId: product.id, productName: product.name,
      category: product.category, platform: SocialPlatform.instagram,
      status: JobStatus.completed, createdAt: created,
      completedAt: DateTime(2025, 10, 2), caption: 'Old caption',
    );
    await prefs.setString('caption4k_processing_jobs_v1', '[${jsonEncode(job.toJson())}]');

    final removed = await repository.expireOldRecords(now: DateTime(2026, 2, 1));
    expect(removed, 1);
    expect(await repository.getAll(), isEmpty);
    expect(prefs.getString('caption4k_processing_jobs_v1'), '[]');
    expect(await image.exists(), isTrue);

    await repository.expireOldImages(now: DateTime(2026, 2, 1));
    expect(await image.exists(), isTrue);
    await repository.expireOldImages(now: DateTime(2026, 2, 15, 1));
    expect(await image.exists(), isFalse);
  });


  test('three-month cleanup retains recent operations independently of old product', () async {
    SharedPreferences.setMockInitialValues({});
    final prefs = await SharedPreferences.getInstance();
    final container = ProviderContainer(overrides: [
      sharedPreferencesProvider.overrideWithValue(prefs),
    ]);
    addTearDown(container.dispose);
    final repository = container.read(productRepositoryProvider);
    final product = Product(
      id: 'old-product-recent-job', name: 'Old product',
      category: ContentCategory.products, imagePaths: const [],
      platforms: const [SocialPlatform.instagram],
      createdAt: DateTime(2025, 10, 1),
    );
    await repository.save(product);
    final recentJob = ProcessingJob(
      id: 'recent-job', productId: product.id, productName: product.name,
      category: product.category, platform: SocialPlatform.instagram,
      status: JobStatus.completed, createdAt: DateTime(2026, 1, 20),
      completedAt: DateTime(2026, 1, 20, 0, 1), caption: 'Recent caption',
    );
    await prefs.setString(
      'caption4k_processing_jobs_v1', '[${jsonEncode(recentJob.toJson())}]');

    await repository.expireOldRecords(now: DateTime(2026, 2, 1));

    expect(await repository.getAll(), isEmpty);
    final savedJobs = (jsonDecode(prefs.getString('caption4k_processing_jobs_v1')!) as List)
        .map((e) => ProcessingJob.fromJson(e as Map<String, dynamic>)).toList();
    expect(savedJobs, hasLength(1));
    expect(savedJobs.single.id, 'recent-job');
    expect(savedJobs.single.caption, 'Recent caption');
  });

  test('changed product content creates a fresh operation without duplicating unchanged saves', () async {
    SharedPreferences.setMockInitialValues({});
    final prefs = await SharedPreferences.getInstance();
    final container = ProviderContainer(overrides: [
      sharedPreferencesProvider.overrideWithValue(prefs),
    ]);
    addTearDown(container.dispose);
    final jobs = container.read(processingJobRepositoryProvider);
    final original = Product(
      id: 'revision-product', name: 'Desk', description: 'Oak desk',
      category: ContentCategory.decor, imagePaths: const ['/desk.jpg'],
      platforms: const [SocialPlatform.instagram], createdAt: DateTime(2026, 1, 1),
    );
    await jobs.createForProduct(original);
    final first = (await jobs.getAll()).single;
    await jobs.saveCaption(first.id, 'Original caption', notify: false);
    await jobs.createForProduct(original);
    expect((await jobs.getAll()).length, 1);

    final edited = original.copyWith(description: 'Oak desk with two drawers');
    await jobs.createForProduct(edited);
    final all = await jobs.getAll();
    expect(all.length, 2);
    expect(all.where((job) => job.status == JobStatus.completed).length, 1);
    expect(all.where((job) => job.status == JobStatus.waitingForAi).length, 1);
    expect(all.map((job) => job.id).toSet().length, 2);

    // Complete the revised operation, then remove and re-add the platform.
    // Re-adding it should create a fresh operation with the same content.
    final revisedWaiting = all.firstWhere((job) => job.status == JobStatus.waitingForAi);
    await jobs.saveCaption(revisedWaiting.id, 'Revised caption', notify: false);
    final withoutInstagram = edited.copyWith(platforms: const []);
    await jobs.createForProduct(withoutInstagram, previousProduct: edited);
    final restoredSelection = edited.copyWith(
      platforms: const [SocialPlatform.instagram],
    );
    await jobs.createForProduct(
      restoredSelection, previousProduct: withoutInstagram,
    );
    expect((await jobs.getAll()).length, 3);
  });

  test('repository saves and deletes products locally', () async {
    SharedPreferences.setMockInitialValues({});
    final prefs = await SharedPreferences.getInstance();
    final container = ProviderContainer(overrides: [
      sharedPreferencesProvider.overrideWithValue(prefs),
    ]);
    addTearDown(container.dispose);
    final repository = container.read(productRepositoryProvider);
    final product = Product(
      id: 'p2', name: 'Desk lamp', category: ContentCategory.decor,
      imagePaths: const [], platforms: const [SocialPlatform.website],
      createdAt: DateTime(2026, 10, 31),
    );
    await repository.save(product);
    expect((await repository.getAll()).single.name, 'Desk lamp');
    await repository.delete('p2');
    expect(await repository.getAll(), isEmpty);
  });

  test('a task waiting more than 30 days is cancelled with a reason, then its image can expire', () async {
    final directory = await Directory.systemTemp.createTemp('caption4k_stale_');
    addTearDown(() => directory.delete(recursive: true));
    final image = File('${directory.path}/stale.jpg');
    await image.writeAsBytes([1, 2, 3]);
    SharedPreferences.setMockInitialValues({});
    final prefs = await SharedPreferences.getInstance();
    final container = ProviderContainer(overrides: [
      sharedPreferencesProvider.overrideWithValue(prefs),
    ]);
    addTearDown(container.dispose);
    final repository = container.read(productRepositoryProvider);
    final product = Product(
      id: 'stale-product', name: 'Stale product',
      category: ContentCategory.outfit, imagePaths: [image.path],
      platforms: const [SocialPlatform.instagram], createdAt: DateTime(2026, 1, 1),
    );
    await repository.save(product);
    final stale = ProcessingJob(
      id: 'stale-job', productId: product.id, productName: product.name,
      category: product.category, platform: SocialPlatform.instagram,
      status: JobStatus.waitingForAi, createdAt: DateTime(2026, 1, 1),
    );
    await prefs.setString('caption4k_processing_jobs_v1', '[${jsonEncode(stale.toJson())}]');

    final deleted = await repository.expireOldImages(
      retention: const Duration(days: 30), now: DateTime(2026, 2, 5),
    );
    expect(deleted, 1);
    expect(await image.exists(), isFalse);
    final saved = (jsonDecode(prefs.getString('caption4k_processing_jobs_v1')!) as List)
        .map((e) => ProcessingJob.fromJson(e as Map<String, dynamic>))
        .single;
    expect(saved.status, JobStatus.cancelled);
    expect(saved.errorMessage, contains('automatically'));
    expect(saved.attempts, isEmpty);
    expect(saved.attemptCount, 0);
  });

  test('deleting a product detaches its image until its own 30 days pass', () async {
    final directory = await Directory.systemTemp.createTemp('caption4k_detach_');
    addTearDown(() => directory.delete(recursive: true));
    final image = File('${directory.path}/detached.jpg');
    await image.writeAsBytes([1, 2, 3]);
    SharedPreferences.setMockInitialValues({});
    final prefs = await SharedPreferences.getInstance();
    final container = ProviderContainer(overrides: [
      sharedPreferencesProvider.overrideWithValue(prefs),
    ]);
    addTearDown(container.dispose);
    final repository = container.read(productRepositoryProvider);
    final product = Product(
      id: 'detach-product', name: 'Detach product',
      category: ContentCategory.decor, imagePaths: [image.path],
      platforms: const [SocialPlatform.website], createdAt: DateTime(2026, 1, 1),
    );
    await repository.save(product);
    await repository.delete(product.id);

    expect(await repository.getAll(), isEmpty);
    expect(await image.exists(), isTrue);
    var deleted = await repository.expireOldImages(
      retention: const Duration(days: 30), now: DateTime(2026, 1, 15),
    );
    expect(deleted, 0);
    expect(await image.exists(), isTrue);
    deleted = await repository.expireOldImages(
      retention: const Duration(days: 30), now: DateTime(2026, 2, 5),
    );
    expect(deleted, 1);
    expect(await image.exists(), isFalse);
  });
}
