import 'package:caption_4k/app/app.dart';
import 'package:caption_4k/core/storage/preferences.dart';
import 'package:caption_4k/shell/app_bottom_nav.dart';
import 'package:material_ui/material_ui.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

Future<SharedPreferences> _pump(
  WidgetTester t,
  Map<String, Object> initial,
) async {
  SharedPreferences.setMockInitialValues(initial);
  final prefs = await SharedPreferences.getInstance();
  await t.pumpWidget(
    ProviderScope(
      overrides: [sharedPreferencesProvider.overrideWithValue(prefs)],
      child: const CaptionApp(),
    ),
  );
  await t.pumpAndSettle();
  return prefs;
}

void main() {
  testWidgets('bottom nav switches between three tabs', (t) async {
    await _pump(t, {});
    expect(find.text('No queued products'), findsOneWidget);

    await t.tap(find.descendant(
      of: find.byType(AppBottomNav),
      matching: find.text('AI'),
    ));
    await t.pumpAndSettle();
    expect(find.text('Your conversations'), findsOneWidget);
    expect(find.text('Start a new chat. Your conversations will be saved on this device.'), findsOneWidget);

    await t.tap(find.descendant(
      of: find.byType(AppBottomNav),
      matching: find.text('Upload'),
    ));
    await t.pump();
    expect(find.text('Add images'), findsOneWidget);
  });

  testWidgets('long-pressing a platform opens its template settings', (t) async {
    await _pump(t, {});
    await t.tap(find.descendant(
      of: find.byType(AppBottomNav),
      matching: find.text('Upload'),
    ));
    await t.pumpAndSettle();
    final websiteIcon = find.byIcon(Icons.language_rounded);
    await t.ensureVisible(websiteIcon);
    await t.pumpAndSettle();
    await t.longPress(websiteIcon);
    await t.pumpAndSettle();
    expect(find.text('AI Select'), findsOneWidget);
    expect(find.text('Manage templates'), findsOneWidget);
  });

  testWidgets('history screen opens from the processing queue', (t) async {
    await _pump(t, {});
    await t.tap(find.text('History'));
    await t.pumpAndSettle();
    expect(find.text('Operations history'), findsOneWidget);
    expect(find.text('No matching operations.'), findsOneWidget);
  });

  testWidgets('saved theme mode is restored on start', (t) async {
    await _pump(t, {'theme_mode': 'dark'});
    final app = t.widget<MaterialApp>(find.byType(MaterialApp));
    expect(app.themeMode, ThemeMode.dark);
  });

  testWidgets('choosing a theme persists it', (t) async {
    final prefs = await _pump(t, {});
    await t.tap(find.byIcon(Icons.settings_outlined));
    await t.pumpAndSettle();
    await t.tap(find.text('Dark Mode'));
    await t.pumpAndSettle();
    expect(prefs.getString('theme_mode'), 'dark');
    final app = t.widget<MaterialApp>(find.byType(MaterialApp));
    expect(app.themeMode, ThemeMode.dark);
  });
}
