import 'package:flutter_test/flutter_test.dart';
import 'package:caption_4k/domain/analytics.dart';
import 'package:caption_4k/features/generation/data/caption_generation_request.dart';
import 'package:caption_4k/features/upload/data/caption_template.dart';
import 'package:caption_4k/features/upload/data/product.dart';

void main() {
  test('builds a platform-specific request using the selected template', () {
    final product = Product(
      id: 'p1', name: 'Adidas Samba OG',
      specialInstructions: 'Focus on university use and keep the tone natural.',
      category: ContentCategory.outfit,
      imagePaths: ['/local/image.jpg'], platforms: [SocialPlatform.x],
      createdAt: DateTime(2026, 10, 31),
    );
    final template = CaptionTemplate(
      id: 'x-outfit', name: 'X Outfit', platform: SocialPlatform.x,
      category: ContentCategory.outfit,
      instructions: defaultTemplateInstructions(SocialPlatform.x),
    );
    final request = CaptionGenerationRequest.fromProduct(
      product: product, platform: SocialPlatform.x, template: template,
    );
    expect(request.prompt, contains('Adidas Samba OG'));
    expect(request.prompt, contains('Focus on university use and keep the tone natural.'));
    expect(request.prompt, contains('Follow these template instructions exactly'));
    expect(request.imagePaths, ['/local/image.jpg']);
    expect(request.platform, SocialPlatform.x);
    expect(request.contentType, CaptionContentType.image);
    expect(request.prompt, contains('Content type: IMAGE'));
  });

  test('rejects a template for a different platform', () {
    final product = Product(
      id: 'p1', name: 'Chair', category: ContentCategory.decor,
      imagePaths: [], platforms: [SocialPlatform.pinterest],
      createdAt: DateTime(2026, 10, 31),
    );
    const template = CaptionTemplate(
      id: 'x-decor', name: 'X Decor', platform: SocialPlatform.x,
      category: ContentCategory.decor, instructions: 'Short caption',
    );
    expect(() => CaptionGenerationRequest.fromProduct(
      product: product, platform: SocialPlatform.pinterest, template: template,
    ), throwsArgumentError);
  });
}
