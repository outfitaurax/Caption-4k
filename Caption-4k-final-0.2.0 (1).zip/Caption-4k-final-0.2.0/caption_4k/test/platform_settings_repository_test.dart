import 'package:caption_4k/core/storage/preferences.dart';
import 'package:caption_4k/domain/analytics.dart';
import 'package:caption_4k/features/upload/data/caption_template.dart';
import 'package:caption_4k/features/upload/data/platform_settings_repository.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  test('image and video defaults are stored independently', () async {
    SharedPreferences.setMockInitialValues({});
    final prefs = await SharedPreferences.getInstance();
    final container = ProviderContainer(overrides: [
      sharedPreferencesProvider.overrideWithValue(prefs),
    ]);
    addTearDown(container.dispose);
    final repository = container.read(platformSettingsRepositoryProvider);

    await repository.setDefaultTemplate(
      SocialPlatform.instagram,
      ContentCategory.outfit,
      'custom-image',
      contentType: CaptionContentType.image,
    );
    await repository.setDefaultTemplate(
      SocialPlatform.instagram,
      ContentCategory.outfit,
      'custom-video',
      contentType: CaptionContentType.video,
    );

    expect(
      repository.defaultTemplateId(SocialPlatform.instagram, ContentCategory.outfit),
      'custom-image',
    );
    expect(
      repository.defaultTemplateId(
        SocialPlatform.instagram,
        ContentCategory.outfit,
        contentType: CaptionContentType.video,
      ),
      'custom-video',
    );
  });

  test('legacy image default remains readable after the key migration', () async {
    SharedPreferences.setMockInitialValues({
      'caption4k_default_templates_v1':
          '{"instagram_outfit":"legacy-template"}',
    });
    final prefs = await SharedPreferences.getInstance();
    final container = ProviderContainer(overrides: [
      sharedPreferencesProvider.overrideWithValue(prefs),
    ]);
    addTearDown(container.dispose);
    final repository = container.read(platformSettingsRepositoryProvider);

    expect(
      repository.defaultTemplateId(SocialPlatform.instagram, ContentCategory.outfit),
      'legacy-template',
    );
    expect(
      repository.defaultTemplateId(
        SocialPlatform.instagram,
        ContentCategory.outfit,
        contentType: CaptionContentType.video,
      ),
      'default_instagram_outfit_video',
    );
  });
}
