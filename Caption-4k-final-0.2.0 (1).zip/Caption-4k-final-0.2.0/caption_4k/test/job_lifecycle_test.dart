import 'package:caption_4k/core/storage/preferences.dart';
import 'package:caption_4k/domain/analytics.dart';
import 'package:caption_4k/features/operations/data/processing_job.dart';
import 'package:caption_4k/features/operations/data/processing_job_repository.dart';
import 'package:caption_4k/features/upload/data/product.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

Future<ProviderContainer> _container() async {
  SharedPreferences.setMockInitialValues({});
  final prefs = await SharedPreferences.getInstance();
  final container = ProviderContainer(overrides: [
    sharedPreferencesProvider.overrideWithValue(prefs),
  ]);
  addTearDown(container.dispose);
  return container;
}

Product _product() => Product(
      id: 'p1',
      name: 'Hoodie',
      category: ContentCategory.outfit,
      imagePaths: const [],
      platforms: const [SocialPlatform.instagram],
      createdAt: DateTime(2026, 1, 1),
    );

void main() {
  test('all six lifecycle states exist with readable labels', () {
    expect(JobStatus.values.map((s) => s.label), [
      'Waiting for AI connection',
      'Queued',
      'Processing',
      'Completed',
      'Failed',
      'Cancelled',
    ]);
    expect(JobStatus.queued.isActive, isTrue);
    expect(JobStatus.completed.isActive, isFalse);
  });

  test('every run is kept in the attempt history', () async {
    final container = await _container();
    final repo = container.read(processingJobRepositoryProvider);
    await repo.createForProduct(_product());
    final id = (await repo.getAll()).single.id;

    await repo.start(id);
    await repo.saveFailure(id, 'boom');
    await repo.updateStatus(id, JobStatus.waitingForAi); // retry
    await repo.start(id);
    await repo.saveCaption(id, 'A caption', notify: false);
    await repo.saveCaption(id, 'An edited caption', notify: false);

    final job = (await repo.getAll()).single;
    expect(job.status, JobStatus.completed);
    expect(job.attemptCount, 2);
    expect(job.attempts.map((a) => (a.number, a.result)), [(1, 'failed'), (2, 'completed')]);
    expect(job.attempts.first.message, 'boom');
    expect(job.captionVersions, hasLength(2));
    expect(job.captionVersions.first.caption, 'A caption');
    expect(job.captionVersions.last.caption, 'An edited caption');
  });

  test('start moves a waiting job to processing and is idempotent', () async {
    final container = await _container();
    final repo = container.read(processingJobRepositoryProvider);
    await repo.createForProduct(_product());
    final id = (await repo.getAll()).single.id;

    await repo.start(id);
    final first = (await repo.getAll()).single;
    expect(first.status, JobStatus.processing);
    expect(first.attemptCount, 1);
    expect(first.attemptStartedAt, isNotNull);

    await repo.start(id);
    final second = (await repo.getAll()).single;
    expect(second.attemptCount, 1);
    expect(second.attemptStartedAt, first.attemptStartedAt);
  });

  test('queued jobs can start processing but completed jobs cannot restart', () async {
    final container = await _container();
    final repo = container.read(processingJobRepositoryProvider);
    await repo.createForProduct(_product());
    final id = (await repo.getAll()).single.id;
    await repo.updateStatus(id, JobStatus.queued);
    expect((await repo.getAll()).single.status, JobStatus.queued);
    await repo.start(id);
    expect((await repo.getAll()).single.status, JobStatus.processing);
    await repo.saveCaption(id, 'Done', notify: false);
    await repo.start(id);
    final completed = (await repo.getAll()).single;
    expect(completed.status, JobStatus.completed);
    expect(completed.attemptCount, 1);
    expect(completed.attempts.single.result, 'completed');
  });

  test('cancelling a waiting task does not count a processing attempt', () async {
    final container = await _container();
    final repo = container.read(processingJobRepositoryProvider);
    await repo.createForProduct(_product());
    final id = (await repo.getAll()).single.id;
    await repo.updateStatus(id, JobStatus.cancelled);
    final job = (await repo.getAll()).single;
    expect(job.status, JobStatus.cancelled);
    expect(job.attempts, isEmpty);
    expect(job.attemptCount, 0);
    expect(job.errorMessage, 'Cancelled by you.');
  });

  test('retry resets the 30-day waiting window without counting an attempt', () async {
    final container = await _container();
    final repo = container.read(processingJobRepositoryProvider);
    await repo.createForProduct(_product());
    final id = (await repo.getAll()).single.id;
    await repo.start(id);
    await repo.saveFailure(id, 'temporary');
    await repo.updateStatus(id, JobStatus.waitingForAi);

    final retried = (await repo.getAll()).single;
    expect(retried.status, JobStatus.waitingForAi);
    expect(retried.attemptCount, 1);
    expect(retried.attemptStartedAt, isNotNull);
  });

  test('old saved jobs without attempts still load', () {
    final job = ProcessingJob.fromJson({
      'id': 'j',
      'productId': 'p',
      'productName': 'Old',
      'category': 'outfit',
      'platform': 'instagram',
      'status': 'waitingForAi',
      'createdAt': '2026-01-01T00:00:00.000',
    });
    expect(job.attempts, isEmpty);
    expect(job.attemptStartedAt, isNull);
  });
}
