import 'package:caption_4k/features/upload/data/product_grouping.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('one-product mode keeps all images in a single group', () {
    final groups = groupForProducts(['a', 'b', 'c'], oneProduct: true);
    expect(groups, [['a', 'b', 'c']]);
  });

  test('separate mode makes one group per image, in order', () {
    final groups = groupForProducts(['a', 'b', 'c'], oneProduct: false);
    expect(groups, [['a'], ['b'], ['c']]);
  });

  test('no images means no products', () {
    expect(groupForProducts(<String>[], oneProduct: true), isEmpty);
    expect(groupForProducts(<String>[], oneProduct: false), isEmpty);
  });

  test('separate products are numbered; a single product keeps its name', () {
    expect(productNameFor('Hoodie', 0, 1), 'Hoodie');
    expect(productNameFor('Hoodie', 0, 3), 'Hoodie 1');
    expect(productNameFor('Hoodie', 2, 3), 'Hoodie 3');
  });
}
