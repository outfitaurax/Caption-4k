import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:caption_4k/core/storage/preferences.dart';
import 'package:caption_4k/domain/analytics.dart';
import 'package:caption_4k/features/upload/data/template_repository.dart';
import 'package:caption_4k/features/upload/data/caption_template.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  test('creates platform templates for every category', () async {
    SharedPreferences.setMockInitialValues({});
    final prefs = await SharedPreferences.getInstance();
    final container = ProviderContainer(overrides: [sharedPreferencesProvider.overrideWithValue(prefs)]);
    final templates = await container.read(templateRepositoryProvider).getAll();
    expect(templates.length, ContentCategory.values.length * SocialPlatform.values.length * CaptionContentType.values.length);
    final pinterest = templates.firstWhere((e) => e.platform == SocialPlatform.pinterest && e.category == ContentCategory.outfit);
    expect(pinterest.instructions, contains('exactly 800 characters'));
    expect(pinterest.instructions, contains('cherry red outfit, sporty streetwear'));
    expect(pinterest.instructions, contains('For OUTFIT'));
    final instagram = templates.firstWhere((e) => e.platform == SocialPlatform.instagram);
    expect(instagram.instructions, contains('exactly five relevant hashtags'));
    final x = templates.firstWhere((e) => e.platform == SocialPlatform.x);
    expect(x.instructions, contains('color, material, model'));
    final products = templates.firstWhere((e) => e.category == ContentCategory.products && e.contentType == CaptionContentType.image);
    expect(products.instructions, contains('For PRODUCTS'));
    final video = templates.firstWhere((e) => e.platform == SocialPlatform.instagram && e.category == ContentCategory.products && e.contentType == CaptionContentType.video);
    expect(video.instructions, contains('VIDEO CONTENT'));
    container.dispose();
  });

  test('custom templates can be saved and deleted without deleting defaults', () async {
    SharedPreferences.setMockInitialValues({});
    final prefs = await SharedPreferences.getInstance();
    final container = ProviderContainer(overrides: [sharedPreferencesProvider.overrideWithValue(prefs)]);
    final repo = container.read(templateRepositoryProvider);
    await repo.getAll();
    const custom = CaptionTemplate(id: 'custom1', name: 'Short X', platform: SocialPlatform.x, category: ContentCategory.decor, instructions: 'Describe the item briefly.');
    await repo.save(custom);
    expect((await repo.getAll()).any((e) => e.id == 'custom1'), isTrue);
    await repo.delete('custom1');
    final remaining = await repo.getAll();
    expect(remaining.any((e) => e.id == 'custom1'), isFalse);
    expect(remaining.any((e) => e.isDefault), isTrue);
    container.dispose();
  });

  test('TikTok has a default template for every content category', () {
    for (final category in ContentCategory.values) {
      final instructions = defaultTemplateInstructions(SocialPlatform.tiktok, category);
      expect(instructions, contains('TikTok'));
      expect(instructions, contains('hashtags'));
    }
  });
}
