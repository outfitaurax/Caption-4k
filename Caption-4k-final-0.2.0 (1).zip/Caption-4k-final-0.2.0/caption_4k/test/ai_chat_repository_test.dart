import 'package:caption_4k/core/storage/preferences.dart';
import 'package:caption_4k/features/ai/data/ai_chat_repository.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  test('keeps chats independent and persists their messages', () async {
    SharedPreferences.setMockInitialValues({});
    final prefs = await SharedPreferences.getInstance();
    final container = ProviderContainer(overrides: [sharedPreferencesProvider.overrideWithValue(prefs)]);
    final repo = container.read(aiChatRepositoryProvider);
    final first = await repo.create();
    final second = await repo.create();
    await repo.addUserMessage(first.id, 'First conversation');
    final chats = await repo.getAll();
    expect(chats.length, 2);
    expect(chats.firstWhere((e) => e.id == first.id).messages.single.text, 'First conversation');
    expect(chats.firstWhere((e) => e.id == second.id).messages, isEmpty);
    container.dispose();
  });

  test('background retention removes expired chats without relying on screen open', () async {
    SharedPreferences.setMockInitialValues({});
    final prefs = await SharedPreferences.getInstance();
    final repo = AiChatRepository(prefs);
    final old = DateTime(2025, 1, 1);
    final recent = DateTime(2026, 1, 1);
    await prefs.setString('caption4k_ai_chats_v1', '[{"id":"old","title":"Old","createdAt":"${old.toIso8601String()}","updatedAt":"${old.toIso8601String()}","messages":[]},{"id":"recent","title":"Recent","createdAt":"${recent.toIso8601String()}","updatedAt":"${recent.toIso8601String()}","messages":[]}]');

    expect(await repo.expireOldConversations(now: DateTime(2026, 3, 1)), 1);
    final remaining = await repo.getAll(now: DateTime(2026, 3, 1));
    expect(remaining.map((chat) => chat.id), ['recent']);
  });

  test('expires chats older than three months', () async {
    SharedPreferences.setMockInitialValues({});
    final prefs = await SharedPreferences.getInstance();
    final repo = AiChatRepository(prefs);
    final old = DateTime(2025, 1, 1);
    await prefs.setString('caption4k_ai_chats_v1', '[{"id":"old","title":"Old","createdAt":"${old.toIso8601String()}","updatedAt":"${old.toIso8601String()}","messages":[]}]');
    expect(await repo.getAll(now: DateTime(2025, 5, 1)), isEmpty);
  });
  test('backs up malformed chat data before a new chat overwrites the active key', () async {
    SharedPreferences.setMockInitialValues({
      'caption4k_ai_chats_v1': '{not valid json',
    });
    final prefs = await SharedPreferences.getInstance();
    final repo = AiChatRepository(prefs);

    await repo.create();

    expect(prefs.getString('caption4k_ai_chats_v1_corrupt_backup'), '{not valid json');
    expect(await repo.getAll(), hasLength(1));
  });

}
