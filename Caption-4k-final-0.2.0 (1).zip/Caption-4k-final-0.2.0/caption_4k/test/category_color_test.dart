import 'package:material_ui/material_ui.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:caption_4k/domain/analytics.dart';
import 'package:caption_4k/features/analytics/presentation/platform_style.dart';

void main() {
  test('category colours follow the approved Caption 4K palette', () {
    expect(categoryColor(ContentCategory.products), const Color(0xFFDC2626));
    expect(categoryColor(ContentCategory.prompt), const Color(0xFF2563EB));
    expect(categoryColor(ContentCategory.decor), const Color(0xFFF59E0B));
    expect(categoryColor(ContentCategory.outfit), const Color(0xFF7C3AED));
  });
}
