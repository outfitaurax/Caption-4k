import 'package:caption_4k/domain/analytics.dart';
import 'package:caption_4k/features/analytics/data/local_analytics_repository.dart';
import 'package:caption_4k/features/operations/data/processing_job.dart';
import 'package:caption_4k/features/upload/data/product.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  final now = DateTime(2026, 10, 31, 12);
  final product = Product(
    id: 'p1', name: 'Cream Samba', category: ContentCategory.outfit,
    imagePaths: const ['/one.jpg', '/two.jpg'],
    platforms: const [SocialPlatform.instagram, SocialPlatform.pinterest],
    createdAt: now.subtract(const Duration(hours: 2)),
  );

  ProcessingJob job(String id, SocialPlatform platform, JobStatus status) => ProcessingJob(
    id: id, productId: 'p1', productName: product.name,
    category: ContentCategory.outfit, platform: platform, status: status,
    createdAt: now.subtract(const Duration(hours: 1)),
    completedAt: status == JobStatus.waitingForAi ? null : now,
    caption: status == JobStatus.completed ? 'Cream Adidas Samba' : null,
  );

  test('counts each product once even when it has multiple images', () async {
    final repository = LocalAnalyticsRepository(
      products: [product],
      jobs: [job('j1', SocialPlatform.instagram, JobStatus.completed), job('j2', SocialPlatform.pinterest, JobStatus.completed)],
      clock: () => now,
    );
    final summary = await repository.load(AnalyticsPeriod.weekly);
    expect(summary.products, 1);
    expect(summary.captions, 2);
    expect(summary.captionsForCategory(ContentCategory.outfit), 2);
    expect(summary.captionsForPlatform(SocialPlatform.instagram), 1);
    expect(summary.recent.single.captions, 2);
    expect(summary.platformsOverTime.length, summary.series.length);
    expect(summary.heatmap.length, 7);
  });

  test('only completed jobs count as captions; failed and cancelled stay separate', () async {
    final repository = LocalAnalyticsRepository(
      products: [product],
      jobs: [
        job('j1', SocialPlatform.instagram, JobStatus.completed),
        job('j2', SocialPlatform.pinterest, JobStatus.failed),
        job('j3', SocialPlatform.x, JobStatus.cancelled),
        job('j4', SocialPlatform.facebook, JobStatus.waitingForAi),
      ],
      clock: () => now,
    );
    final summary = await repository.load(AnalyticsPeriod.daily);
    expect(summary.captions, 1);
    expect(summary.completed, 1);
    expect(summary.failed, 1);
    expect(summary.cancelled, 1);
  });

  test('calculates average processing duration from completed jobs', () async {
    final started = now.subtract(const Duration(minutes: 3));
    final completed = now.subtract(const Duration(minutes: 1));
    final timedJob = ProcessingJob(
      id: 'timed', productId: 'p1', productName: product.name,
      category: ContentCategory.outfit, platform: SocialPlatform.instagram,
      status: JobStatus.completed, createdAt: now.subtract(const Duration(minutes: 2)),
      startedAt: started, completedAt: completed, caption: 'Finished caption',
    );
    final summary = await LocalAnalyticsRepository(
      products: [product], jobs: [timedJob], clock: () => now,
    ).load(AnalyticsPeriod.weekly);
    expect(summary.avgProcessingSeconds, 120);
    expect(summary.stageSeconds['Total operation'], 120);
  });


  test('counts captions in the period they were completed, not created', () async {
    final oldCreatedJob = ProcessingJob(
      id: 'old-created-new-completed', productId: 'p1', productName: product.name,
      category: ContentCategory.outfit, platform: SocialPlatform.instagram,
      status: JobStatus.completed,
      createdAt: now.subtract(const Duration(days: 10)),
      completedAt: now.subtract(const Duration(hours: 1)),
      caption: 'Completed today',
    );
    final summary = await LocalAnalyticsRepository(
      products: [product], jobs: [oldCreatedJob], clock: () => now,
    ).load(AnalyticsPeriod.daily);
    expect(summary.captions, 1);
    expect(summary.series.fold<int>(0, (sum, point) => sum + point.captions), 1);
  });

  test('excludes products and jobs outside selected period', () async {
    final oldProduct = Product(
      id: 'old', name: 'Old item', category: ContentCategory.decor,
      imagePaths: const [], platforms: const [SocialPlatform.x],
      createdAt: now.subtract(const Duration(days: 45)),
    );
    final repository = LocalAnalyticsRepository(products: [product, oldProduct], jobs: [], clock: () => now);
    expect((await repository.load(AnalyticsPeriod.monthly)).products, 1);
  });
  test('PRODUCTS is included in analytics category totals', () async {
    final productsItem = Product(
      id: 'p-products', name: 'Desk organizer', category: ContentCategory.products,
      imagePaths: const ['/products.jpg'], platforms: const [SocialPlatform.instagram],
      createdAt: now.subtract(const Duration(hours: 1)),
    );
    final completedJob = ProcessingJob(
      id: 'j-products', productId: productsItem.id, productName: productsItem.name,
      category: ContentCategory.products, platform: SocialPlatform.instagram,
      status: JobStatus.completed, createdAt: now.subtract(const Duration(minutes: 30)),
      completedAt: now, caption: 'Minimal desk organizer',
    );
    final summary = await LocalAnalyticsRepository(
      products: [productsItem], jobs: [completedJob], clock: () => now,
    ).load(AnalyticsPeriod.monthly);
    expect(summary.products, 1);
    expect(summary.captionsForCategory(ContentCategory.products), 1);
  });

}
