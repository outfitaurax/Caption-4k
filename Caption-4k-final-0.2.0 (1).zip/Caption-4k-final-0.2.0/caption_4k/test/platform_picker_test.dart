import 'package:caption_4k/core/theme/app_colors.dart';
import 'package:caption_4k/domain/analytics.dart';
import 'package:caption_4k/features/upload/presentation/widgets/platform_picker.dart';
import 'package:material_ui/material_ui.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:simple_icons/simple_icons.dart';

void main() {
  testWidgets('shows recognizable brand marks for all social platforms', (tester) async {
    await tester.pumpWidget(
      MaterialApp(
        theme: ThemeData(extensions: const [AppColors.light]),
        home: Scaffold(
          body: PlatformPicker(
            selected: const {},
            onToggle: (_) {},
            onLongPress: (_) {},
          ),
        ),
      ),
    );

    expect(find.byIcon(SimpleIcons.instagram), findsOneWidget);
    expect(find.byIcon(SimpleIcons.pinterest), findsOneWidget);
    expect(find.byIcon(SimpleIcons.tiktok), findsOneWidget);
    expect(find.byIcon(SimpleIcons.facebook), findsOneWidget);
    expect(find.byIcon(SimpleIcons.x), findsOneWidget);
    expect(find.byIcon(Icons.language_rounded), findsOneWidget);
  });

  testWidgets('fits six platform tiles on a narrow phone width', (tester) async {
    tester.view.physicalSize = const Size(320, 800);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);

    await tester.pumpWidget(
      MaterialApp(
        theme: ThemeData(extensions: const [AppColors.light]),
        home: Scaffold(
          body: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: PlatformPicker(
              selected: const {},
              onToggle: (_) {},
              onLongPress: (_) {},
            ),
          ),
        ),
      ),
    );

    expect(tester.takeException(), isNull);
    for (final icon in [
      SimpleIcons.instagram,
      SimpleIcons.pinterest,
      SimpleIcons.tiktok,
      SimpleIcons.facebook,
      SimpleIcons.x,
      Icons.language_rounded,
    ]) {
      expect(find.byIcon(icon), findsOneWidget);
    }
  });

  testWidgets('keeps tap and long-press platform actions', (tester) async {
    SocialPlatform? tapped;
    SocialPlatform? longPressed;
    await tester.pumpWidget(
      MaterialApp(
        theme: ThemeData(extensions: const [AppColors.light]),
        home: Scaffold(
          body: PlatformPicker(
            selected: const {},
            onToggle: (value) => tapped = value,
            onLongPress: (value) => longPressed = value,
          ),
        ),
      ),
    );

    await tester.tap(find.byIcon(SimpleIcons.instagram));
    await tester.pump();
    expect(tapped, SocialPlatform.instagram);

    await tester.longPress(find.byIcon(SimpleIcons.pinterest));
    await tester.pump();
    expect(longPressed, SocialPlatform.pinterest);
  });
}
