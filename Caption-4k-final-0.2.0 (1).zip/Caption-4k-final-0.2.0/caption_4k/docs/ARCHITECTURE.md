# Caption 4K architecture (Stage 1)

lib/
  app/        MaterialApp, routes
  core/       theme tokens, storage helpers (no feature code)
  shared/     reusable widgets (AppCard, ScreenScaffold, EmptyState)
  shell/      bottom navigation shell (Home / AI / Upload)
  features/   one folder per feature: presentation, application, data
  domain/     (reserved) entities and repository interfaces
  data/       (reserved) local/ (Drift database, file storage), repositories/
  services/   (reserved) abstract AI/backend interfaces, implemented later

State management: Riverpod. Persistence now: shared_preferences (theme only).
Planned: Drift (SQLite) for products, images, jobs, templates, captions.
No AI provider, API keys, or mock data in this stage.

## Analytics (added after Stage 1 review)
- domain/analytics.dart: pure model (AnalyticsSummary, counts per PRODUCT, never per image).
- features/analytics/data: EmptyAnalyticsRepository (default, honest "no data"),
  SampleAnalyticsRepository (debug builds only, toggled in Settings > Developer).
- Replace the repository with a Drift-backed one in Stages 4-6; UI stays unchanged.
- Charts are plain CustomPainter/Flex widgets in shared/charts (no extra packages).

## Local product storage (MVP increment)
- `features/upload/data/product.dart`: product metadata model.
- `features/upload/data/product_repository.dart`: JSON metadata persisted in SharedPreferences.
- Original selected images are copied from the picker cache into the app documents directory under `product_images/`; saved records point to those durable app-owned paths.
- Upload currently saves one product with multiple images, a content category, and selected target platforms. Caption generation and template selection are not connected yet.
- This is an MVP local store, not the planned scalable database. Before storing a large catalog, migrate metadata to SQLite/Drift while retaining image files in app storage.

## Caption templates

Templates are stored locally in SharedPreferences through `TemplateRepository`.
The first run seeds default templates for X, Pinterest, and Instagram across OUTFIT,
DECOR, and PROMPT. Users can add, edit, and delete custom templates from Upload >
Manage templates. Default templates can be edited but cannot be deleted.
Pinterest instructions require a title under 100 characters, an exactly 800-character
description, and a single comma-separated SEO phrase line matching the supplied
reference style. Instagram uses the same structure plus exactly five relevant hashtags.
X uses a concise product description with useful identifying details and no filler.

## Caption generation boundary (MVP Step 3)

`features/generation/data/caption_generation_request.dart` creates a deterministic request from a saved product and a matching platform/category template. The prompt carries the product name, local image paths, platform, category, and the exact user-defined template instructions. It also tells the provider not to invent product attributes and to validate the requested character/hashtag constraints.

`features/generation/application/caption_generation_service.dart` defines the provider boundary. The current implementation intentionally throws `AiProviderNotConfigured`; it does not return demo captions. A real provider must be connected through a secure backend. Do not put API keys in the Flutter app.
