# Source review - 2 Nov 2026 (manual, NOT compiled)

Base: Caption_4K_with_special_instructions.zip. No Flutter/Dart was available,
so nothing below was analyzed, tested or built. Run `flutter pub get`,
`flutter analyze`, `flutter test` before trusting this package.

## Fixed
1. product_repository.dart - compile error: `failedImageDeletes` was used in
   expireOldRecords() but only defined in expireOldImages().
2. product_repository.dart - compile error: nullable `orphanRaw` passed to
   setString(). Now guarded.
3. Retention vs. waiting operations: images and product records of products
   that still have a "Waiting for AI connection" operation are no longer
   deleted by the 30-day / 3-month sweeps. Protection ends when the operation
   is completed, failed, cancelled or deleted. (The old test asserted the
   opposite and was rewritten.)
4. Analytics: removed the "Avg. time" tile (no reliable timing exists yet;
   manual captions have no start time). Replaced with "Failed / Cancelled".
5. app.dart: reload SharedPreferences on resume so the WorkManager isolate's
   cleanup is not overwritten by stale cache; also refresh jobs list.
6. Status shown as readable labels ("Waiting for AI connection") instead of
   raw enum names.
7. upload_screen.dart: stale imageAddedAt entries for removed images are dropped.

## Known gaps (not changed)
- Upload screen does not match the reference design (Material chips and
  outlined fields; no large upload area, square category cards, platform icon
  row, long-press settings, one-product/separate-products mode, chat input).
- Job states Queued and Processing do not exist yet (only waitingForAi,
  completed, failed, cancelled).
- Attempt history is a counter only.
- pubspec requires Flutter >=3.47 / Dart >=3.13: verify with `flutter pub get`.
- Product deletion removes its images immediately.

## Update: Upload screen rebuilt to the HTML design reference (not compiled)
- Large dashed image area; reorderable thumbnails with remove buttons.
- "One product" / "Separate products" selector (shown when 2+ images are added).
  Separate mode saves one product per image, numbered from the entered name.
- Three square category cards (OUTFIT / DECOR / PROMPT).
- Platform row incl. TikTok: tap selects, long press opens template settings
  (template library, default template, AI Select choice, manage templates).
  AI Select only stores the choice; no AI runs.
- Special Instructions field kept; compact AI chat bar is disabled until AI exists.
- Platform icons are interim vector approximations, not official brand assets.
- New: product_grouping.dart, platform_settings_repository.dart,
  platform_settings_sheet.dart, widgets/{image_strip,category_picker,platform_picker}.dart.
- New tests: test/product_grouping_test.dart; app_test.dart long-press test.

## Still pending (agreed order)
1. Waiting-for-AI time limit (30 days, auto-cancel with reason) and product
   deletion that detaches images but keeps them until their own 30 days.
2. Run flutter analyze / flutter test and fix what appears.
3. Job states Queued + Processing and a real attempt history.
4. Final review + APK on a real Android phone.

## Update 3: retention + job lifecycle (not compiled)
- Operations waiting for AI (or Queued) for more than 30 days are cancelled
  automatically with the reason stored on the job and in its attempt history
  (lib/features/operations/data/waiting_job_expiry.dart; runs at the start of
  both retention sweeps: startup, resume, WorkManager).
- Deleting a product no longer deletes its photos: they are tracked in the
  orphan index and removed by the image sweep when their own 30 days end.
- JobStatus now has all six states. Queued and Processing are defined and
  protected by cleanup, but nothing sets them until the backend/Tout exists.
- Attempt history: every finished run (completed / failed / cancelled) is kept
  with number, start, end, result and message. Old saved jobs load unchanged.
- Tests added: job_lifecycle_test.dart; product_test.dart (stale waiting task,
  detached image); updated waiting-operation test.

## How to get a verified APK
Copy github_workflow/android.yml to <repo>/.github/workflows/android.yml and push.
GitHub Actions runs bootstrap, flutter analyze, flutter test, builds the release
APK and uploads it as artifact "caption4k-apk" plus the reports. A red run means
analyze/tests failed and the APK is NOT approved.
