# Caption 4K final handoff notes

- The supplied Stage 1 visual foundation is retained: theme tokens, cards, screen scaffold, segmented controls, shell, and bottom navigation are unchanged.
- The launch screen artwork is a large black `C` with only `Caption` below it on white. No other text is included.
- The launcher icon is a black `C` on a white background.
- TikTok is included as a selectable platform and has a dedicated default caption instruction.
- The app remains local-first. Product data, settings, templates, and operation history are stored on-device. No Tout, backend, remote API, or hosted model integration is included in this package.
- Flutter analysis, automated tests, Android/iOS platform generation, and APK build still need to be run in a Flutter SDK environment before this package can be called verified.


## Retention policy (updated)

- Image files are removed after 30 days measured from each image's own `imageAddedAt` timestamp.
- Product text and operation history are removed after three calendar months measured from each product/operation creation timestamp.
- When a product record expires before one of its images reaches 30 days, the image timestamp is moved to a small local orphan-image index so the image is still deleted on its own 30-day schedule.
- Android WorkManager requests a periodic cleanup about once per day. Android may defer the exact execution time based on battery and system conditions. Startup/resume cleanup is also retained as a fallback.

## Validation status

The source changes and regression tests are included, but `flutter pub get`, `flutter analyze`, `flutter test`, and APK build must still be run in a Flutter SDK environment. The project now requires Flutter 3.47+ / Dart 3.13+ because of the Workmanager dependency.
