# Local operations and results

Processing jobs are stored locally in SharedPreferences. Each product/platform pair has its own job.

## Lifecycle metadata

- `createdAt`: when the product was added and its platform job was created.
- `startedAt`: set when a future worker explicitly starts the job.
- `completedAt`: set when a caption is saved or a failure is recorded.
- `attemptCount`: number of retries after the initial attempt.
- `caption`: final platform-specific result, stored on that job.
- `errorMessage`: failure information, stored on that job.

The app does not simulate progress or automatically mark jobs complete. Until the final AI/backend integration, jobs remain waiting for the AI connection unless manually cancelled. The lifecycle methods are ready for the future worker to call.

## Repository operations

- `getAll()` returns jobs newest first.
- `getForMonth(DateTime(year, month))` returns jobs created in that month.
- `start(id)` records a start timestamp.
- `saveCaption(id, caption)` stores a result and completion timestamp.
- `saveFailure(id, message)` stores a failure and completion timestamp.
- `updateStatus(id, JobStatus.waitingForAi)` retries and clears old output/timestamps while incrementing the retry count.

Older locally saved jobs remain readable; missing lifecycle fields default to null/zero.
