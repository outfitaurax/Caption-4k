# Source review fixes — 2026-11-03

This is a source-level correction pass on `Caption_4K_final_candidate.zip`.

## Changes made

1. **Detached image retention:** editing a product no longer immediately deletes images removed from its image list. Their original per-image `imageAddedAt` timestamp is kept in the orphan index, and the owning product ID is stored separately.
2. **Deleted-product image protection:** detached images remain protected while any associated operation is in `Waiting for AI connection`, `Queued`, or `Processing`. Deleting a product cancels waiting/queued jobs but leaves an already-processing job record intact until it is resolved.
3. **Safe orphan cleanup:** orphan date/owner indexes are read before cleanup. Corrupt indexes are backed up and cleanup fails closed rather than deleting files without knowing their owner. Expired image metadata is persisted to the orphan index before product metadata is removed, and failed file deletions remain queued for a later retry.
4. **Three-month cleanup ordering:** stale waiting/queued jobs are expired before the job list is read for pruning, preventing the cleanup routine from writing an older copy of the job list and accidentally restoring an expired waiting job.
5. **30-day waiting timeout:** retries reset the waiting-window timestamp without incrementing the attempt counter. `Waiting for AI connection` and `Queued` jobs older than 30 days are cancelled with an explicit reason and a recorded history entry. A stale waiting/queued job is also rejected if a start is attempted before the next scheduled cleanup.
6. **Operation lifecycle:** starting a waiting/queued job now changes its status to `Processing`, records a start time, increments the attempt count once, and is idempotent if called repeatedly. Completed/cancelled jobs cannot be restarted directly.
7. **Attempt history:** attempt numbers now align with actual starts and prior history, including older jobs that only had an attempt counter. Completion/failure/cancellation closes the active attempt; editing an already-completed caption does not create a fake new attempt.
8. **Product deletion and platform edits:** queued work removed from a product/platform is cancelled with a reason rather than silently dropped. Processing work is retained so its image protection is not lost.
9. **Partial upload save:** if a product is saved successfully but creation of its local operation records fails, the uploaded images are removed from the upload selection and the user is informed. Retrying no longer creates a duplicate product for that already-saved group.
10. **UI wording:** the product-delete confirmation now accurately describes cancellation of waiting/queued work and retention of active processing work.

## Tests added or updated

- Editing a product detaches removed images without deleting them before their 30-day expiry.
- Detached images remain protected while a deleted product has an active processing job, then become eligible for cleanup after cancellation.
- Starting a job moves it to `Processing` and repeated start calls do not double-count attempts.
- Queued jobs can start processing; completed jobs cannot restart.
- A retry resets the 30-day waiting window without counting an attempt until processing actually starts.
- Existing attempt-history test now models two real starts and checks the attempt count accordingly.

## Validation status

- ZIP integrity: passed.
- Basic delimiter scan across 66 Dart files: passed; this is not a Dart compiler/analyzer.
- `pubspec.yaml` YAML parse: passed.
- `scripts/bootstrap_platforms.sh` shell syntax check: passed.
- `flutter pub get`, `flutter analyze`, `flutter test`, Android build, and on-device UI testing: **not run** because Flutter and Dart executables are not installed in the review environment.
- Android/iOS platform folders and `pubspec.lock` remain absent from this source archive. Generate platform scaffolding and a lockfile in the actual Flutter environment before building.

This is an improved source candidate, not a verified APK or release build. The future Tout/backend integration remains intentionally unimplemented.
