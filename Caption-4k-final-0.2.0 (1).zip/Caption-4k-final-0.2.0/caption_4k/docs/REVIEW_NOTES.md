# Source review update — 2026-11-01

## Changes applied

1. **Operation revisions:** new operation IDs are unique per revision. Unchanged saves are deduplicated; changed product name/description/category/images create a new operation, and re-adding a previously removed platform also creates a new operation while previous completed results remain in history. Platform selection changes no longer force re-generation for unchanged platforms.
2. **Analytics dates:** completed captions, failures, and cancellations are counted in the period they actually finished (`completedAt`), not the period the product/job was first created. Time-series buckets use completion time. Average captions per product uses the distinct products represented by completed captions.
3. **Retention:** image expiry is measured from each image's own `imageAddedAt` date (30 days). Product text and operation history are removed after three calendar months. If a product record expires while one of its images is still younger than 30 days, the image timestamp is retained in a local orphan index until its own expiry. Failed file deletions are retried on later sweeps.
4. **Background cleanup:** Android WorkManager is configured for a daily periodic cleanup, with startup and app-resume cleanup as fallbacks. Android may defer the exact run time according to system and battery policies.
5. **Notification permission feedback:** the settings screen now distinguishes a granted permission from a denied/unavailable request.
6. **Regression tests added/updated:** operation revision deduplication, completion-period analytics, 30-day image cleanup, and three-month record cleanup.

## Important limits / validation still required

- This is an updated **source candidate**, not a verified release build. The current environment has no Flutter or Dart executable, so `flutter pub get`, `flutter analyze`, `flutter test`, and APK build have not been run.
- `pubspec.lock` is intentionally omitted because the prior lockfile did not match the declared dependencies. Run `flutter pub get` in the target Flutter environment to generate a consistent lockfile.
- Android/iOS platform folders are not included; run `bash scripts/bootstrap_platforms.sh` after installing the required Flutter SDK.
- WorkManager cleanup is best-effort, not an exact clock alarm. Android can defer periodic work because of battery/system policies. The task is registered on Android only; iOS background execution needs separate Apple platform setup.
- AI caption generation remains intentionally unconfigured until the later Tout integration. The local workflow, history, manual caption saving, templates and analytics remain separate from that future integration.
