/// Pure Dart analytics model. No Flutter imports.
enum AnalyticsPeriod { daily, weekly, monthly }

enum ContentCategory {
  outfit,
  decor,
  prompt,
  products;

  String get label => name.toUpperCase();
  String get title => '${name[0].toUpperCase()}${name.substring(1)}';
}

enum SocialPlatform {
  instagram,
  pinterest,
  tiktok,
  x,
  facebook,
  website;

  String get label => switch (this) {
        SocialPlatform.instagram => 'Instagram',
        SocialPlatform.pinterest => 'Pinterest',
        SocialPlatform.tiktok => 'TikTok',
        SocialPlatform.x => 'X',
        SocialPlatform.facebook => 'Facebook',
        SocialPlatform.website => 'Website',
      };
}

class SeriesPoint {
  const SeriesPoint({
    required this.label,
    required this.captions,
    required this.products,
  });
  final String label;
  final int captions;
  final int products;
}

class ProductActivity {
  const ProductActivity({
    required this.name,
    required this.category,
    required this.captions,
    required this.whenLabel,
  });
  final String name;
  final ContentCategory category;
  final int captions;
  final String whenLabel;
}

/// Everything the analytics UI needs for one period.
/// Counts are per PRODUCT, never per image.
class AnalyticsSummary {
  const AnalyticsSummary({
    required this.period,
    this.products = 0,
    this.productsChange,
    this.captions = 0,
    this.captionsChange,
    this.avgCaptionsPerProduct = 0,
    this.avgCaptionsChange,
    this.avgProcessingSeconds = 0,
    this.avgProcessingChange,
    this.series = const [],
    this.platformsByCategory = const {},
    this.platformsOverTime = const [],
    this.heatmap = const [],
    this.completed = 0,
    this.failed = 0,
    this.cancelled = 0,
    this.stageSeconds = const {},
    this.recent = const [],
  });

  final AnalyticsPeriod period;
  final int products;
  final double? productsChange; // 0.14 == +14% vs previous period
  final int captions;
  final double? captionsChange;
  final double avgCaptionsPerProduct;
  final double? avgCaptionsChange;
  final int avgProcessingSeconds;
  final double? avgProcessingChange;
  final List<SeriesPoint> series;
  final Map<ContentCategory, Map<SocialPlatform, int>> platformsByCategory;
  final List<Map<SocialPlatform, int>> platformsOverTime;

  /// Rows = Mon..Sun, columns = morning, noon, evening, night. Values 0..5.
  final List<List<int>> heatmap;
  final int completed;
  final int failed;
  final int cancelled;
  final Map<String, int> stageSeconds;
  final List<ProductActivity> recent;

  bool get isEmpty => products == 0 && captions == 0;

  int captionsForCategory(ContentCategory c) =>
      (platformsByCategory[c] ?? const {}).values.fold(0, (a, b) => a + b);

  int captionsForPlatform(SocialPlatform p) =>
      platformsByCategory.values.fold(0, (a, m) => a + (m[p] ?? 0));
}
