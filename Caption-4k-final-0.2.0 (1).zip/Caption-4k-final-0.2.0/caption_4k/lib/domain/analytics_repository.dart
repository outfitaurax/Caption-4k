import 'analytics.dart';

abstract interface class AnalyticsRepository {
  Future<AnalyticsSummary> load(AnalyticsPeriod period);
}
