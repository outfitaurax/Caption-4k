import 'package:material_ui/material_ui.dart';

import '../../app/routes.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_tokens.dart';

/// Shared page layout: large title, settings icon, scrollable content.
class ScreenScaffold extends StatelessWidget {
  const ScreenScaffold({super.key, required this.title, required this.children});

  final String title;
  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    return SafeArea(
      bottom: false,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 14, 12, 8),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    title,
                    style: AppText.screenTitle.copyWith(color: c.text),
                  ),
                ),
                IconButton(
                  tooltip: 'Settings',
                  icon: Icon(Icons.settings_outlined, color: c.text),
                  onPressed: () => AppRoutes.openSettings(context),
                ),
              ],
            ),
          ),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
              children: children,
            ),
          ),
        ],
      ),
    );
  }
}
