import 'package:material_ui/material_ui.dart';

import '../../core/theme/app_colors.dart';

class Heatmap extends StatelessWidget {
  const Heatmap({
    super.key,
    required this.rows,
    required this.rowLabels,
    required this.colLabels,
  });

  final List<List<int>> rows;
  final List<String> rowLabels;
  final List<String> colLabels;

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    final small = TextStyle(fontSize: 10, color: c.textSecondary);
    return Column(
      children: [
        Row(
          children: [
            const SizedBox(width: 38),
            for (final l in colLabels)
              Expanded(child: Text(l, textAlign: TextAlign.center, style: small)),
          ],
        ),
        const SizedBox(height: 6),
        for (var i = 0; i < rows.length; i++)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 3),
            child: Row(
              children: [
                SizedBox(width: 38, child: Text(rowLabels[i], style: small)),
                for (final v in rows[i])
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 3),
                      child: Opacity(
                        opacity: (0.1 + v * 0.17).clamp(0.0, 1.0),
                        child: Container(
                          height: 22,
                          decoration: BoxDecoration(
                            color: c.selected,
                            borderRadius: BorderRadius.circular(7),
                          ),
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
      ],
    );
  }
}
