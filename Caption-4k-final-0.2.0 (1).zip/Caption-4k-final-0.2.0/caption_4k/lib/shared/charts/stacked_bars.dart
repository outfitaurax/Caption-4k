import 'package:material_ui/material_ui.dart';

import '../../core/theme/app_colors.dart';

/// One column per bucket; each column stacks [stacks][i][j] with [colors][j].
class StackedBars extends StatelessWidget {
  const StackedBars({
    super.key,
    required this.labels,
    required this.stacks,
    required this.colors,
    this.height = 120,
  });

  final List<String> labels;
  final List<List<int>> stacks;
  final List<Color> colors;
  final double height;

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    final totals = [for (final s in stacks) s.fold(0, (a, b) => a + b)];
    final maxT = totals.fold(1, (a, b) => a > b ? a : b);
    return Column(
      children: [
        SizedBox(
          height: height,
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              for (var i = 0; i < stacks.length; i++)
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 5),
                    child: Align(
                      alignment: Alignment.bottomCenter,
                      child: totals[i] == 0
                          ? const SizedBox.shrink()
                          : FractionallySizedBox(
                              heightFactor: (totals[i] / maxT).clamp(0.04, 1.0),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(6),
                                child: Column(
                                  verticalDirection: VerticalDirection.up,
                                  children: [
                                    for (var j = 0; j < stacks[i].length; j++)
                                      if (stacks[i][j] > 0)
                                        Expanded(
                                          flex: stacks[i][j],
                                          child: ColoredBox(color: colors[j]),
                                        ),
                                  ],
                                ),
                              ),
                            ),
                    ),
                  ),
                ),
            ],
          ),
        ),
        const SizedBox(height: 6),
        Row(
          children: [
            for (final l in labels)
              Expanded(
                child: Text(
                  l,
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 10, color: c.textSecondary),
                ),
              ),
          ],
        ),
      ],
    );
  }
}
