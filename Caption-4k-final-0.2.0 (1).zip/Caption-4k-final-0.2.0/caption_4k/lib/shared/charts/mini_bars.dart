import 'package:material_ui/material_ui.dart';

import '../../core/theme/app_colors.dart';

/// Small bar chart used in the Total Captions card. Last bar is highlighted.
class MiniBars extends StatelessWidget {
  const MiniBars({super.key, required this.labels, required this.values, this.height = 96});

  final List<String> labels;
  final List<int> values;
  final double height;

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    final maxV = values.fold(1, (a, b) => a > b ? a : b);
    return SizedBox(
      height: height,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          for (var i = 0; i < values.length; i++)
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 3),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Container(
                      height: (height - 20) * values[i] / maxV,
                      decoration: BoxDecoration(
                        color: i == values.length - 1 ? c.selected : c.muted,
                        borderRadius: BorderRadius.circular(6),
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      labels[i],
                      maxLines: 1,
                      style: TextStyle(fontSize: 10, color: c.textSecondary),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}
