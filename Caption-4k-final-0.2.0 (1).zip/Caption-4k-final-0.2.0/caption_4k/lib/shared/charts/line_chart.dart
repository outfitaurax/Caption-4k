import 'package:material_ui/material_ui.dart';

import '../../core/theme/app_colors.dart';

/// Two-series line chart: filled primary line, dashed secondary line.
class LineChart extends StatelessWidget {
  const LineChart({
    super.key,
    required this.labels,
    required this.primary,
    required this.secondary,
    this.height = 170,
  });

  final List<String> labels;
  final List<double> primary;
  final List<double> secondary;
  final double height;

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    return SizedBox(
      height: height,
      width: double.infinity,
      child: CustomPaint(
        painter: _LinePainter(
          labels: labels,
          primary: primary,
          secondary: secondary,
          line: c.selected,
          sub: c.textSecondary,
          grid: c.border,
          dotFill: c.card,
        ),
      ),
    );
  }
}

class _LinePainter extends CustomPainter {
  _LinePainter({
    required this.labels,
    required this.primary,
    required this.secondary,
    required this.line,
    required this.sub,
    required this.grid,
    required this.dotFill,
  });

  final List<String> labels;
  final List<double> primary;
  final List<double> secondary;
  final Color line;
  final Color sub;
  final Color grid;
  final Color dotFill;

  @override
  void paint(Canvas canvas, Size size) {
    final n = primary.length;
    if (n == 0) return;
    const left = 8.0, right = 8.0, top = 8.0, bottom = 24.0;
    final w = size.width - left - right;
    final h = size.height - top - bottom;
    var maxV = 1.0;
    for (final v in [...primary, ...secondary]) {
      if (v > maxV) maxV = v;
    }
    double x(int i) => n == 1 ? left + w / 2 : left + i * w / (n - 1);
    double y(double v) => top + h * (1 - v / maxV);

    final gridPaint = Paint()
      ..color = grid
      ..strokeWidth = 1;
    for (final f in [0.0, 0.5, 1.0]) {
      final gy = top + h * f;
      canvas.drawLine(Offset(left, gy), Offset(left + w, gy), gridPaint);
    }

    final pts = [for (var i = 0; i < n; i++) Offset(x(i), y(primary[i]))];
    final pts2 = [
      for (var i = 0; i < n && i < secondary.length; i++)
        Offset(x(i), y(secondary[i])),
    ];

    final linePath = _path(pts);
    final area = Path.from(linePath)
      ..lineTo(pts.last.dx, top + h)
      ..lineTo(pts.first.dx, top + h)
      ..close();
    canvas.drawPath(area, Paint()..color = line.withValues(alpha: 0.08));

    if (pts2.length > 1) {
      final dashPaint = Paint()
        ..color = sub
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2;
      for (final m in _path(pts2).computeMetrics()) {
        var d = 0.0;
        while (d < m.length) {
          canvas.drawPath(m.extractPath(d, d + 4), dashPaint);
          d += 8;
        }
      }
    }

    canvas.drawPath(
      linePath,
      Paint()
        ..color = line
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.5
        ..strokeJoin = StrokeJoin.round
        ..strokeCap = StrokeCap.round,
    );
    for (final p in pts) {
      canvas.drawCircle(p, 3.5, Paint()..color = dotFill);
      canvas.drawCircle(
        p,
        3.5,
        Paint()
          ..color = line
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2,
      );
    }

    for (var i = 0; i < n && i < labels.length; i++) {
      final tp = TextPainter(
        text: TextSpan(text: labels[i], style: TextStyle(fontSize: 10, color: sub)),
        textDirection: TextDirection.ltr,
      )..layout();
      tp.paint(canvas, Offset(x(i) - tp.width / 2, size.height - bottom + 8));
    }
  }

  Path _path(List<Offset> pts) {
    final p = Path()..moveTo(pts.first.dx, pts.first.dy);
    for (final o in pts.skip(1)) {
      p.lineTo(o.dx, o.dy);
    }
    return p;
  }

  @override
  bool shouldRepaint(covariant _LinePainter old) => true;
}
