import 'package:material_ui/material_ui.dart';

import '../../core/theme/app_colors.dart';

class PercentBar extends StatelessWidget {
  const PercentBar({super.key, required this.fraction, required this.color});

  final double fraction;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(4),
      child: Stack(
        children: [
          Container(height: 8, color: context.colors.muted),
          FractionallySizedBox(
            widthFactor: fraction.clamp(0.0, 1.0),
            child: Container(height: 8, color: color),
          ),
        ],
      ),
    );
  }
}
