import 'package:material_ui/material_ui.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../core/navigation/app_navigator.dart';
import '../core/storage/preferences.dart';
import '../features/operations/data/processing_job_repository.dart';
import '../core/theme/app_theme.dart';
import '../features/operations/presentation/processing_job_detail.dart';
import '../features/settings/application/theme_controller.dart';
import '../features/upload/data/product_repository.dart';
import '../features/ai/data/ai_chat_repository.dart';
import '../shell/main_shell.dart';

class CaptionApp extends ConsumerStatefulWidget {
  const CaptionApp({super.key});

  @override
  ConsumerState<CaptionApp> createState() => _CaptionAppState();
}

class _CaptionAppState extends ConsumerState<CaptionApp>
    with WidgetsBindingObserver {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _cleanupExpiredImages();
  }

  Future<void> _cleanupExpiredImages() async {
    try {
      // The background cleanup runs in another isolate; refresh the cached
      // preferences so this isolate never overwrites its changes.
      await ref.read(sharedPreferencesProvider).reload();
      final repository = ref.read(productRepositoryProvider);
      await repository.expireOldImages();
      await repository.expireOldRecords();
      await ref.read(aiChatRepositoryProvider).expireOldConversations();
      ref.invalidate(productsProvider);
      ref.invalidate(processingJobsProvider);
    } catch (_) {
      // Image cleanup is best-effort and must not interrupt app navigation.
    }
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Caption 4K',
      navigatorKey: appNavigatorKey,
      onGenerateRoute: (settings) {
        if (settings.name == '/operation') {
          final jobId = settings.arguments as String?;
          if (jobId != null) {
            return MaterialPageRoute<void>(
              builder: (_) => ProcessingJobNotificationScreen(jobId: jobId),
            );
          }
        }
        return null;
      },
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light(),
      darkTheme: AppTheme.dark(),
      themeMode: ref.watch(themeModeProvider),
      home: const MainShell(),
    );
  }
}
