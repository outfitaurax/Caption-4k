import 'package:cupertino_ui/cupertino_ui.dart';

import '../features/settings/presentation/settings_screen.dart';

class AppRoutes {
  const AppRoutes._();

  static Future<void> openSettings(BuildContext context) {
    return Navigator.of(context).push(
      CupertinoPageRoute<void>(builder: (_) => const SettingsScreen()),
    );
  }
}
