import '../../../domain/analytics.dart';
import '../../../domain/analytics_repository.dart';
import '../../operations/data/processing_job.dart';
import '../../upload/data/product.dart';

/// Builds analytics only from locally saved products and processing jobs.
/// Products are counted once regardless of how many images they contain.
class LocalAnalyticsRepository implements AnalyticsRepository {
  LocalAnalyticsRepository({
    required this.products,
    required this.jobs,
    DateTime Function()? clock,
  }) : _clock = clock ?? DateTime.now;

  final List<Product> products;
  final List<ProcessingJob> jobs;
  final DateTime Function() _clock;

  @override
  Future<AnalyticsSummary> load(AnalyticsPeriod period) async {
    final now = _clock();
    final duration = switch (period) {
      AnalyticsPeriod.daily => const Duration(days: 1),
      AnalyticsPeriod.weekly => const Duration(days: 7),
      AnalyticsPeriod.monthly => const Duration(days: 30),
    };
    final start = switch (period) {
      AnalyticsPeriod.daily => DateTime(now.year, now.month, now.day),
      AnalyticsPeriod.weekly => now.subtract(duration),
      AnalyticsPeriod.monthly => DateTime(now.year, now.month, 1),
    };
    final previousStart = period == AnalyticsPeriod.monthly
        ? DateTime(start.year, start.month - 1, 1)
        : start.subtract(duration);

    final currentProducts = products
        .where((p) => !p.createdAt.isBefore(start) && !p.createdAt.isAfter(now))
        .toList();
    final previousProducts = products
        .where((p) => !p.createdAt.isBefore(previousStart) && p.createdAt.isBefore(start))
        .toList();
    final currentJobs = jobs
        .where((j) => !j.createdAt.isBefore(start) && !j.createdAt.isAfter(now))
        .toList();

    // Completed captions belong to the period in which they were actually
    // completed, not the date the product/operation was first created.
    final completed = jobs.where((j) =>
        j.status == JobStatus.completed &&
        j.completedAt != null &&
        !j.completedAt!.isBefore(start) &&
        !j.completedAt!.isAfter(now)).toList();
    final previousCompleted = jobs.where((j) =>
        j.status == JobStatus.completed &&
        j.completedAt != null &&
        !j.completedAt!.isBefore(previousStart) &&
        j.completedAt!.isBefore(start)).toList();
    final failedInPeriod = jobs.where((j) =>
        j.status == JobStatus.failed && j.completedAt != null &&
        !j.completedAt!.isBefore(start) && !j.completedAt!.isAfter(now)).length;
    final cancelledInPeriod = jobs.where((j) =>
        j.status == JobStatus.cancelled && j.completedAt != null &&
        !j.completedAt!.isBefore(start) && !j.completedAt!.isAfter(now)).length;
    final currentIds = currentProducts.map((p) => p.id).toSet();

    final byCategory = <ContentCategory, Map<SocialPlatform, int>>{
      for (final category in ContentCategory.values)
        category: {for (final platform in SocialPlatform.values) platform: 0},
    };
    for (final job in completed) {
      byCategory[job.category]![job.platform] =
          byCategory[job.category]![job.platform]! + 1;
    }

    final bucketCount = switch (period) {
      AnalyticsPeriod.daily => 4,
      AnalyticsPeriod.weekly => 7,
      AnalyticsPeriod.monthly => 6,
    };
    final bucketDuration = switch (period) {
      AnalyticsPeriod.daily => const Duration(hours: 6),
      AnalyticsPeriod.weekly => const Duration(days: 1),
      AnalyticsPeriod.monthly => const Duration(days: 5),
    };
    final series = <SeriesPoint>[];
    final platformsOverTime = <Map<SocialPlatform, int>>[];
    for (var i = 0; i < bucketCount; i++) {
      final bucketStart = period == AnalyticsPeriod.daily
          ? start.add(Duration(hours: i * 6))
          : start.add(bucketDuration * i);
      final bucketEnd = i == bucketCount - 1
          ? now.add(const Duration(microseconds: 1))
          : bucketStart.add(bucketDuration);
      final bucketJobs = completed
          .where((j) => j.completedAt != null &&
              !j.completedAt!.isBefore(bucketStart) && j.completedAt!.isBefore(bucketEnd))
          .toList();
      final bucketProducts = currentProducts
          .where((p) => !p.createdAt.isBefore(bucketStart) && p.createdAt.isBefore(bucketEnd))
          .length;
      final label = period == AnalyticsPeriod.daily
          ? '${bucketStart.hour.toString().padLeft(2, '0')}:00'
          : '${bucketStart.day}/${bucketStart.month}';
      series.add(SeriesPoint(
        label: label,
        captions: bucketJobs.length,
        products: bucketProducts,
      ));
      platformsOverTime.add({
        for (final platform in SocialPlatform.values)
          platform: bucketJobs.where((job) => job.platform == platform).length,
      });
    }

    // Weekday x time-of-day heatmap. Counts operations created in this period.
    final heatmap = List.generate(7, (_) => List<int>.filled(4, 0));
    for (final job in currentJobs) {
      final local = job.createdAt.toLocal();
      final weekday = local.weekday - 1;
      final hour = local.hour;
      final timeBucket = hour >= 5 && hour < 11
          ? 0
          : hour >= 11 && hour < 16
              ? 1
              : hour >= 16 && hour < 21
                  ? 2
                  : 3;
      heatmap[weekday][timeBucket]++;
    }

    final averageProcessing = _averageProcessingSeconds(completed);
    final previousAverageProcessing = _averageProcessingSeconds(previousCompleted);
    final completedProductIds = completed.map((job) => job.productId).toSet();
    final previousCompletedProductIds =
        previousCompleted.map((job) => job.productId).toSet();
    final averagePerProduct = completedProductIds.isEmpty
        ? 0.0
        : completed.length / completedProductIds.length;
    final previousAveragePerProduct = previousCompletedProductIds.isEmpty
        ? 0.0
        : previousCompleted.length / previousCompletedProductIds.length;

    final recent = currentProducts.toList()
      ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
    final recentActivities = recent.take(8).map((p) => ProductActivity(
          name: p.name,
          category: p.category,
          captions: completed.where((j) => j.productId == p.id).length,
          whenLabel: _relativeLabel(now.difference(p.createdAt)),
        )).toList();

    final averageTime = averageProcessing.round();
    return AnalyticsSummary(
      period: period,
      products: currentIds.length,
      productsChange: _percentChange(currentIds.length.toDouble(), previousProducts.length.toDouble()),
      captions: completed.length,
      captionsChange: _percentChange(completed.length.toDouble(), previousCompleted.length.toDouble()),
      avgCaptionsPerProduct: averagePerProduct,
      avgCaptionsChange: _percentChange(averagePerProduct, previousAveragePerProduct),
      avgProcessingSeconds: averageTime,
      avgProcessingChange: _percentChange(averageProcessing, previousAverageProcessing),
      series: series,
      platformsByCategory: byCategory,
      platformsOverTime: platformsOverTime,
      heatmap: heatmap,
      completed: completed.length,
      failed: failedInPeriod,
      cancelled: cancelledInPeriod,
      stageSeconds: averageProcessing > 0 ? {'Total operation': averageTime} : const {},
      recent: recentActivities,
    );
  }

  double _averageProcessingSeconds(List<ProcessingJob> jobs) {
    final durations = jobs
        .map((job) => job.processingDuration?.inSeconds)
        .whereType<int>()
        .where((seconds) => seconds >= 0)
        .toList();
    if (durations.isEmpty) return 0;
    return durations.reduce((a, b) => a + b) / durations.length;
  }

  double? _percentChange(double current, double previous) {
    if (previous <= 0) return null;
    return (current - previous) / previous;
  }

  String _relativeLabel(Duration age) {
    if (age.inMinutes < 1) return 'Just now';
    if (age.inHours < 1) return '${age.inMinutes}m ago';
    if (age.inDays < 1) return '${age.inHours}h ago';
    return '${age.inDays}d ago';
  }
}
