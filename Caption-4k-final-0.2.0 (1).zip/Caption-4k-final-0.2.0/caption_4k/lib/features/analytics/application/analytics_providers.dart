import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../domain/analytics.dart';
import '../data/local_analytics_repository.dart';
import '../../operations/data/processing_job_repository.dart';
import '../../upload/data/product_repository.dart';

final analyticsPeriodProvider = StateProvider<AnalyticsPeriod>((ref) => AnalyticsPeriod.weekly);

final analyticsSummaryProvider = FutureProvider<AnalyticsSummary>((ref) async {
  // Watch these refreshable providers so Home stats update after local changes.
  final productsState = ref.watch(productsProvider);
  final jobsState = ref.watch(processingJobsProvider);
  final products = productsState.valueOrNull ?? await ref.watch(productRepositoryProvider).getAll();
  final jobs = jobsState.valueOrNull ?? await ref.watch(processingJobRepositoryProvider).getAll();
  final repository = LocalAnalyticsRepository(products: products, jobs: jobs);
  return repository.load(ref.watch(analyticsPeriodProvider));
});
