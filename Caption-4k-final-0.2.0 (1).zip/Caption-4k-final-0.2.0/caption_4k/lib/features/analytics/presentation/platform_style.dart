import 'package:material_ui/material_ui.dart';

import '../../../core/theme/app_colors.dart';
import '../../../domain/analytics.dart';

extension PlatformStyle on SocialPlatform {
  /// Brand colour used when a platform tile is selected.
  Color color(AppColors c) => switch (this) {
        SocialPlatform.instagram => const Color(0xFFD6249F),
        SocialPlatform.pinterest => const Color(0xFFE60023),
        SocialPlatform.tiktok => c.text,
        SocialPlatform.x => c.text,
        SocialPlatform.facebook => const Color(0xFF1877F2),
        SocialPlatform.website => const Color(0xFF3B5B8A),
      };
}

Color categoryColor(ContentCategory category) => switch (category) {
      ContentCategory.outfit => const Color(0xFF7C3AED), // Purple
      ContentCategory.decor => const Color(0xFFF59E0B), // Orange
      ContentCategory.prompt => const Color(0xFF2563EB), // Blue
      ContentCategory.products => const Color(0xFFDC2626), // Red
    };

List<Color> categoryColors() =>
    [for (final category in ContentCategory.values) categoryColor(category)];
