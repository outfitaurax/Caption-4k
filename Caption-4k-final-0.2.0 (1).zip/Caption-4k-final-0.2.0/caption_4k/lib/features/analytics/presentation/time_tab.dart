import 'package:material_ui/material_ui.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_tokens.dart';
import '../../../domain/analytics.dart';
import '../../../shared/charts/heatmap.dart';
import '../../../shared/charts/percent_bar.dart';
import '../../../shared/widgets/app_card.dart';
import 'analytics_widgets.dart';

class TimeTab extends StatelessWidget {
  const TimeTab({super.key, required this.summary});
  final AnalyticsSummary summary;

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    final s = summary;
    final outcomeTotal = s.completed + s.failed + s.cancelled;
    final maxStage = s.stageSeconds.values.fold(1, (a, b) => a > b ? a : b);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (s.heatmap.isNotEmpty) ...[
          const SectionHeading('Busiest times'),
          AppCard(
            child: Heatmap(
              rows: s.heatmap,
              rowLabels: const ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
              colLabels: const ['Morning', 'Noon', 'Evening', 'Night'],
            ),
          ),
        ],
        const SectionHeading('Processing'),
        AppCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (outcomeTotal > 0) ...[
                Row(
                  children: [
                    Text('Outcome', style: AppText.caption.copyWith(color: c.textSecondary)),
                    const Spacer(),
                    Text(
                      '${(s.completed * 100 / outcomeTotal).round()}% completed',
                      style: AppText.caption.copyWith(color: c.textSecondary),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                ClipRRect(
                  borderRadius: BorderRadius.circular(5),
                  child: SizedBox(
                    height: 10,
                    child: Row(
                      children: [
                        if (s.completed > 0)
                          Expanded(flex: s.completed, child: ColoredBox(color: c.success)),
                        if (s.failed > 0) ...[
                          const SizedBox(width: 2),
                          Expanded(flex: s.failed, child: const ColoredBox(color: Color(0xFFC0554F))),
                        ],
                        if (s.cancelled > 0) ...[
                          const SizedBox(width: 2),
                          Expanded(flex: s.cancelled, child: ColoredBox(color: c.muted)),
                        ],
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  '${(s.failed * 100 / outcomeTotal).round()}% failed \u00b7 ${(s.cancelled * 100 / outcomeTotal).round()}% cancelled',
                  style: const TextStyle(fontSize: 11).copyWith(color: c.textSecondary),
                ),
                const SizedBox(height: AppSpacing.lg),
              ],
              Text(
                'Average operation time',
                style: AppText.caption.copyWith(color: c.textSecondary),
              ),
              for (final e in s.stageSeconds.entries)
                Padding(
                  padding: const EdgeInsets.only(top: 12),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          Expanded(child: Text(e.key, style: AppText.body.copyWith(color: c.text))),
                          Text(
                            formatSeconds(e.value),
                            style: AppText.caption.copyWith(color: c.textSecondary),
                          ),
                        ],
                      ),
                      const SizedBox(height: 6),
                      PercentBar(fraction: e.value / maxStage, color: c.selected),
                    ],
                  ),
                ),
            ],
          ),
        ),
      ],
    );
  }
}
