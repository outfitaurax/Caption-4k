import 'package:material_ui/material_ui.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_tokens.dart';
import '../../../domain/analytics.dart';
import '../../../shared/charts/percent_bar.dart';
import '../../../shared/charts/stacked_bars.dart';
import '../../../shared/widgets/app_card.dart';
import 'analytics_widgets.dart';
import 'platform_style.dart';

class PlatformsTab extends StatelessWidget {
  const PlatformsTab({super.key, required this.summary});
  final AnalyticsSummary summary;

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    final s = summary;
    final total = s.captions == 0 ? 1 : s.captions;
    final sorted = [...SocialPlatform.values]
      ..sort((a, b) => s.captionsForPlatform(b).compareTo(s.captionsForPlatform(a)));
    final used = [
      for (final p in SocialPlatform.values)
        if (s.captionsForPlatform(p) > 0) p,
    ];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SectionHeading('Platform usage'),
        AppCard(
          child: Column(
            children: [
              for (final p in sorted)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 7),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          ColorDot(p.color(c)),
                          const SizedBox(width: 8),
                          Expanded(child: Text(p.label, style: AppText.body.copyWith(color: c.text))),
                          Text(
                            '${s.captionsForPlatform(p)} \u00b7 ${(s.captionsForPlatform(p) * 100 / total).round()}%',
                            style: AppText.caption.copyWith(color: c.textSecondary),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      PercentBar(
                        fraction: s.captionsForPlatform(p) / total,
                        color: p.color(c),
                      ),
                    ],
                  ),
                ),
            ],
          ),
        ),
        const SectionHeading('Platforms over time'),
        AppCard(
          child: Column(
            children: [
              StackedBars(
                labels: [for (final p in s.series) p.label],
                stacks: [
                  for (final m in s.platformsOverTime) [for (final p in used) m[p] ?? 0],
                ],
                colors: [for (final p in used) p.color(c)],
              ),
              const SizedBox(height: AppSpacing.md),
              Wrap(
                spacing: 14,
                runSpacing: 6,
                children: [
                  for (final p in used)
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        ColorDot(p.color(c)),
                        const SizedBox(width: 5),
                        Text(p.label, style: AppText.caption.copyWith(color: c.textSecondary)),
                      ],
                    ),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }
}
