import 'package:material_ui/material_ui.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_tokens.dart';
import '../../../domain/analytics.dart';
import '../../../shared/charts/donut_chart.dart';
import '../../../shared/charts/line_chart.dart';
import '../../../shared/widgets/app_card.dart';
import 'analytics_widgets.dart';
import 'platform_style.dart';

class OverviewTab extends StatelessWidget {
  const OverviewTab({super.key, required this.summary});
  final AnalyticsSummary summary;

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    final s = summary;
    final colors = categoryColors();
    final values = [for (final k in ContentCategory.values) s.captionsForCategory(k)];
    final total = values.fold(0, (a, b) => a + b);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(
              child: MetricTile(label: 'Products', value: '${s.products}', change: s.productsChange),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: MetricTile(label: 'Captions', value: '${s.captions}', change: s.captionsChange),
            ),
          ],
        ),
        const SizedBox(height: 10),
        Row(
          children: [
            Expanded(
              child: MetricTile(
                label: 'Captions / product',
                value: s.avgCaptionsPerProduct.toStringAsFixed(1),
                change: s.avgCaptionsChange,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: MetricTile(
                label: 'Failed / Cancelled',
                value: '${s.failed} / ${s.cancelled}',
              ),
            ),
          ],
        ),
        const SizedBox(height: AppSpacing.lg),
        const SectionHeading('Activity over time'),
        AppCard(
          child: Column(
            children: [
              LineChart(
                labels: [for (final p in s.series) p.label],
                primary: [for (final p in s.series) p.captions.toDouble()],
                secondary: [for (final p in s.series) p.products.toDouble()],
              ),
              const SizedBox(height: AppSpacing.sm),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text('\u2014 Captions', style: AppText.caption.copyWith(color: c.textSecondary)),
                  const SizedBox(width: 16),
                  Text('- - Products', style: AppText.caption.copyWith(color: c.textSecondary)),
                ],
              ),
            ],
          ),
        ),
        const SectionHeading('Category split'),
        AppCard(
          child: Row(
            children: [
              DonutChart(
                values: values,
                colors: colors,
                centerValue: '$total',
                centerLabel: 'captions',
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  children: [
                    for (var i = 0; i < values.length; i++)
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 6),
                        child: Row(
                          children: [
                            ColorDot(colors[i]),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                ContentCategory.values[i].label,
                                style: AppText.body.copyWith(color: c.text),
                              ),
                            ),
                            Text(
                              '${values[i]} \u00b7 ${total == 0 ? 0 : (values[i] * 100 / total).round()}%',
                              style: AppText.caption.copyWith(color: c.textSecondary),
                            ),
                          ],
                        ),
                      ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SectionHeading('Product activity'),
        AppCard(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
          child: s.recent.isEmpty
              ? Padding(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  child: Text(
                    'No products in this period.',
                    style: AppText.caption.copyWith(color: c.textSecondary),
                  ),
                )
              : Column(
                  children: [
                    for (var i = 0; i < s.recent.length; i++) ...[
                      if (i > 0) Divider(height: 1, color: c.border),
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        child: Row(
                          children: [
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(s.recent[i].name, style: AppText.body.copyWith(color: c.text)),
                                  Text(
                                    '${s.recent[i].category.label} \u00b7 ${s.recent[i].captions} captions',
                                    style: AppText.caption.copyWith(color: c.textSecondary),
                                  ),
                                ],
                              ),
                            ),
                            Text(
                              s.recent[i].whenLabel,
                              style: AppText.caption.copyWith(color: c.textSecondary),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ],
                ),
        ),
      ],
    );
  }
}
