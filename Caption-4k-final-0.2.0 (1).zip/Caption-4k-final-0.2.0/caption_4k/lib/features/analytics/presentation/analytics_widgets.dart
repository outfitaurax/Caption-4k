import 'package:material_ui/material_ui.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_tokens.dart';

String formatSeconds(int s) => s >= 60 ? '${s ~/ 60}m ${s % 60}s' : '${s}s';

class SectionHeading extends StatelessWidget {
  const SectionHeading(this.text, {super.key});
  final String text;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(4, 6, 4, 12),
        child: Text(
          text,
          style: AppText.sectionTitle.copyWith(color: context.colors.text),
        ),
      );
}

class ColorDot extends StatelessWidget {
  const ColorDot(this.color, {super.key});
  final Color color;

  @override
  Widget build(BuildContext context) => Container(
        width: 10,
        height: 10,
        decoration: BoxDecoration(color: color, shape: BoxShape.circle),
      );
}

/// "↑ 14%" style change label. Null change renders nothing.
class ChangeLabel extends StatelessWidget {
  const ChangeLabel(this.change, {super.key, this.lowerIsBetter = false});
  final double? change;
  final bool lowerIsBetter;

  @override
  Widget build(BuildContext context) {
    final v = change;
    if (v == null) return const SizedBox.shrink();
    final c = context.colors;
    final good = lowerIsBetter ? v <= 0 : v >= 0;
    return Text(
      '${v >= 0 ? '\u2191' : '\u2193'} ${(v.abs() * 100).round()}%',
      style: TextStyle(
        fontSize: 12,
        fontWeight: FontWeight.w600,
        color: good ? c.success : c.textSecondary,
      ),
    );
  }
}

class MetricTile extends StatelessWidget {
  const MetricTile({
    super.key,
    required this.label,
    required this.value,
    this.change,
    this.lowerIsBetter = false,
  });

  final String label;
  final String value;
  final double? change;
  final bool lowerIsBetter;

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: c.card,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: c.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: AppText.caption.copyWith(color: c.textSecondary)),
          const SizedBox(height: 2),
          Text(
            value,
            style: TextStyle(fontSize: 26, fontWeight: FontWeight.w700, color: c.text),
          ),
          ChangeLabel(change, lowerIsBetter: lowerIsBetter),
        ],
      ),
    );
  }
}
