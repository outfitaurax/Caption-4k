import 'package:material_ui/material_ui.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_tokens.dart';
import '../../../domain/analytics.dart';
import '../../../shared/charts/mini_bars.dart';
import '../../../shared/widgets/app_card.dart';
import '../../../shared/widgets/app_segmented.dart';
import '../../../shared/widgets/empty_state.dart';
import '../application/analytics_providers.dart';
import 'analytics_widgets.dart';
import 'overview_tab.dart';
import 'platforms_tab.dart';
import 'time_tab.dart';

enum _Tab { overview, platforms, time }

class AnalyticsSection extends ConsumerStatefulWidget {
  const AnalyticsSection({super.key});

  @override
  ConsumerState<AnalyticsSection> createState() => _AnalyticsSectionState();
}

class _AnalyticsSectionState extends ConsumerState<AnalyticsSection> {
  _Tab _tab = _Tab.overview;

  @override
  Widget build(BuildContext context) {
    final period = ref.watch(analyticsPeriodProvider);
    final summary = ref.watch(analyticsSummaryProvider);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        AppSegmented<AnalyticsPeriod>(
          options: const [
            (AnalyticsPeriod.weekly, 'Weekly'),
            (AnalyticsPeriod.monthly, 'Monthly'),
            (AnalyticsPeriod.daily, 'Daily'),
          ],
          value: period,
          onChanged: (v) => ref.read(analyticsPeriodProvider.notifier).state = v,
        ),
        const SizedBox(height: AppSpacing.md),
        summary.when(
          loading: () => const SizedBox(
            height: 120,
            child: Center(child: CircularProgressIndicator.adaptive()),
          ),
          error: (_, __) => const AppCard(
            child: EmptyState(
              icon: Icons.error_outline,
              title: 'Could not load analytics',
              message: 'Please try again.',
            ),
          ),
          data: (s) => s.isEmpty ? const _Empty() : _content(s),
        ),
      ],
    );
  }

  Widget _content(AnalyticsSummary s) {
    final c = context.colors;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        AppCard(
          child: Row(
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '${s.captions}',
                    style: TextStyle(fontSize: 40, fontWeight: FontWeight.w700, color: c.text),
                  ),
                  Text('Total Captions', style: AppText.body.copyWith(color: c.textSecondary)),
                  const SizedBox(height: 4),
                  ChangeLabel(s.captionsChange),
                ],
              ),
              const SizedBox(width: 20),
              Expanded(
                child: MiniBars(
                  labels: [for (final p in s.series) p.label],
                  values: [for (final p in s.series) p.captions],
                ),
              ),
            ],
          ),
        ),
        AppSegmented<_Tab>(
          options: const [
            (_Tab.overview, 'Overview'),
            (_Tab.platforms, 'Platforms'),
            (_Tab.time, 'Time'),
          ],
          value: _tab,
          onChanged: (v) => setState(() => _tab = v),
        ),
        const SizedBox(height: AppSpacing.lg),
        switch (_tab) {
          _Tab.overview => OverviewTab(summary: s),
          _Tab.platforms => PlatformsTab(summary: s),
          _Tab.time => TimeTab(summary: s),
        },
      ],
    );
  }
}

class _Empty extends StatelessWidget {
  const _Empty();

  @override
  Widget build(BuildContext context) => const AppCard(
        child: EmptyState(
          icon: Icons.bar_chart_outlined,
          title: 'No analytics yet',
          message: 'Statistics appear after your first products.',
        ),
      );
}
