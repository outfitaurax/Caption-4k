import 'package:material_ui/material_ui.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_tokens.dart';
import '../../../domain/analytics.dart';
import '../../../shared/charts/percent_bar.dart';
import 'analytics_widgets.dart';
import 'platform_style.dart';

/// Shows how many captions of [category] went to each platform.
Future<void> showCategorySheet(
  BuildContext context,
  AnalyticsSummary summary,
  ContentCategory category,
) {
  final c = context.colors;
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    backgroundColor: c.card,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(AppRadius.card)),
    ),
    builder: (_) => _CategorySheet(summary: summary, category: category),
  );
}

class _CategorySheet extends StatelessWidget {
  const _CategorySheet({required this.summary, required this.category});
  final AnalyticsSummary summary;
  final ContentCategory category;

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    final counts = summary.platformsByCategory[category] ?? const <SocialPlatform, int>{};
    final total = counts.values.fold(0, (a, b) => a + b);
    final rows = [...SocialPlatform.values]
      ..sort((a, b) => (counts[b] ?? 0).compareTo(counts[a] ?? 0));
    final used = rows.where((p) => (counts[p] ?? 0) > 0).length;
    final periodName = switch (summary.period) {
      AnalyticsPeriod.daily => 'Today',
      AnalyticsPeriod.weekly => 'This week',
      AnalyticsPeriod.monthly => 'This month',
    };
    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(20, 20, 20, 24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text(
                  category.label,
                  style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700)
                      .copyWith(color: c.text),
                ),
                const Spacer(),
                Text(periodName, style: AppText.caption.copyWith(color: c.textSecondary)),
              ],
            ),
            const SizedBox(height: 4),
            Text(
              '$total captions across $used platforms',
              style: AppText.caption.copyWith(color: c.textSecondary),
            ),
            for (final p in rows)
              Padding(
                padding: const EdgeInsets.only(top: 16),
                child: Column(
                  children: [
                    Row(
                      children: [
                        ColorDot(p.color(c)),
                        const SizedBox(width: 8),
                        Expanded(child: Text(p.label, style: AppText.body.copyWith(color: c.text))),
                        Text(
                          '${counts[p] ?? 0}',
                          style: AppText.body.copyWith(fontWeight: FontWeight.w700, color: c.text),
                        ),
                        Text(
                          ' captions \u00b7 ${total == 0 ? 0 : ((counts[p] ?? 0) * 100 / total).round()}%',
                          style: AppText.caption.copyWith(color: c.textSecondary),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    PercentBar(
                      fraction: total == 0 ? 0 : (counts[p] ?? 0) / total,
                      color: p.color(c),
                    ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }
}
