import 'package:characters/characters.dart';

/// Counts user-perceived characters (grapheme clusters), not UTF-16 units
/// or Unicode code points. A combined emoji such as a family emoji counts once.
int captionCharacterCount(String value) => value.characters.length;
