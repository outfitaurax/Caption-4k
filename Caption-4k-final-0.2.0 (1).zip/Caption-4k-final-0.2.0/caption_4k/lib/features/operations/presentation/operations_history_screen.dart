import 'package:material_ui/material_ui.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/app_colors.dart';
import '../../../domain/analytics.dart';
import '../data/processing_job.dart';
import '../data/processing_job_repository.dart';
import 'processing_job_detail.dart';
import '../../analytics/presentation/platform_style.dart';

class OperationsHistoryScreen extends ConsumerStatefulWidget {
  const OperationsHistoryScreen({super.key});

  @override
  ConsumerState<OperationsHistoryScreen> createState() =>
      _OperationsHistoryScreenState();
}

class _OperationsHistoryScreenState
    extends ConsumerState<OperationsHistoryScreen> {
  final _searchController = TextEditingController();
  String _filter = 'all';
  String _categoryFilter = 'all';

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  bool _matchesStatus(ProcessingJob job) => switch (_filter) {
        'completed' => job.status == JobStatus.completed,
        'failed' => job.status == JobStatus.failed,
        'cancelled' => job.status == JobStatus.cancelled,
        'waiting' => job.status.isActive,
        _ => true,
      };

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    final jobs = ref.watch(processingJobsProvider);
    final query = _searchController.text.trim().toLowerCase();
    return Scaffold(
      appBar: AppBar(title: const Text('Operations history')),
      body: jobs.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (_, __) => const Center(child: Text('Could not load operation history.')),
        data: (items) {
          final filtered = items.where((job) {
            final matchesQuery = query.isEmpty ||
                job.productName.toLowerCase().contains(query) ||
                job.platform.label.toLowerCase().contains(query) ||
                job.category.label.toLowerCase().contains(query);
            final matchesCategory = _categoryFilter == 'all' || job.category.name == _categoryFilter;
            return matchesQuery && matchesCategory && _matchesStatus(job);
          }).toList();
          return Column(children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
              child: TextField(
                controller: _searchController,
                onChanged: (_) => setState(() {}),
                decoration: InputDecoration(
                  hintText: 'Search product, category or platform',
                  prefixIcon: const Icon(Icons.search),
                  suffixIcon: query.isEmpty
                      ? null
                      : IconButton(
                          onPressed: () {
                            _searchController.clear();
                            setState(() {});
                          },
                          icon: const Icon(Icons.close),
                        ),
                  border: const OutlineInputBorder(),
                ),
              ),
            ),
            SizedBox(
              height: 46,
              child: ListView(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                scrollDirection: Axis.horizontal,
                children: [
                  for (final option in const [
                    ('all', 'All'),
                    ('waiting', 'Waiting'),
                    ('completed', 'Completed'),
                    ('failed', 'Failed'),
                    ('cancelled', 'Cancelled'),
                  ])
                    Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: ChoiceChip(
                        label: Text(option.$2),
                        selected: _filter == option.$1,
                        onSelected: (_) => setState(() => _filter = option.$1),
                      ),
                    ),
                ],
              ),
            ),
            SizedBox(
              height: 44,
              child: ListView(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                scrollDirection: Axis.horizontal,
                children: [
                  for (final category in ContentCategory.values)
                    Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: ChoiceChip(
                        label: Text(category.label),
                        selected: _categoryFilter == category.name,
                        onSelected: (_) => setState(() => _categoryFilter = category.name),
                      ),
                    ),
                  ChoiceChip(label: const Text('All categories'), selected: _categoryFilter == 'all', onSelected: (_) => setState(() => _categoryFilter = 'all')),
                ],
              ),
            ),
            Expanded(
              child: filtered.isEmpty
                  ? Center(
                      child: Text('No matching operations.',
                          style: TextStyle(color: c.textSecondary)),
                    )
                  : _buildDailyGroups(filtered, c),
            ),
          ]);
        },
      ),
    );
  }
  Widget _buildDailyGroups(List<ProcessingJob> jobs, AppColors colors) {
    final groups = <DateTime, List<ProcessingJob>>{};
    for (final job in jobs) {
      final date = job.createdAt.toLocal();
      final key = DateTime(date.year, date.month, date.day);
      (groups[key] ??= []).add(job);
    }
    final dates = groups.keys.toList()..sort((a, b) => b.compareTo(a));
    for (final dayJobs in groups.values) {
      dayJobs.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    }
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
      children: [
        for (final date in dates)
          _DailyHistoryCard(
            date: date,
            jobs: groups[date]!,
            colors: colors,
            onJobTap: (job) => showProcessingJobDetail(context, ref, job),
          ),
      ],
    );
  }

}


class _DailyHistoryCard extends StatelessWidget {
  const _DailyHistoryCard({
    required this.date,
    required this.jobs,
    required this.colors,
    required this.onJobTap,
  });

  final DateTime date;
  final List<ProcessingJob> jobs;
  final AppColors colors;
  final ValueChanged<ProcessingJob> onJobTap;

  /// The day header follows caption category, never operation status.
  /// A single-category day uses that category's approved accent. Mixed days
  /// stay neutral; each operation below carries its own category colour.
  Color _headerColor(AppColors colors) {
    final categories = jobs.map((job) => job.category).toSet();
    return categories.length == 1
        ? categoryColor(categories.first)
        : colors.card;
  }

  String get _dateLabel {
    const weekdays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    return '${weekdays[date.weekday - 1]}, ${date.day} ${months[date.month - 1]} ${date.year}';
  }

  String get _summary {
    final completed = jobs.where((job) => job.status == JobStatus.completed).length;
    final failed = jobs.where((job) => job.status == JobStatus.failed).length;
    final active = jobs.where((job) => job.status.isActive).length;
    final cancelled = jobs.where((job) => job.status == JobStatus.cancelled).length;
    final parts = <String>[];
    if (completed > 0) parts.add('$completed completed');
    if (active > 0) parts.add('$active active');
    if (failed > 0) parts.add('$failed failed');
    if (cancelled > 0) parts.add('$cancelled cancelled');
    return parts.isEmpty ? '${jobs.length} operations' : parts.join(' · ');
  }

  @override
  Widget build(BuildContext context) {
    final header = _headerColor(colors);
    final isSingleCategoryDay = jobs.map((job) => job.category).toSet().length == 1;
    // Pick a readable foreground for each category header. Bright orange
    // needs dark text; red, blue, and purple need white text for contrast.
    final headerTextColor = isSingleCategoryDay
        ? (header.computeLuminance() > 0.179
            ? const Color(0xFF151927)
            : Colors.white)
        : colors.text;
    return Card(
      clipBehavior: Clip.antiAlias,
      margin: const EdgeInsets.only(bottom: 14),
      child: Theme(
        data: Theme.of(context).copyWith(
          dividerColor: colors.border.withValues(alpha: 0.55),
          splashColor: Colors.transparent,
          highlightColor: Colors.transparent,
        ),
        child: ExpansionTile(
          initiallyExpanded: true,
          collapsedBackgroundColor: header,
          backgroundColor: header,
          collapsedIconColor: headerTextColor,
          iconColor: headerTextColor,
          tilePadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
          childrenPadding: EdgeInsets.zero,
          title: Row(
            children: [
              Expanded(
                child: Text(
                  _dateLabel,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: headerTextColor,
                    fontWeight: FontWeight.w700,
                    fontSize: 16,
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Flexible(
                child: Text(
                  _summary,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  textAlign: TextAlign.end,
                  style: TextStyle(
                    color: headerTextColor.withValues(alpha: 0.88),
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ],
          ),
          subtitle: Padding(
            padding: const EdgeInsets.only(top: 5),
            child: Text(
              '${jobs.length} operations',
              style: TextStyle(
                color: headerTextColor.withValues(alpha: 0.88),
                fontSize: 12,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          children: [
            for (var index = 0; index < jobs.length; index++) ...[
              if (index > 0) Divider(height: 1, color: colors.border),
              _HistoryJobTile(job: jobs[index], colors: colors, onTap: () => onJobTap(jobs[index])),
            ],
          ],
        ),
      ),
    );
  }
}

class _HistoryJobTile extends StatelessWidget {
  const _HistoryJobTile({
    required this.job,
    required this.colors,
    required this.onTap,
  });

  final ProcessingJob job;
  final AppColors colors;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final statusColor = switch (job.status) {
      JobStatus.completed => const Color(0xFF2EAD70),
      JobStatus.failed => const Color(0xFFE34D59),
      JobStatus.cancelled => colors.textSecondary,
      JobStatus.waitingForAi || JobStatus.queued => const Color(0xFFE39A2D),
      JobStatus.processing => const Color(0xFF3979D6),
    };
    final time = job.createdAt.toLocal();
    final hour = time.hour % 12 == 0 ? 12 : time.hour % 12;
    final minute = time.minute.toString().padLeft(2, '0');
    final period = time.hour >= 12 ? 'PM' : 'AM';
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 5),
      leading: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            job.status == JobStatus.completed
                ? Icons.check_circle
                : job.status == JobStatus.failed
                    ? Icons.error_outline
                    : job.status == JobStatus.cancelled
                        ? Icons.cancel_outlined
                        : Icons.schedule_outlined,
            color: statusColor,
            size: 22,
          ),
          const SizedBox(width: 7),
          Container(
            width: 5,
            height: 28,
            decoration: BoxDecoration(
              color: categoryColor(job.category),
              borderRadius: BorderRadius.circular(4),
            ),
          ),
        ],
      ),
      title: Text(job.productName, style: const TextStyle(fontWeight: FontWeight.w600)),
      subtitle: Text('${job.category.label} · ${job.platform.label} · ${job.status.label}'),
      trailing: Text(
        '$hour:$minute $period',
        style: TextStyle(color: colors.textSecondary, fontSize: 12),
      ),
      onTap: onTap,
    );
  }
}
