import 'package:material_ui/material_ui.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/app_colors.dart';
import '../../../shared/widgets/app_card.dart';
import '../data/processing_job.dart';
import '../data/processing_job_repository.dart';
import '../domain/caption_character_count.dart';

Future<void> showProcessingJobDetail(BuildContext context, WidgetRef ref, ProcessingJob job) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    builder: (sheetContext) => _ProcessingJobDetail(job: job),
  );
}

class _ProcessingJobDetail extends ConsumerWidget {
  const _ProcessingJobDetail({required this.job});
  final ProcessingJob job;

  String get _statusLabel => job.status.label;

  Future<void> _editCaption(BuildContext context, WidgetRef ref) async {
    final titleController = TextEditingController(text: job.captionTitle ?? '');
    final captionController = TextEditingController(text: job.caption ?? '');
    final result = await showDialog<({String title, String caption})>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: const Text('Edit title and caption'),
          content: SizedBox(
            width: 440,
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextField(
                    controller: titleController, autofocus: true, minLines: 1, maxLines: 2,
                    decoration: const InputDecoration(
                      labelText: 'Title', hintText: 'Enter the caption title separately',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 14),
                  TextField(
                    controller: captionController, minLines: 5, maxLines: 12,
                    onChanged: (_) => setDialogState(() {}),
                    decoration: const InputDecoration(
                      labelText: 'Full caption', hintText: 'Write or paste the complete caption here',
                      border: OutlineInputBorder(), alignLabelWithHint: true,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Align(
                    alignment: Alignment.centerRight,
                    child: Text(
                      'Characters: ${captionCharacterCount(captionController.text)} (spaces and punctuation included)',
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                  ),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Cancel')),
            FilledButton(
              onPressed: () => Navigator.pop(dialogContext, (
                title: titleController.text.trim(), caption: captionController.text.trim(),
              )),
              child: const Text('Save'),
            ),
          ],
        ),
      ),
    );
    titleController.dispose();
    captionController.dispose();
    if (result == null || result.caption.isEmpty) return;
    await ref.read(processingJobRepositoryProvider).saveCaption(
      job.id,
      result.caption,
      title: result.title,
      notify: false,
    );
    ref.invalidate(processingJobsProvider);
    if (context.mounted) Navigator.of(context).pop();
  }

  Future<void> _addCaptionInstruction(
    BuildContext context, WidgetRef ref, String mode) async {
    final controller = TextEditingController();
    final isExtend = mode == 'extend';
    final instruction = await showDialog<String>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(isExtend ? 'Extend current caption' : 'Regenerate caption'),
        content: SizedBox(
          width: 440,
          child: TextField(
            controller: controller,
            autofocus: true,
            minLines: 3,
            maxLines: 6,
            decoration: InputDecoration(
              labelText: 'New instructions',
              hintText: isExtend
                  ? 'Example: Add more details and increase the caption length without removing existing text.'
                  : 'Describe how you want the new caption to be written.',
              border: const OutlineInputBorder(),
              alignLabelWithHint: true,
            ),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Cancel')),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, controller.text.trim()),
            child: const Text('Save instructions'),
          ),
        ],
      ),
    );
    controller.dispose();
    if (instruction == null || instruction.isEmpty) return;
    await ref.read(processingJobRepositoryProvider).saveCaptionInstruction(
      job.id, mode: mode, instruction: instruction);
    ref.invalidate(processingJobsProvider);
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Instructions saved. AI generation will activate after Tout/backend integration.')),
      );
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final c = context.colors;
    final repository = ref.read(processingJobRepositoryProvider);
    Future<void> refresh() async {
      ref.invalidate(processingJobsProvider);
      if (context.mounted) Navigator.of(context).pop();
    }

    return SafeArea(
      child: Padding(
        padding: EdgeInsets.fromLTRB(20, 8, 20, 24 + MediaQuery.viewInsetsOf(context).bottom),
        child: ConstrainedBox(
          constraints: BoxConstraints(
            maxHeight: MediaQuery.sizeOf(context).height * 0.85,
          ),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
            Text(job.productName, style: Theme.of(context).textTheme.titleLarge?.copyWith(color: c.text, fontWeight: FontWeight.w700)),
            const SizedBox(height: 6),
            Text('${job.category.label} · ${job.platform.label}', style: TextStyle(color: c.textSecondary)),
            const SizedBox(height: 16),
            AppCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Task status', style: TextStyle(color: c.textSecondary, fontSize: 12)),
              const SizedBox(height: 5),
              Text(_statusLabel, style: TextStyle(color: c.text, fontWeight: FontWeight.w600)),
              const SizedBox(height: 8),
              Text('Created ${job.createdAt.toLocal()}', style: TextStyle(color: c.textSecondary, fontSize: 12)),
              if (job.startedAt != null) ...[
                const SizedBox(height: 5),
                Text('Started ${job.startedAt!.toLocal()}', style: TextStyle(color: c.textSecondary, fontSize: 12)),
              ],
              if (job.completedAt != null) ...[
                const SizedBox(height: 5),
                Text('Finished ${job.completedAt!.toLocal()}', style: TextStyle(color: c.textSecondary, fontSize: 12)),
              ],
              const SizedBox(height: 5),
              Text('Attempts started: ${job.attemptCount}', style: TextStyle(color: c.textSecondary, fontSize: 12)),
              if (job.processingDuration != null) ...[
                const SizedBox(height: 5),
                Text('Processing time: ${job.processingDuration!.inSeconds} sec', style: TextStyle(color: c.textSecondary, fontSize: 12)),
              ],
            ])),
            const SizedBox(height: 12),
            Text('Title', style: TextStyle(color: c.text, fontWeight: FontWeight.w600)),
            const SizedBox(height: 8),
            AppCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              SelectableText(
                job.captionTitle?.trim().isNotEmpty == true
                    ? job.captionTitle!
                    : 'No separate title has been added.',
                style: TextStyle(color: c.textSecondary, height: 1.45),
              ),
              if (job.captionTitle?.trim().isNotEmpty == true)
                Align(alignment: Alignment.centerRight, child: IconButton(
                  tooltip: 'Copy title',
                  onPressed: () => Clipboard.setData(ClipboardData(text: job.captionTitle!)),
                  icon: const Icon(Icons.copy, size: 18),
                )),
            ])),
            const SizedBox(height: 12),
            Text('Full caption', style: TextStyle(color: c.text, fontWeight: FontWeight.w600)),
            const SizedBox(height: 8),
            AppCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              SelectableText(
                job.caption?.trim().isNotEmpty == true
                    ? job.caption!
                    : 'No caption has been generated yet. AI and backend connection will be added in the final integration stage.',
                style: TextStyle(color: c.textSecondary, height: 1.45),
              ),
              if (job.caption?.trim().isNotEmpty == true)
                Align(alignment: Alignment.centerRight, child: TextButton.icon(
                  onPressed: () => Clipboard.setData(ClipboardData(text: job.caption!)),
                  icon: const Icon(Icons.copy, size: 16), label: const Text('Copy full caption'),
                )),
            ])),
            if (job.caption?.trim().isNotEmpty == true) ...[
              const SizedBox(height: 6),
              Align(
                alignment: Alignment.centerRight,
                child: Text(
                  'Characters: ${captionCharacterCount(job.caption!)} (including spaces and punctuation)',
                  style: TextStyle(color: c.textSecondary, fontSize: 12),
                ),
              ),
              const SizedBox(height: 12),
              Text('Improve this caption', style: TextStyle(color: c.text, fontWeight: FontWeight.w600)),
              const SizedBox(height: 8),
              Row(children: [
                Expanded(child: OutlinedButton.icon(
                  onPressed: () => _addCaptionInstruction(context, ref, 'extend'),
                  icon: const Icon(Icons.add, size: 18),
                  label: const Text('Extend caption'),
                )),
                const SizedBox(width: 8),
                Expanded(child: OutlinedButton.icon(
                  onPressed: () => _addCaptionInstruction(context, ref, 'regenerate'),
                  icon: const Icon(Icons.refresh, size: 18),
                  label: const Text('Regenerate'),
                )),
              ]),
              if (job.captionInstructions.isNotEmpty) ...[
                const SizedBox(height: 10),
                Text('Saved instructions', style: TextStyle(color: c.text, fontWeight: FontWeight.w600)),
                const SizedBox(height: 6),
                AppCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  for (final item in job.captionInstructions.reversed)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(item.mode == 'extend' ? 'Extend caption' : 'Regenerate caption',
                          style: TextStyle(color: c.text, fontWeight: FontWeight.w600)),
                        const SizedBox(height: 3),
                        Text(item.instruction, style: TextStyle(color: c.textSecondary)),
                        Text(item.createdAt.toLocal().toString(),
                          style: TextStyle(color: c.textSecondary, fontSize: 11)),
                      ]),
                    ),
                ])),
              ],
            ],
            if (job.captionVersions.isNotEmpty) ...[
              const SizedBox(height: 12),
              Text('Caption version history', style: TextStyle(color: c.text, fontWeight: FontWeight.w600)),
              const SizedBox(height: 8),
              AppCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                for (final version in job.captionVersions.reversed)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Row(children: [
                        Expanded(child: Text('Version ${version.number}', style: TextStyle(color: c.text, fontWeight: FontWeight.w600))),
                        TextButton.icon(
                          onPressed: () => Clipboard.setData(ClipboardData(text: version.caption)),
                          icon: const Icon(Icons.copy, size: 14), label: const Text('Copy'),
                        ),
                      ]),
                      if (version.title?.isNotEmpty == true) Text(version.title!, style: TextStyle(color: c.textSecondary, fontWeight: FontWeight.w600)),
                      Text(version.caption, maxLines: 4, overflow: TextOverflow.ellipsis, style: TextStyle(color: c.textSecondary)),
                      Text('${version.createdAt.toLocal()} · ${captionCharacterCount(version.caption)} characters', style: TextStyle(color: c.textSecondary, fontSize: 11)),
                    ]),
                  ),
              ])),
            ],
            if (job.errorMessage?.isNotEmpty == true) ...[
              const SizedBox(height: 8),
              Text(job.errorMessage!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
            ],
            if (job.attempts.isNotEmpty) ...[
              const SizedBox(height: 12),
              Text('Attempt history', style: TextStyle(color: c.text, fontWeight: FontWeight.w600)),
              const SizedBox(height: 8),
              AppCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                for (final a in job.attempts.reversed)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: Text(
                      'Attempt ${a.number}: ${a.result}${a.message == null ? '' : ' - ${a.message}'}\n${a.startedAt.toLocal()} to ${a.finishedAt?.toLocal() ?? 'unfinished'}',
                      style: TextStyle(color: c.textSecondary, height: 1.4),
                    ),
                  ),
              ])),
            ],
            const SizedBox(height: 8),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: () => _editCaption(context, ref),
                icon: const Icon(Icons.edit_outlined, size: 18),
                label: Text(job.caption == null ? 'Add title and caption manually' : 'Edit title and caption'),
              ),
            ),
            const SizedBox(height: 12),
            Row(children: [
              if (job.status.isActive)
                Expanded(child: OutlinedButton(onPressed: () async { await repository.updateStatus(job.id, JobStatus.cancelled); await refresh(); }, child: const Text('Cancel task'))),
              if (job.status == JobStatus.failed || job.status == JobStatus.cancelled) ...[
                Expanded(child: OutlinedButton(onPressed: () async { await repository.updateStatus(job.id, JobStatus.waitingForAi); await refresh(); }, child: const Text('Retry later'))),
              ],
              if (job.status == JobStatus.completed)
                Expanded(child: OutlinedButton(onPressed: () => Navigator.of(context).pop(), child: const Text('Close'))),
            ]),
              ],
            ),
          ),
        ),
      ),
    );
  }
}


/// Destination opened when the user taps a local operation notification.
class ProcessingJobNotificationScreen extends ConsumerWidget {
  const ProcessingJobNotificationScreen({super.key, required this.jobId});
  final String jobId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final jobs = ref.watch(processingJobsProvider);
    final c = context.colors;
    return Scaffold(
      appBar: AppBar(title: const Text('Operation details')),
      body: jobs.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (_, __) => const Center(child: Text('Could not load this operation.')),
        data: (items) {
          final matches = items.where((item) => item.id == jobId);
          if (matches.isEmpty) {
            return const Center(child: Text('This operation is no longer available.'));
          }
          final job = matches.first;
          return ListView(padding: const EdgeInsets.all(20), children: [
            Text(job.productName, style: Theme.of(context).textTheme.headlineSmall?.copyWith(color: c.text, fontWeight: FontWeight.w700)),
            const SizedBox(height: 6),
            Text('${job.category.label} · ${job.platform.label}', style: TextStyle(color: c.textSecondary)),
            const SizedBox(height: 18),
            AppCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Status: ${job.status.label}', style: TextStyle(color: c.text, fontWeight: FontWeight.w600)),
              const SizedBox(height: 8),
              Text('Created: ${job.createdAt.toLocal()}', style: TextStyle(color: c.textSecondary)),
              if (job.completedAt != null) Text('Finished: ${job.completedAt!.toLocal()}', style: TextStyle(color: c.textSecondary)),
            ])),
            const SizedBox(height: 14),
            Text('Title', style: Theme.of(context).textTheme.titleMedium?.copyWith(color: c.text)),
            const SizedBox(height: 8),
            AppCard(child: SelectableText(
              job.captionTitle?.trim().isNotEmpty == true ? job.captionTitle! : 'No separate title has been added.',
              style: TextStyle(color: c.textSecondary, height: 1.5),
            )),
            if (job.captionTitle?.trim().isNotEmpty == true)
              Align(alignment: Alignment.centerRight, child: TextButton.icon(
                onPressed: () => Clipboard.setData(ClipboardData(text: job.captionTitle!)),
                icon: const Icon(Icons.copy, size: 16), label: const Text('Copy title'),
              )),
            Text('Full caption', style: Theme.of(context).textTheme.titleMedium?.copyWith(color: c.text)),
            const SizedBox(height: 8),
            AppCard(child: SelectableText(
              job.caption?.trim().isNotEmpty == true
                  ? job.caption!
                  : 'No caption result is available for this operation.',
              style: TextStyle(color: c.textSecondary, height: 1.5),
            )),
            if (job.caption?.trim().isNotEmpty == true)
              Padding(
                padding: const EdgeInsets.only(top: 6),
                child: Align(
                  alignment: Alignment.centerRight,
                  child: Text('Characters: ${captionCharacterCount(job.caption!)} (including spaces and punctuation)',
                    style: TextStyle(color: c.textSecondary, fontSize: 12)),
                ),
              ),
            if (job.errorMessage?.trim().isNotEmpty == true) ...[
              const SizedBox(height: 12),
              Text('Operation error', style: Theme.of(context).textTheme.titleMedium?.copyWith(color: c.text)),
              const SizedBox(height: 8),
              AppCard(child: SelectableText(
                job.errorMessage!,
                style: TextStyle(color: Theme.of(context).colorScheme.error, height: 1.5),
              )),
            ],
            if (job.caption?.trim().isNotEmpty == true)
              Align(alignment: Alignment.centerRight, child: TextButton.icon(
                onPressed: () => Clipboard.setData(ClipboardData(text: job.caption!)),
                icon: const Icon(Icons.copy, size: 16), label: const Text('Copy full caption'),
              )),
          ]);
        },
      ),
    );
  }
}
