import 'dart:convert';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../../core/storage/preferences.dart';
import '../../../core/notifications/local_notification_service.dart';
import '../../upload/data/product.dart';
import 'processing_job.dart';
import 'waiting_job_expiry.dart';

class ProcessingJobRepository {
  ProcessingJobRepository(Ref ref)
      : _prefs = ref.read(sharedPreferencesProvider),
        _notifications = ref.read(localNotificationServiceProvider);
  final SharedPreferences _prefs;
  final LocalNotificationService _notifications;
  static const _key = 'caption4k_processing_jobs_v1';

  Future<List<ProcessingJob>> getAll() async {
    final raw = _prefs.getString(_key);
    if (raw == null || raw.isEmpty) return [];
    try {
      final jobs = (jsonDecode(raw) as List)
          .map((e) => ProcessingJob.fromJson(e as Map<String, dynamic>)).toList();
      jobs.sort((a, b) => b.createdAt.compareTo(a.createdAt));
      return jobs;
    } catch (_) {
      if (!_prefs.containsKey('${_key}_corrupt_backup')) {
        await _prefs.setString('${_key}_corrupt_backup', raw);
      }
      return [];
    }
  }

  Future<List<ProcessingJob>> getForMonth(DateTime month) async {
    final jobs = await getAll();
    return jobs.where((job) => job.createdAt.year == month.year && job.createdAt.month == month.month).toList();
  }

  Future<void> _write(List<ProcessingJob> jobs) =>
      _prefs.setString(_key, jsonEncode(jobs.map((e) => e.toJson()).toList()));

  String _fingerprint(Product product) => jsonEncode({
    'name': product.name.trim(),
    'description': product.description.trim(),
    'specialInstructions': product.specialInstructions.trim(),
    'category': product.category.name,
    'images': product.imagePaths,
  });

  Future<void> createForProduct(Product product, {Product? previousProduct}) async {
    final jobs = await getAll();
    final selectedPlatforms = product.platforms.toSet();
    final fingerprint = _fingerprint(product);

    // A platform removed before work starts cancels its pending operation;
    // keep the cancellation in history instead of silently deleting it.
    final removedAt = DateTime.now();
    for (var i = 0; i < jobs.length; i++) {
      final job = jobs[i];
      if (job.productId == product.id &&
          (job.status == JobStatus.waitingForAi || job.status == JobStatus.queued) &&
          !selectedPlatforms.contains(job.platform)) {
        jobs[i] = job.cancelledWithReason(
          'Cancelled because this platform was removed from the product.', removedAt);
      }
    }

    for (final platform in selectedPlatforms) {
      final related = jobs.where((job) =>
          job.productId == product.id && job.platform == platform).toList()
        ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
      final latest = related.isEmpty ? null : related.first;

      if (latest != null &&
          (latest.status == JobStatus.waitingForAi || latest.status == JobStatus.queued)) {
        final index = jobs.indexWhere((job) => job.id == latest.id);
        jobs[index] = latest.copyWith(
          productName: product.name,
          category: product.category,
          sourceFingerprint: fingerprint,
        );
        continue;
      }

      // Avoid duplicate jobs when a product is saved without content changes.
      // A changed name/description/instructions/category/image set creates a new operation
      // while retaining the previous result as history.
      if (latest != null) {
        // Legacy jobs have no fingerprint, so treat their content as unknown
        // and create one refreshed operation. Subsequent saves are deduplicated.
        final wasPreviouslySelected = previousProduct == null ||
            previousProduct.platforms.contains(platform);
        final sameContent = latest.sourceFingerprint == fingerprint;
        if (sameContent && wasPreviouslySelected) continue;
      }

      final createdAt = DateTime.now();
      final id = '${product.id}_${platform.name}_${createdAt.microsecondsSinceEpoch}';
      jobs.insert(0, ProcessingJob(
        id: id,
        productId: product.id,
        productName: product.name,
        category: product.category,
        platform: platform,
        status: JobStatus.waitingForAi,
        createdAt: createdAt,
        sourceFingerprint: fingerprint,
      ));
    }
    await _write(jobs);
  }

  /// Cancel work that has not started when a product is deleted. A genuinely
  /// processing job remains available until its worker finishes, so its image
  /// files can stay protected by the detached-image owner index.
  Future<void> deleteForProduct(String productId) async {
    final jobs = await getAll();
    final now = DateTime.now();
    for (var i = 0; i < jobs.length; i++) {
      final job = jobs[i];
      if (job.productId != productId) continue;
      if (job.status == JobStatus.waitingForAi || job.status == JobStatus.queued) {
        jobs[i] = job.cancelledWithReason(
          'Cancelled because the product was deleted.', now);
      }
    }
    await _write(jobs);
  }

  /// Cancels operations that waited longer than 30 days for the AI connection.
  Future<int> expireWaitingJobs({DateTime? now}) =>
      expireStaleWaitingJobs(_prefs, now: now);

  Future<void> delete(String id) async {
    final jobs = await getAll();
    final index = jobs.indexWhere((job) => job.id == id);
    if (index < 0) return;
    final job = jobs[index];
    // Never drop a processing record: its detached images may still be in use.
    if (job.status == JobStatus.processing) return;
    if (job.status == JobStatus.waitingForAi || job.status == JobStatus.queued) {
      jobs[index] = job.cancelledWithReason(
        'Removed from the queue by the user.', DateTime.now());
    } else {
      jobs.removeAt(index);
    }
    await _write(jobs);
  }

  Future<void> _update(String id, ProcessingJob Function(ProcessingJob) transform) async {
    final jobs = await getAll();
    final index = jobs.indexWhere((job) => job.id == id);
    if (index < 0) return;
    jobs[index] = transform(jobs[index]);
    await _write(jobs);
  }

  ProcessingJob _beginProcessing(ProcessingJob job) {
    if (job.status != JobStatus.waitingForAi && job.status != JobStatus.queued) {
      return job;
    }
    final now = DateTime.now();
    final waitingSince = job.attemptStartedAt ?? job.createdAt;
    if (waitingSince.isBefore(now.subtract(maxWaitingForAi))) {
      return job.cancelledWithReason(
        'Cancelled automatically: waited more than ${maxWaitingForAi.inDays} days for the AI connection.',
        now,
      );
    }
    return job.copyWith(
      status: JobStatus.processing,
      startedAt: now,
      attemptStartedAt: now,
      attemptCount: job.attemptCount + 1,
      clearCompletedAt: true,
      clearCaptionTitle: true,
      clearCaption: true,
      clearError: true,
    );
  }

  /// Mark a queued/waiting operation as actively processing and begin one
  /// real attempt. Repeated calls while already processing are idempotent.
  Future<void> start(String id) => _update(id, _beginProcessing);

  Future<void> updateStatus(String id, JobStatus status) => _update(id, (job) {
    if (status == JobStatus.processing) return _beginProcessing(job);


    if (status == JobStatus.queued) {
      if (job.status != JobStatus.waitingForAi) return job;
      return job.copyWith(status: JobStatus.queued);
    }

    if (status == JobStatus.cancelled) {
      if (!job.status.isActive) return job;
      return job.cancelledWithReason('Cancelled by you.', DateTime.now());
    }

    if (status == JobStatus.failed) {
      if (!job.status.isActive) return job;
      final now = DateTime.now();
      final base = job.withAttempt('failed', message: job.errorMessage, at: now);
      return base.copyWith(status: status, completedAt: now, clearAttemptStartedAt: true);
    }

    if (status == JobStatus.waitingForAi) {
      if (job.status != JobStatus.failed && job.status != JobStatus.cancelled) {
        return job;
      }
      return job.copyWith(
        status: status,
        clearStartedAt: true,
        clearCompletedAt: true,
        clearCaptionTitle: true,
        clearCaption: true,
        clearError: true,
        attemptStartedAt: DateTime.now(),
      );
    }

    return job.copyWith(status: status);
  });

  Future<void> saveCaption(String id, String caption, {String? title, bool notify = true}) async {
    if (caption.trim().isEmpty) throw ArgumentError.value(caption, 'caption', 'Caption cannot be empty.');
    await _update(id, (job) {
      final now = DateTime.now();
      final cleanTitle = title?.trim();
      final changed = job.caption != caption ||
          (title != null && job.captionTitle != cleanTitle);
      final versions = [...job.captionVersions];
      if (changed) {
        // Migrate legacy captions into the revision history before replacing them.
        if (job.caption?.trim().isNotEmpty == true && versions.isEmpty) {
          versions.add(CaptionVersion(
            id: '${job.id}_v1', number: 1, caption: job.caption!,
            title: job.captionTitle, createdAt: job.completedAt ?? job.createdAt,
          ));
        }
        versions.add(CaptionVersion(
          id: '${job.id}_v${versions.length + 1}_${now.microsecondsSinceEpoch}',
          number: versions.length + 1, caption: caption,
          title: cleanTitle, createdAt: now,
          changeType: job.caption == null ? 'saved' : 'edited',
        ));
      }
      if (job.status == JobStatus.completed) {
        return job.copyWith(
          captionTitle: cleanTitle, caption: caption,
          clearCaptionTitle: title != null && cleanTitle!.isEmpty,
          clearError: true, captionVersions: versions,
        );
      }
      return job.withAttempt('completed', at: now).copyWith(
        status: JobStatus.completed, captionTitle: cleanTitle, caption: caption,
        clearCaptionTitle: title != null && cleanTitle!.isEmpty,
        completedAt: now, clearError: true, clearAttemptStartedAt: true,
        captionVersions: versions,
      );
    });
    ProcessingJob? job;
    for (final item in await getAll()) { if (item.id == id) { job = item; break; } }
    if (notify && job != null) {
      await _notifications.showJobCompleted(
        jobId: job.id, productName: job.productName, platform: job.platform.label);
    }
  }

  Future<void> saveCaptionInstruction(
    String id, {required String mode, required String instruction}) async {
    final cleaned = instruction.trim();
    if (cleaned.isEmpty) {
      throw ArgumentError.value(instruction, 'instruction', 'Instruction cannot be empty.');
    }
    if (mode != 'extend' && mode != 'regenerate') {
      throw ArgumentError.value(mode, 'mode', 'Unsupported caption instruction mode.');
    }
    await _update(id, (job) => job.copyWith(
      captionInstructions: [
        ...job.captionInstructions,
        CaptionInstruction(
          id: DateTime.now().microsecondsSinceEpoch.toString(),
          mode: mode,
          instruction: cleaned,
          createdAt: DateTime.now(),
        ),
      ],
    ));
  }

  Future<void> saveFailure(String id, String message) async {
    await _update(id, (job) {
      if (job.status == JobStatus.completed ||
          job.status == JobStatus.failed ||
          job.status == JobStatus.cancelled) {
        return job;
      }
      final now = DateTime.now();
      return job.withAttempt('failed', message: message, at: now).copyWith(
        status: JobStatus.failed,
        errorMessage: message,
        completedAt: now,
        clearAttemptStartedAt: true,
      );
    });
    ProcessingJob? job;
    for (final item in await getAll()) { if (item.id == id) { job = item; break; } }
    if (job != null && job.status == JobStatus.failed) {
      await _notifications.showJobFailed(
        jobId: job.id, productName: job.productName, platform: job.platform.label);
    }
  }
}

final processingJobRepositoryProvider = Provider<ProcessingJobRepository>((ref) => ProcessingJobRepository(ref));
final processingJobsProvider = FutureProvider<List<ProcessingJob>>((ref) => ref.watch(processingJobRepositoryProvider).getAll());
