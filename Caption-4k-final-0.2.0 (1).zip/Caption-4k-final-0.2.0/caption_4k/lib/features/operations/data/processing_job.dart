import '../../../domain/analytics.dart';

enum JobStatus { waitingForAi, queued, processing, completed, failed, cancelled }

extension JobStatusLabel on JobStatus {
  /// Work that has not finished and may still need its product images.
  bool get isActive =>
      this == JobStatus.waitingForAi ||
      this == JobStatus.queued ||
      this == JobStatus.processing;

  String get label => switch (this) {
        JobStatus.waitingForAi => 'Waiting for AI connection',
        JobStatus.queued => 'Queued',
        JobStatus.processing => 'Processing',
        JobStatus.completed => 'Completed',
        JobStatus.failed => 'Failed',
        JobStatus.cancelled => 'Cancelled',
      };
}

/// One recorded run of an operation. Never overwritten; retries add new entries.
class JobAttempt {
  const JobAttempt({
    required this.number,
    required this.startedAt,
    required this.result,
    this.finishedAt,
    this.message,
  });

  final int number;
  final DateTime startedAt;
  final DateTime? finishedAt;
  final String result; // completed | failed | cancelled
  final String? message;

  Map<String, Object?> toJson() => {
    'number': number,
    'startedAt': startedAt.toIso8601String(),
    'finishedAt': finishedAt?.toIso8601String(),
    'result': result,
    'message': message,
  };

  factory JobAttempt.fromJson(Map<String, dynamic> json) => JobAttempt(
    number: (json['number'] as num?)?.toInt() ?? 1,
    startedAt: DateTime.tryParse(json['startedAt'] as String? ?? '') ?? DateTime.now(),
    finishedAt: DateTime.tryParse(json['finishedAt'] as String? ?? ''),
    result: json['result'] as String? ?? 'unknown',
    message: json['message'] as String?,
  );
}


/// A user instruction saved against an existing caption. The AI action is
/// intentionally deferred until the Tout/backend integration is available.
class CaptionInstruction {
  const CaptionInstruction({
    required this.id,
    required this.mode,
    required this.instruction,
    required this.createdAt,
  });

  final String id;
  /// `extend` adds to the current caption; `regenerate` requests a new version.
  final String mode;
  final String instruction;
  final DateTime createdAt;

  Map<String, Object?> toJson() => {
    'id': id,
    'mode': mode,
    'instruction': instruction,
    'createdAt': createdAt.toIso8601String(),
  };

  factory CaptionInstruction.fromJson(Map<String, dynamic> json) => CaptionInstruction(
    id: json['id'] as String? ?? DateTime.now().microsecondsSinceEpoch.toString(),
    mode: json['mode'] as String? ?? 'extend',
    instruction: json['instruction'] as String? ?? '',
    createdAt: DateTime.tryParse(json['createdAt'] as String? ?? '') ?? DateTime.now(),
  );
}


/// Immutable saved caption revision. Older revisions are never overwritten.
class CaptionVersion {
  const CaptionVersion({
    required this.id,
    required this.number,
    required this.caption,
    required this.createdAt,
    this.title,
    this.changeType = 'saved',
  });

  final String id;
  final int number;
  final String caption;
  final DateTime createdAt;
  final String? title;
  /// saved | edited | extend_requested | regenerate_requested
  final String changeType;

  Map<String, Object?> toJson() => {
    'id': id, 'number': number, 'caption': caption,
    'createdAt': createdAt.toIso8601String(), 'title': title,
    'changeType': changeType,
  };

  factory CaptionVersion.fromJson(Map<String, dynamic> json) => CaptionVersion(
    id: json['id'] as String? ?? DateTime.now().microsecondsSinceEpoch.toString(),
    number: (json['number'] as num?)?.toInt() ?? 1,
    caption: json['caption'] as String? ?? '',
    createdAt: DateTime.tryParse(json['createdAt'] as String? ?? '') ?? DateTime.now(),
    title: json['title'] as String?,
    changeType: json['changeType'] as String? ?? 'saved',
  );
}

class ProcessingJob {
  const ProcessingJob({
    required this.id,
    required this.productId,
    required this.productName,
    required this.category,
    required this.platform,
    required this.status,
    required this.createdAt,
    this.startedAt,
    this.completedAt,
    this.captionTitle,
    this.caption,
    this.errorMessage,
    this.attemptCount = 0,
    this.sourceFingerprint,
    this.attempts = const [],
    this.attemptStartedAt,
    this.captionInstructions = const [],
    this.captionVersions = const [],
  });

  final String id;
  final String productId;
  final String productName;
  final ContentCategory category;
  final SocialPlatform platform;
  final JobStatus status;
  final DateTime createdAt;
  final DateTime? startedAt;
  final DateTime? completedAt;
  /// Optional standalone title returned or entered separately from the full caption.
  final String? captionTitle;
  final String? caption;
  final String? errorMessage;
  final int attemptCount;
  /// Fingerprint of the product content used to create this operation.
  /// Null for operations saved by older app versions.
  final String? sourceFingerprint;
  /// Completed, failed, or cancelled attempts, oldest first.
  final List<JobAttempt> attempts;
  /// When the current attempt began (creation time, or the last retry).
  final DateTime? attemptStartedAt;
  /// Separate post-generation instructions; never mixed with Upload instructions.
  final List<CaptionInstruction> captionInstructions;
  /// Immutable local history of saved caption revisions, oldest first.
  final List<CaptionVersion> captionVersions;

  /// Adds the current attempt to the history with its [result].
  ProcessingJob withAttempt(String result, {String? message, DateTime? at}) {
    final number = attemptCount > attempts.length
        ? attemptCount
        : attempts.length + 1;
    return copyWith(
      attempts: [
        ...attempts,
        JobAttempt(
          number: number,
          startedAt: attemptStartedAt ?? startedAt ?? createdAt,
          finishedAt: at ?? DateTime.now(),
          result: result,
          message: message,
        ),
      ],
      attemptCount: number,
    );
  }


  /// Cancels this job and records [reason] in both the job and its history.
  ProcessingJob cancelledWithReason(String reason, DateTime at) {
    // A waiting/queued item has not started a real attempt. Preserve the
    // cancellation reason without inflating attemptCount or attempts.
    if (status == JobStatus.waitingForAi || status == JobStatus.queued) {
      return copyWith(
        status: JobStatus.cancelled,
        errorMessage: reason,
        completedAt: at,
        clearAttemptStartedAt: true,
      );
    }
    return withAttempt('cancelled', message: reason, at: at).copyWith(
      status: JobStatus.cancelled,
      errorMessage: reason,
      completedAt: at,
      clearAttemptStartedAt: true,
    );
  }

  Duration? get processingDuration => startedAt == null || completedAt == null
      ? null
      : completedAt!.difference(startedAt!);

  ProcessingJob copyWith({
    JobStatus? status,
    String? captionTitle,
    String? caption,
    String? errorMessage,
    DateTime? startedAt,
    DateTime? completedAt,
    int? attemptCount,
    String? productName,
    ContentCategory? category,
    String? sourceFingerprint,
    List<JobAttempt>? attempts,
    DateTime? attemptStartedAt,
    bool clearCaptionTitle = false,
    bool clearCaption = false,
    bool clearError = false,
    bool clearStartedAt = false,
    bool clearCompletedAt = false,
    bool clearAttemptStartedAt = false,
    List<CaptionInstruction>? captionInstructions,
    List<CaptionVersion>? captionVersions,
  }) => ProcessingJob(
    id: id,
    productId: productId,
    productName: productName ?? this.productName,
    category: category ?? this.category,
    platform: platform,
    status: status ?? this.status,
    createdAt: createdAt,
    startedAt: clearStartedAt ? null : (startedAt ?? this.startedAt),
    completedAt: clearCompletedAt ? null : (completedAt ?? this.completedAt),
    captionTitle: clearCaptionTitle ? null : (captionTitle ?? this.captionTitle),
    caption: clearCaption ? null : (caption ?? this.caption),
    errorMessage: clearError ? null : (errorMessage ?? this.errorMessage),
    attemptCount: attemptCount ?? this.attemptCount,
    sourceFingerprint: sourceFingerprint ?? this.sourceFingerprint,
    attempts: attempts ?? this.attempts,
    attemptStartedAt: clearAttemptStartedAt
        ? null
        : (attemptStartedAt ?? this.attemptStartedAt),
    captionInstructions: captionInstructions ?? this.captionInstructions,
    captionVersions: captionVersions ?? this.captionVersions,
  );

  Map<String, Object?> toJson() => {
    'id': id,
    'productId': productId,
    'productName': productName,
    'category': category.name,
    'platform': platform.name,
    'status': status.name,
    'createdAt': createdAt.toIso8601String(),
    'startedAt': startedAt?.toIso8601String(),
    'completedAt': completedAt?.toIso8601String(),
    'captionTitle': captionTitle,
    'caption': caption,
    'errorMessage': errorMessage,
    'attemptCount': attemptCount,
    'sourceFingerprint': sourceFingerprint,
    'attempts': attempts.map((a) => a.toJson()).toList(),
    'attemptStartedAt': attemptStartedAt?.toIso8601String(),
    'captionInstructions': captionInstructions.map((e) => e.toJson()).toList(),
    'captionVersions': captionVersions.map((e) => e.toJson()).toList(),
  };

  factory ProcessingJob.fromJson(Map<String, dynamic> json) => ProcessingJob(
    id: json['id'] as String,
    productId: json['productId'] as String,
    productName: json['productName'] as String,
    category: ContentCategory.values.firstWhere(
      (e) => e.name == json['category'], orElse: () => ContentCategory.outfit),
    platform: SocialPlatform.values.firstWhere(
      (e) => e.name == json['platform'], orElse: () => SocialPlatform.instagram),
    status: JobStatus.values.firstWhere(
      (e) => e.name == json['status'], orElse: () => JobStatus.waitingForAi),
    createdAt: DateTime.tryParse(json['createdAt'] as String? ?? '') ?? DateTime.now(),
    startedAt: DateTime.tryParse(json['startedAt'] as String? ?? ''),
    completedAt: DateTime.tryParse(json['completedAt'] as String? ?? ''),
    captionTitle: json['captionTitle'] as String?,
    caption: json['caption'] as String?,
    errorMessage: json['errorMessage'] as String?,
    attemptCount: (json['attemptCount'] as num?)?.toInt() ?? 0,
    sourceFingerprint: json['sourceFingerprint'] as String?,
    attempts: ((json['attempts'] as List?) ?? const [])
        .whereType<Map>()
        .map((e) => JobAttempt.fromJson(Map<String, dynamic>.from(e)))
        .toList(),
    attemptStartedAt: DateTime.tryParse(json['attemptStartedAt'] as String? ?? ''),
    captionInstructions: ((json['captionInstructions'] as List?) ?? const [])
        .whereType<Map>()
        .map((e) => CaptionInstruction.fromJson(Map<String, dynamic>.from(e)))
        .toList(),
    captionVersions: ((json['captionVersions'] as List?) ?? const [])
        .whereType<Map>()
        .map((e) => CaptionVersion.fromJson(Map<String, dynamic>.from(e)))
        .toList(),
  );
}
