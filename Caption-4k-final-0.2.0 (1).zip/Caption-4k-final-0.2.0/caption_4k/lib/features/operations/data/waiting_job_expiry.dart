import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import 'processing_job.dart';

const processingJobsStorageKey = 'caption4k_processing_jobs_v1';

/// Longest time an operation may wait for the AI connection.
const maxWaitingForAi = Duration(days: 30);

/// Cancels operations that waited longer than [maxWait] and records why.
/// Operations that are actually processing are never touched.
/// Returns how many operations were cancelled.
Future<int> expireStaleWaitingJobs(
  SharedPreferences prefs, {
  DateTime? now,
  Duration maxWait = maxWaitingForAi,
}) async {
  try {
    final raw = prefs.getString(processingJobsStorageKey);
    if (raw == null || raw.isEmpty) return 0;
    final jobs = (jsonDecode(raw) as List)
        .map((e) => ProcessingJob.fromJson(e as Map<String, dynamic>))
        .toList();
    final time = now ?? DateTime.now();
    final cutoff = time.subtract(maxWait);
    var cancelled = 0;
    for (var i = 0; i < jobs.length; i++) {
      final job = jobs[i];
      final waiting =
          job.status == JobStatus.waitingForAi || job.status == JobStatus.queued;
      if (!waiting) continue;
      final since = job.attemptStartedAt ?? job.createdAt;
      if (!since.isBefore(cutoff)) continue;
      jobs[i] = job.cancelledWithReason(
        'Cancelled automatically: waited more than ${maxWait.inDays} days for the AI connection.',
        time,
      );
      cancelled++;
    }
    if (cancelled == 0) return 0;
    await prefs.setString(
      processingJobsStorageKey,
      jsonEncode(jobs.map((j) => j.toJson()).toList()),
    );
    return cancelled;
  } catch (_) {
    // Unreadable job data is left untouched; the repository keeps a backup.
    return 0;
  }
}
