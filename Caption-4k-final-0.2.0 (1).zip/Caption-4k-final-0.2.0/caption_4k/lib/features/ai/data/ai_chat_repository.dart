import 'dart:convert';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../../core/storage/preferences.dart';

class AiChatMessage {
  const AiChatMessage({required this.text, required this.role, required this.createdAt});
  final String text;
  final String role;
  final DateTime createdAt;
  Map<String, Object?> toJson() => {'text': text, 'role': role, 'createdAt': createdAt.toIso8601String()};
  factory AiChatMessage.fromJson(Map<String, dynamic> json) => AiChatMessage(
    text: json['text'] as String? ?? '', role: json['role'] as String? ?? 'user',
    createdAt: DateTime.tryParse(json['createdAt'] as String? ?? '') ?? DateTime.now());
}

class AiChatConversation {
  const AiChatConversation({required this.id, required this.title, required this.createdAt, required this.updatedAt, this.messages = const []});
  final String id;
  final String title;
  final DateTime createdAt;
  final DateTime updatedAt;
  final List<AiChatMessage> messages;
  Map<String, Object?> toJson() => {'id': id, 'title': title, 'createdAt': createdAt.toIso8601String(), 'updatedAt': updatedAt.toIso8601String(), 'messages': messages.map((e) => e.toJson()).toList()};
  factory AiChatConversation.fromJson(Map<String, dynamic> json) => AiChatConversation(
    id: json['id'] as String, title: json['title'] as String? ?? 'New chat',
    createdAt: DateTime.tryParse(json['createdAt'] as String? ?? '') ?? DateTime.now(),
    updatedAt: DateTime.tryParse(json['updatedAt'] as String? ?? '') ?? DateTime.now(),
    messages: (json['messages'] as List? ?? const []).whereType<Map>().map((e) => AiChatMessage.fromJson(Map<String, dynamic>.from(e))).toList());
}

class AiChatRepository {
  AiChatRepository(this._prefs);
  final SharedPreferences _prefs;
  static const _key = 'caption4k_ai_chats_v1';
  static const retention = Duration(days: 90);
  /// Prunes conversations by their original creation date. Editing or adding
  /// messages does not extend the three-month retention period.
  Future<int> expireOldConversations({DateTime? now}) async {
    final raw = _prefs.getString(_key);
    if (raw == null || raw.isEmpty) return 0;
    try {
      final cutoff = (now ?? DateTime.now()).subtract(retention);
      final decoded = (jsonDecode(raw) as List)
          .whereType<Map>()
          .map((e) => AiChatConversation.fromJson(Map<String, dynamic>.from(e)))
          .toList();
      final retained = decoded.where((chat) => !chat.createdAt.isBefore(cutoff)).toList();
      final removed = decoded.length - retained.length;
      if (removed > 0) await _write(retained);
      return removed;
    } catch (_) {
      // Preserve unreadable chat data; do not overwrite it during cleanup.
      return 0;
    }
  }

  Future<List<AiChatConversation>> getAll({DateTime? now}) async {
    final raw = _prefs.getString(_key);
    if (raw == null || raw.isEmpty) return [];
    try {
      final cutoff = (now ?? DateTime.now()).subtract(retention);
      final chats = (jsonDecode(raw) as List).whereType<Map>().map((e) => AiChatConversation.fromJson(Map<String, dynamic>.from(e))).where((e) => !e.createdAt.isBefore(cutoff)).toList()..sort((a,b) => b.updatedAt.compareTo(a.updatedAt));
      await _write(chats);
      return chats;
    } catch (_) {
      // Preserve malformed chat data before returning an empty view. Without
      // this backup, creating a new chat could overwrite the unreadable data.
      if (!_prefs.containsKey('${_key}_corrupt_backup')) {
        await _prefs.setString('${_key}_corrupt_backup', raw);
      }
      return [];
    }
  }
  Future<void> _write(List<AiChatConversation> chats) => _prefs.setString(_key, jsonEncode(chats.map((e) => e.toJson()).toList()));
  Future<AiChatConversation> create() async {
    final chats = await getAll(); final now = DateTime.now();
    final chat = AiChatConversation(id: now.microsecondsSinceEpoch.toString(), title: 'New chat', createdAt: now, updatedAt: now);
    chats.insert(0, chat); await _write(chats); return chat;
  }
  Future<void> addUserMessage(String id, String text) async {
    final chats = await getAll(); final i = chats.indexWhere((e) => e.id == id); if (i < 0) return;
    final old = chats[i]; final now = DateTime.now();
    chats[i] = AiChatConversation(id: old.id, title: old.messages.isEmpty ? (text.length > 32 ? '${text.substring(0,32)}…' : text) : old.title, createdAt: old.createdAt, updatedAt: now, messages: [...old.messages, AiChatMessage(text: text, role: 'user', createdAt: now)]);
    await _write(chats);
  }
  Future<void> rename(String id, String title) async {
    final chats = await getAll(); final i = chats.indexWhere((e) => e.id == id); if (i < 0) return; final old = chats[i];
    chats[i] = AiChatConversation(id: old.id, title: title.trim(), createdAt: old.createdAt, updatedAt: DateTime.now(), messages: old.messages); await _write(chats);
  }
  Future<void> delete(String id) async { final chats = await getAll(); chats.removeWhere((e) => e.id == id); await _write(chats); }
}

final aiChatRepositoryProvider = Provider<AiChatRepository>((ref) => AiChatRepository(ref.read(sharedPreferencesProvider)));
