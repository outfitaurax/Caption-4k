import 'package:material_ui/material_ui.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../shared/widgets/screen_scaffold.dart';
import '../data/ai_chat_repository.dart';

class AiScreen extends ConsumerStatefulWidget {
  const AiScreen({super.key});
  @override
  ConsumerState<AiScreen> createState() => _AiScreenState();
}

class _AiScreenState extends ConsumerState<AiScreen> {
  final _messageController = TextEditingController();
  List<AiChatConversation> _chats = [];
  String? _selectedId;
  bool _loading = true;
  AiChatConversation? get _selected { for (final chat in _chats) { if (chat.id == _selectedId) return chat; } return null; }
  @override
  void initState() { super.initState(); _load(); }
  @override
  void dispose() { _messageController.dispose(); super.dispose(); }
  Future<void> _load() async {
    final chats = await ref.read(aiChatRepositoryProvider).getAll(); if (!mounted) return;
    setState(() { _chats = chats; _selectedId ??= chats.isEmpty ? null : chats.first.id; _loading = false; });
  }
  Future<void> _newChat() async { final chat = await ref.read(aiChatRepositoryProvider).create(); await _load(); if (mounted) setState(() => _selectedId = chat.id); }
  Future<void> _send() async {
    final text = _messageController.text.trim(); final chat = _selected; if (text.isEmpty || chat == null) return;
    _messageController.clear(); await ref.read(aiChatRepositoryProvider).addUserMessage(chat.id, text); await _load(); if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Message saved. AI replies will be available after Tout is connected.')));
  }
  Future<void> _rename(AiChatConversation chat) async {
    final controller = TextEditingController(text: chat.title);
    final name = await showDialog<String>(context: context, builder: (context) => AlertDialog(title: const Text('Rename chat'), content: TextField(controller: controller, autofocus: true, decoration: const InputDecoration(labelText: 'Chat name')), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')), FilledButton(onPressed: () => Navigator.pop(context, controller.text.trim()), child: const Text('Save'))]));
    controller.dispose(); if (name != null && name.trim().isNotEmpty) { await ref.read(aiChatRepositoryProvider).rename(chat.id, name); await _load(); }
  }
  Future<void> _delete(AiChatConversation chat) async {
    final yes = await showDialog<bool>(context: context, builder: (context) => AlertDialog(title: const Text('Delete chat?'), content: Text('Delete “${chat.title}” and its messages?'), actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')), FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Delete'))]));
    if (yes != true) return; await ref.read(aiChatRepositoryProvider).delete(chat.id); if (_selectedId == chat.id) _selectedId = null; await _load();
  }
  @override
  Widget build(BuildContext context) => ScreenScaffold(title: 'AI', children: [
    Row(children: [const Expanded(child: Text('Your conversations', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600))), FilledButton.icon(onPressed: _newChat, icon: const Icon(Icons.add), label: const Text('New Chat'))]),
    const SizedBox(height: 12),
    if (_loading) const Center(child: CircularProgressIndicator())
    else if (_chats.isEmpty) const Padding(padding: EdgeInsets.all(20), child: Text('Start a new chat. Your conversations will be saved on this device.'))
    else ...[
      for (final chat in _chats) Card(child: ListTile(selected: chat.id == _selectedId, leading: const Icon(Icons.chat_bubble_outline), title: Text(chat.title, maxLines: 1, overflow: TextOverflow.ellipsis), subtitle: Text('${chat.messages.length} messages'), onTap: () => setState(() => _selectedId = chat.id), trailing: PopupMenuButton<String>(onSelected: (v) => v == 'rename' ? _rename(chat) : _delete(chat), itemBuilder: (_) => const [PopupMenuItem(value: 'rename', child: Text('Rename')), PopupMenuItem(value: 'delete', child: Text('Delete'))]))),
      if (_selected != null) ...[
        const SizedBox(height: 12), const Text('Conversation', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
        for (final message in _selected!.messages) Align(alignment: message.role == 'user' ? Alignment.centerRight : Alignment.centerLeft, child: Container(margin: const EdgeInsets.symmetric(vertical: 5), padding: const EdgeInsets.all(12), constraints: const BoxConstraints(maxWidth: 320), decoration: BoxDecoration(color: Theme.of(context).colorScheme.surfaceContainerHighest, borderRadius: BorderRadius.circular(14)), child: Text(message.text))),
        Row(children: [Expanded(child: TextField(controller: _messageController, minLines: 1, maxLines: 4, decoration: const InputDecoration(hintText: 'Write a message...', border: OutlineInputBorder()))), const SizedBox(width: 8), IconButton.filled(onPressed: _send, icon: const Icon(Icons.send))]),
        const Padding(padding: EdgeInsets.only(top: 8), child: Text('Messages are saved locally. AI responses are disabled until the secure Tout backend is connected.', style: TextStyle(fontSize: 12))),
      ],
    ],
  ]);
}
