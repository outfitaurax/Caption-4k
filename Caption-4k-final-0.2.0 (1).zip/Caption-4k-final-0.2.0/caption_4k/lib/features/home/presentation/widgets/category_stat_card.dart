import 'package:material_ui/material_ui.dart';

import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_tokens.dart';

/// Stat card. [value] is null until real data exists (shown as a dash).
class CategoryStatCard extends StatelessWidget {
  const CategoryStatCard({
    super.key,
    required this.label,
    required this.icon,
    this.accentColor,
    this.value,
    this.onTap,
  });

  final String label;
  final IconData icon;
  final Color? accentColor;
  final int? value;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 6),
        decoration: BoxDecoration(
          color: c.card,
          borderRadius: BorderRadius.circular(AppRadius.card),
          border: Border.all(color: c.border),
        ),
        child: Column(
          children: [
            Icon(icon, size: 26, color: accentColor ?? c.text),
            const SizedBox(height: 4),
            Text(
              value?.toString() ?? '\u2014',
              style: AppText.statValue.copyWith(color: accentColor ?? c.text),
            ),
            Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center,
                style: AppText.caption.copyWith(color: c.textSecondary)),
          ],
        ),
      ),
    );
  }
}
