import 'dart:io';

import 'package:material_ui/material_ui.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_tokens.dart';
import '../../../domain/analytics.dart';
import '../../../shared/widgets/app_card.dart';
import '../../../shared/widgets/empty_state.dart';
import '../../../shared/widgets/screen_scaffold.dart';
import '../../analytics/application/analytics_providers.dart';
import '../../analytics/presentation/analytics_section.dart';
import '../../analytics/presentation/category_sheet.dart';
import '../../analytics/presentation/platform_style.dart';
import '../../upload/data/product_repository.dart';
import '../../upload/presentation/upload_screen.dart';
import '../../operations/data/processing_job.dart';
import '../../operations/data/processing_job_repository.dart';
import '../../operations/presentation/processing_job_detail.dart';
import '../../operations/presentation/operations_history_screen.dart';
import 'widgets/category_stat_card.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  static const _icons = {
    ContentCategory.outfit: Icons.checkroom_outlined,
    ContentCategory.decor: Icons.home_outlined,
    ContentCategory.prompt: Icons.auto_fix_high_outlined,
    ContentCategory.products: Icons.inventory_2_outlined,
  };

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final c = context.colors;
    final summary = ref.watch(analyticsSummaryProvider).valueOrNull;
    return ScreenScaffold(
      title: 'Caption 4K',
      children: [
        const _ProcessingJobsSection(),
        Padding(
          padding: const EdgeInsets.fromLTRB(4, 6, 4, 12),
          child: Text(
            'Your Stats',
            style: AppText.sectionTitle.copyWith(color: c.text),
          ),
        ),
        GridView.count(
          crossAxisCount: 2,
          crossAxisSpacing: 10,
          mainAxisSpacing: 10,
          childAspectRatio: 1.30,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          children: [
            for (final cat in ContentCategory.values)
              CategoryStatCard(
                label: '${cat.title} Captions',
                icon: _icons[cat]!,
                accentColor: categoryColor(cat),
                value: summary != null && !summary.isEmpty
                    ? summary.captionsForCategory(cat)
                    : null,
                onTap: summary != null && !summary.isEmpty
                    ? () => showCategorySheet(context, summary, cat)
                    : null,
              ),
          ],
        ),
        const SizedBox(height: AppSpacing.lg),
        Padding(
          padding: const EdgeInsets.fromLTRB(4, 6, 4, 12),
          child: Text('Saved Products', style: AppText.sectionTitle.copyWith(color: c.text)),
        ),
        _SavedProductsSection(),
        const SizedBox(height: AppSpacing.lg),
        const AnalyticsSection(),
      ],
    );
  }
}


class _SavedProductsSection extends ConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final c = context.colors;
    final products = ref.watch(productsProvider);
    return products.when(
      loading: () => const Center(child: Padding(padding: EdgeInsets.all(20), child: CircularProgressIndicator())),
      error: (_, __) => const Text('Could not load saved products.'),
      data: (items) {
        if (items.isEmpty) {
          return const AppCard(child: EmptyState(
            icon: Icons.inventory_2_outlined,
            title: 'No saved products yet',
            message: 'Products you save from Upload will appear here.',
          ));
        }
        return Column(children: [
          for (final product in items)
            AppCard(
              padding: const EdgeInsets.all(12),
              child: Row(children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: product.imagePaths.isNotEmpty && File(product.imagePaths.first).existsSync()
                      ? Image.file(File(product.imagePaths.first), width: 58, height: 58, fit: BoxFit.cover)
                      : Container(width: 58, height: 58, color: c.muted, child: Icon(Icons.image_outlined, color: c.textSecondary)),
                ),
                const SizedBox(width: 12),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(product.name, maxLines: 1, overflow: TextOverflow.ellipsis,
                    style: TextStyle(color: c.text, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 4),
                  Text('${product.category.label} · ${product.imagePaths.length} image(s)',
                    style: TextStyle(color: c.textSecondary, fontSize: 12)),
                  if (product.description.isNotEmpty)
                    Text(product.description, maxLines: 1, overflow: TextOverflow.ellipsis,
                      style: TextStyle(color: c.textSecondary, fontSize: 11)),
                  Text(product.platforms.map((p) => p.label).join(', '),
                    maxLines: 1, overflow: TextOverflow.ellipsis,
                    style: TextStyle(color: c.textSecondary, fontSize: 12)),
                ])),
                IconButton(
                  tooltip: 'Edit product',
                  icon: Icon(Icons.edit_outlined, color: c.textSecondary),
                  onPressed: () async {
                    await Navigator.of(context).push(MaterialPageRoute(
                      builder: (_) => Scaffold(
                        body: UploadScreen(product: product),
                      ),
                    ));
                    ref.invalidate(productsProvider);
                    ref.invalidate(processingJobsProvider);
                  },
                ),
                IconButton(
                  tooltip: 'Delete product',
                  icon: Icon(Icons.delete_outline, color: c.textSecondary),
                  onPressed: () async {
                    final confirmed = await showDialog<bool>(
                      context: context,
                      builder: (dialogContext) => AlertDialog(
                        title: const Text('Delete product?'),
                        content: Text('Delete ${product.name}? Its details are removed now. Waiting and queued tasks are cancelled; any task already processing is kept until it finishes. Its photos stay on this device until their 30 days end.'),
                        actions: [
                          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Cancel')),
                          FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('Delete')),
                        ],
                      ),
                    );
                    if (confirmed != true || !context.mounted) return;
                    await ref.read(productRepositoryProvider).delete(product.id);
                    await ref.read(processingJobRepositoryProvider).deleteForProduct(product.id);
                    ref.invalidate(productsProvider);
                    ref.invalidate(processingJobsProvider);
                  },
                ),
              ]),
            ),
        ]);
      },
    );
  }
}

class _ProcessingJobsSection extends ConsumerWidget {
  const _ProcessingJobsSection();
  @override Widget build(BuildContext context, WidgetRef ref) {
    final c=context.colors; final jobs=ref.watch(processingJobsProvider);
    return Column(crossAxisAlignment: CrossAxisAlignment.start,children:[
      Padding(
        padding: const EdgeInsets.fromLTRB(4, 6, 4, 12),
        child: Row(children: [
          Expanded(child: Text('Processing queue', style: AppText.sectionTitle.copyWith(color: c.text))),
          TextButton(onPressed: () => Navigator.of(context).push(MaterialPageRoute(
            builder: (_) => const OperationsHistoryScreen(),
          )), child: const Text('History')),
        ]),
      ),
      jobs.when(loading:()=>const AppCard(child:Padding(padding:EdgeInsets.all(16),child:Center(child:CircularProgressIndicator()))),error:(_,__)=>const AppCard(child:Text('Could not load processing queue.')),data:(items){
        if(items.isEmpty)return const AppCard(child:EmptyState(icon:Icons.hourglass_empty,title:'No queued products',message:'Save a product from Upload to add its platform tasks here.'));
        return Column(children:[for(final job in items.take(12)) AppCard(padding:const EdgeInsets.all(12),child:InkWell(borderRadius: BorderRadius.circular(16), onTap:()=>showProcessingJobDetail(context,ref,job), child:Row(children:[
          Container(width:38,height:38,decoration:BoxDecoration(color:c.muted,borderRadius:BorderRadius.circular(12)),child:Icon(job.status==JobStatus.waitingForAi?Icons.schedule_outlined:job.status==JobStatus.completed?Icons.check_circle_outline:job.status==JobStatus.failed?Icons.error_outline:job.status==JobStatus.cancelled?Icons.cancel_outlined:Icons.hourglass_top,color:c.textSecondary)),
          const SizedBox(width:12),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(job.productName,style:TextStyle(color:c.text,fontWeight:FontWeight.w600)),const SizedBox(height:3),Text('${job.category.label} · ${job.platform.label}',style:TextStyle(color:c.textSecondary,fontSize:12)),Text(job.status==JobStatus.waitingForAi?'Saved · waiting for AI connection':job.status.label,style:TextStyle(color:c.textSecondary,fontSize:12))])),
          IconButton(
            tooltip: job.status == JobStatus.processing
                ? 'Processing task cannot be removed yet'
                : 'Remove task',
            onPressed: () async {
              if (job.status == JobStatus.processing) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('This task is still processing and cannot be removed yet.')),
                );
                return;
              }
              await ref.read(processingJobRepositoryProvider).delete(job.id);
              ref.invalidate(processingJobsProvider);
            },
            icon: Icon(Icons.close, color: c.textSecondary),
          )
        ]))) ]);
      })
    ]);
  }
}
