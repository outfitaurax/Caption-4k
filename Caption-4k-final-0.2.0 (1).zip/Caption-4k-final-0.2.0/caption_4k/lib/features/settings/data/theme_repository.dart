import 'package:material_ui/material_ui.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ThemeRepository {
  ThemeRepository(this._prefs);

  static const key = 'theme_mode';
  final SharedPreferences _prefs;

  ThemeMode load() {
    switch (_prefs.getString(key)) {
      case 'light':
        return ThemeMode.light;
      case 'dark':
        return ThemeMode.dark;
      default:
        return ThemeMode.system;
    }
  }

  Future<void> save(ThemeMode mode) => _prefs.setString(key, mode.name);
}
