import 'package:flutter/foundation.dart';
import 'package:material_ui/material_ui.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_tokens.dart';
import '../../../shared/widgets/app_card.dart';

/// Debug-only information about the current local-first build.
class DeveloperSection extends StatelessWidget {
  const DeveloperSection({super.key});

  @override
  Widget build(BuildContext context) {
    if (!kDebugMode) return const SizedBox.shrink();
    final c = context.colors;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(4, 8, 4, 10),
          child: Text('Developer', style: AppText.sectionTitle.copyWith(color: c.text)),
        ),
        AppCard(
          child: Text(
            'Analytics now reads saved products and processing jobs. No demo numbers are used.',
            style: AppText.body.copyWith(color: c.textSecondary),
          ),
        ),
      ],
    );
  }
}
