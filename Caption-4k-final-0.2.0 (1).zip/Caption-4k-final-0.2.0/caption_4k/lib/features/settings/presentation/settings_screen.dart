import 'package:material_ui/material_ui.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_tokens.dart';
import '../../../shared/widgets/app_card.dart';
import '../application/theme_controller.dart';
import '../../../core/notifications/local_notification_service.dart';
import 'developer_section.dart';

class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  static const _options = <(String, ThemeMode)>[
    ('Light Mode', ThemeMode.light),
    ('Dark Mode', ThemeMode.dark),
    ('System Default', ThemeMode.system),
  ];

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final c = context.colors;
    return Scaffold(
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(8, 14, 12, 8),
              child: Row(
                children: [
                  IconButton(
                    tooltip: 'Back',
                    icon: Icon(Icons.chevron_left, size: 32, color: c.text),
                    onPressed: () => Navigator.of(context).maybePop(),
                  ),
                  Text(
                    'Settings',
                    style: AppText.screenTitle.copyWith(color: c.text),
                  ),
                ],
              ),
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
                children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(4, 0, 4, 10),
                    child: Text(
                      'Appearance',
                      style: AppText.sectionTitle.copyWith(color: c.text),
                    ),
                  ),
                  AppCard(
                    padding: EdgeInsets.zero,
                    child: Column(
                      children: [
                        for (var i = 0; i < _options.length; i++) ...[
                          if (i > 0) Divider(height: 1, color: c.border),
                          _ThemeOption(
                            label: _options[i].$1,
                            mode: _options[i].$2,
                          ),
                        ],
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(4, 18, 4, 10),
                    child: Text('Notifications', style: AppText.sectionTitle.copyWith(color: c.text)),
                  ),
                  AppCard(
                    child: Row(children: [
                      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text('Local operation notifications', style: AppText.body.copyWith(color: c.text)),
                        const SizedBox(height: 4),
                        Text('Get an alert when an operation completes or fails.', style: AppText.caption.copyWith(color: c.textSecondary)),
                      ])),
                      const SizedBox(width: 8),
                      OutlinedButton(
                        onPressed: () async {
                          try {
                            final granted = await ref.read(localNotificationServiceProvider).requestPermission();
                            if (context.mounted) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(content: Text(granted
                                    ? 'Notifications enabled.'
                                    : 'Notifications were not enabled. Check your device settings.')),
                              );
                            }
                          } catch (_) {
                            if (context.mounted) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(content: Text('Could not request notification permission.')),
                              );
                            }
                          }
                        },
                        child: const Text('Enable'),
                      ),
                    ]),
                  ),
                  const DeveloperSection(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ThemeOption extends ConsumerWidget {
  const _ThemeOption({required this.label, required this.mode});

  final String label;
  final ThemeMode mode;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final c = context.colors;
    final selected = ref.watch(themeModeProvider) == mode;
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () => ref.read(themeModeProvider.notifier).setMode(mode),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 15),
        child: Row(
          children: [
            Expanded(
              child: Text(label, style: AppText.body.copyWith(color: c.text)),
            ),
            if (selected) Icon(Icons.check, color: c.success, size: 20),
          ],
        ),
      ),
    );
  }
}
