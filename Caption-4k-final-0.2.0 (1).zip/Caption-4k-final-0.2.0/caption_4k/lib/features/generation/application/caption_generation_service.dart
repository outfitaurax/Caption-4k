import '../data/caption_generation_request.dart';

/// Structured AI output keeps the title separate from the full caption body.
class CaptionGenerationResult {
  const CaptionGenerationResult({required this.title, required this.caption});

  final String title;
  final String caption;
}

/// Provider boundary for future AI integrations.
/// Implementations must return real provider output or throw; never fabricate captions.
abstract interface class CaptionGenerationService {
  Future<CaptionGenerationResult> generate(CaptionGenerationRequest request);
}

/// Used until a real, securely configured AI backend is connected.
class AiProviderNotConfigured implements Exception {
  const AiProviderNotConfigured();
  @override
  String toString() => 'AI provider is not configured. Connect a secure backend first.';
}

class UnconfiguredCaptionGenerationService implements CaptionGenerationService {
  const UnconfiguredCaptionGenerationService();
  @override
  Future<CaptionGenerationResult> generate(CaptionGenerationRequest request) async {
    throw const AiProviderNotConfigured();
  }
}
