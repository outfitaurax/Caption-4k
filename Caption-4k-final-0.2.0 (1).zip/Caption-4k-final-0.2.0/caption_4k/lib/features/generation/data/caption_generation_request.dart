import '../../../domain/analytics.dart';
import '../../upload/data/caption_template.dart';
import '../../upload/data/product.dart';

/// A deterministic request prepared for an AI provider. This does not call an AI.
class CaptionGenerationRequest {
  const CaptionGenerationRequest({
    required this.productId,
    required this.productName,
    required this.category,
    required this.platform,
    required this.imagePaths,
    required this.templateId,
    required this.prompt,
    required this.contentType,
  });

  final String productId;
  final String productName;
  final ContentCategory category;
  final SocialPlatform platform;
  final List<String> imagePaths;
  final String templateId;
  final String prompt;
  final CaptionContentType contentType;

  factory CaptionGenerationRequest.fromProduct({
    required Product product,
    required SocialPlatform platform,
    required CaptionTemplate template,
  }) {
    if (template.platform != platform || template.category != product.category) {
      throw ArgumentError('Template does not match the selected platform and category.');
    }
    final prompt = '''You are creating product content for ${platform.label}.
Content category: ${product.category.label}
Content type: ${template.contentType.name.toUpperCase()}
Product name: ${product.name}
Product details supplied by the user: ${product.description.isEmpty ? 'None supplied' : product.description}
Special instructions from the user: ${product.specialInstructions.trim().isEmpty ? 'None supplied' : product.specialInstructions.trim()}

Follow the user's special instructions where they do not conflict with the platform template or factual accuracy. Treat them as guidance for emphasis, tone, audience, and wording. Do not invent product details to satisfy an instruction.

Use the attached product images as the source of truth. Mention only details that are clearly visible or supplied. Never invent a brand, material, model, color, or product feature. If a detail is uncertain, omit it.

Follow these template instructions exactly:
${template.instructions}

Output only the requested content sections. Before returning, verify every character-count and hashtag-count requirement. For an 800-character description, count spaces and punctuation; exclude title, keywords, and hashtags as specified by the template.''';
    return CaptionGenerationRequest(
      productId: product.id,
      productName: product.name,
      category: product.category,
      platform: platform,
      imagePaths: List.unmodifiable(product.imagePaths),
      templateId: template.id,
      prompt: prompt,
      contentType: template.contentType,
    );
  }
}
