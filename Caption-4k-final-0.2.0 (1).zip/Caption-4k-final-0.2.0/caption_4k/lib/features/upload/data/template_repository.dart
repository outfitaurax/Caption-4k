import 'dart:convert';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../../core/storage/preferences.dart';
import '../../../domain/analytics.dart';
import 'caption_template.dart';

class TemplateRepository {
  TemplateRepository(Ref ref) : _prefs = ref.read(sharedPreferencesProvider);
  final SharedPreferences _prefs;
  static const _key = 'caption4k_templates_v1';

  List<CaptionTemplate> _defaults() => [
    for (final category in ContentCategory.values)
      for (final platform in SocialPlatform.values)
        for (final type in CaptionContentType.values)
          CaptionTemplate(id: type == CaptionContentType.image ? 'default_${platform.name}_${category.name}' : 'default_${platform.name}_${category.name}_video', name: '${platform.label} ${category.label} ${type.name} – Default', platform: platform, category: category, contentType: type, instructions: defaultTemplateInstructions(platform, category, type), isDefault: true),
  ];

  Future<List<CaptionTemplate>> getAll() async {
    final raw = _prefs.getString(_key);
    if (raw == null || raw.isEmpty) {
      final defaults = _defaults();
      await _write(defaults);
      return defaults;
    }
    try {
      final saved = (jsonDecode(raw) as List).map((e) => CaptionTemplate.fromJson(e as Map<String, dynamic>)).toList();
      final ids = saved.map((e) => e.id).toSet();
      for (final item in _defaults()) { if (!ids.contains(item.id)) saved.add(item); }
      return saved;
    } catch (_) {
      if (!_prefs.containsKey('${_key}_corrupt_backup')) {
        await _prefs.setString('${_key}_corrupt_backup', raw);
      }
      return _defaults();
    }
  }
  Future<void> _write(List<CaptionTemplate> items) => _prefs.setString(_key, jsonEncode(items.map((e) => e.toJson()).toList()));
  Future<void> save(CaptionTemplate template) async { final all = await getAll(); final index = all.indexWhere((e) => e.id == template.id); if (index < 0) { all.add(template); } else { all[index] = template; } await _write(all); }
  Future<void> delete(String id) async { final all = await getAll(); all.removeWhere((e) => e.id == id && !e.isDefault); await _write(all); }
}
final templateRepositoryProvider = Provider<TemplateRepository>((ref) => TemplateRepository(ref));
