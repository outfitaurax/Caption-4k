import '../../../domain/analytics.dart';

enum CaptionContentType { image, video }

class CaptionTemplate {
  const CaptionTemplate({
    required this.id,
    required this.name,
    required this.platform,
    required this.category,
    required this.instructions,
    this.contentType = CaptionContentType.image,
    this.isDefault = false,
  });

  final String id;
  final String name;
  final SocialPlatform platform;
  final ContentCategory category;
  final String instructions;
  final CaptionContentType contentType;
  final bool isDefault;

  Map<String, Object?> toJson() => {
        'id': id,
        'name': name,
        'platform': platform.name,
        'category': category.name,
        'instructions': instructions,
        'contentType': contentType.name,
        'isDefault': isDefault,
      };

  factory CaptionTemplate.fromJson(Map<String, dynamic> json) => CaptionTemplate(
        id: json['id'] as String,
        name: json['name'] as String,
        platform: SocialPlatform.values.firstWhere(
          (e) => e.name == json['platform'],
          orElse: () => SocialPlatform.instagram,
        ),
        category: ContentCategory.values.firstWhere(
          (e) => e.name == json['category'],
          orElse: () => ContentCategory.outfit,
        ),
        instructions: json['instructions'] as String? ?? '',
        contentType: CaptionContentType.values.firstWhere((e) => e.name == json['contentType'], orElse: () => CaptionContentType.image),
        isDefault: json['isDefault'] as bool? ?? false,
      );
}

String _categoryGuidance(ContentCategory? category) => switch (category) {
      ContentCategory.outfit => 'For OUTFIT: focus on visible clothing pieces, silhouette, colors, fit, layering, styling direction, and realistic occasions. Use fashion-specific search phrases such as outfit combinations, streetwear, casual styling, seasonal looks, or university outfits only when relevant to the image.',
      ContentCategory.decor => 'For DECOR: focus on the visible object or space, furniture form, materials only when identifiable, color palette, texture, room style, and placement. Use decor-specific search phrases such as room inspiration, interior styling, small-space decor, lighting ideas, or furniture styling only when relevant.',
      ContentCategory.prompt => 'For PROMPT: preserve the creative intent and visual direction. Describe the subject, composition, lighting, atmosphere, camera or art direction only when supplied or clearly visible. Use prompt-specific search phrases such as AI image prompt, visual concept, editorial photography prompt, or composition reference only when relevant.',
      ContentCategory.products => 'For PRODUCTS: focus on the specific item being presented, its visible shape, design, color, function, and distinguishing details. Use product-focused search phrases and identify the product naturally without inventing brand, price, material, size, or specifications.',
      null => 'Tailor every description and search phrase to the actual product and its visible details. Avoid generic keyword filler.',
    };

String defaultTemplateInstructions(
  SocialPlatform platform, [
  ContentCategory? category,
  CaptionContentType contentType = CaptionContentType.image,
]) {
  final categoryGuidance = _categoryGuidance(category);
  final base = switch (platform) {
    SocialPlatform.x => 'Write a concise, natural product caption. Describe the product using its name and only useful identifying details such as color, material, model, or distinctive design. No sales pitch, no filler, no hashtags, and no call to action.',
    SocialPlatform.pinterest => 'Return exactly three sections: Main Title (under 100 characters); Description (exactly 800 characters, including spaces and punctuation; title and keywords are excluded from this count); SEO Keywords. Write a rich, natural description with relevant search terms. SEO Keywords must be a single comma-separated line of varied search PHRASES, mixing short and long-tail phrases, such as cherry red outfit, sporty streetwear, vintage track jacket, or casual university outfits when they genuinely match the image. Do not use hashtags, bullets, numbering, or unrelated filler. Tailor phrases to the product and its category.',
    SocialPlatform.instagram => 'Return exactly four sections: Main Title (under 100 characters); Description (exactly 800 characters, including spaces and punctuation; title, keywords, and hashtags are excluded from this count); SEO Keywords; Hashtags. Use one comma-separated line of varied search PHRASES, mixing short and long-tail phrases, such as cherry red outfit, sporty streetwear, vintage track jacket, or casual university outfits when they genuinely match the image. Finish with exactly five relevant hashtags. Do not use unrelated filler.',
    SocialPlatform.tiktok => 'Write a TikTok-ready product caption in a natural, engaging voice. Start with a short hook, then describe the product accurately using only visible or supplied details. Keep it concise and easy to read on mobile. Add a small set of relevant hashtags (3 to 5); avoid keyword stuffing, unsupported claims, and excessive emojis. Do not include a title or SEO keyword section unless the user template explicitly asks for them.',
    _ => 'Write platform-appropriate copy that accurately describes the product and its distinguishing details. Avoid invented specifications and irrelevant keywords.',
  };
  final mediaGuidance = contentType == CaptionContentType.video
      ? 'VIDEO CONTENT: describe the overall subject and sequence only when supported by the supplied video analysis. Consider visible scenes, transitions, movement, and pacing. Never claim an action or event that is not actually shown.'
      : 'IMAGE CONTENT: base the caption on the visible still image and supplied product details; do not imply motion or events.';
  return '$base\n\n$categoryGuidance\n\n$mediaGuidance\n\nNever invent a brand, material, model, color, feature, or specification. If a detail is uncertain, omit it.';
}
