import 'dart:convert';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../core/storage/preferences.dart';
import '../../../domain/analytics.dart';
import 'caption_template.dart';

/// Per-platform template choices, stored locally.
/// "AI Select" only records the choice; the AI that acts on it is connected
/// in the final integration stage and must pick from saved templates.
class PlatformSettingsRepository {
  PlatformSettingsRepository(Ref ref) : _prefs = ref.read(sharedPreferencesProvider);

  final SharedPreferences _prefs;
  static const _aiKey = 'caption4k_ai_select_platforms_v1';
  static const _defaultsKey = 'caption4k_default_templates_v1';

  bool isAiSelect(SocialPlatform platform) =>
      (_prefs.getStringList(_aiKey) ?? const <String>[]).contains(platform.name);

  Future<void> setAiSelect(SocialPlatform platform, bool value) async {
    final names = <String>{...(_prefs.getStringList(_aiKey) ?? const <String>[])};
    if (value) {
      names.add(platform.name);
    } else {
      names.remove(platform.name);
    }
    await _prefs.setStringList(_aiKey, names.toList());
  }

  Map<String, String> _defaults() {
    final raw = _prefs.getString(_defaultsKey);
    if (raw == null || raw.isEmpty) return {};
    try {
      return (jsonDecode(raw) as Map).map((k, v) => MapEntry(k.toString(), v.toString()));
    } catch (_) {
      return {};
    }
  }

  /// The chosen default template id, or the built-in default id when none chosen.
  String defaultTemplateId(
    SocialPlatform platform,
    ContentCategory category, {
    CaptionContentType contentType = CaptionContentType.image,
  }) {
    final all = _defaults();
    final key = '${platform.name}_${category.name}_${contentType.name}';
    // Read the old image-only key for users upgrading from the earlier format.
    return all[key] ??
        (contentType == CaptionContentType.image
            ? all['${platform.name}_${category.name}']
            : null) ??
        'default_${platform.name}_${category.name}${contentType == CaptionContentType.video ? '_video' : ''}';
  }

  Future<void> setDefaultTemplate(
    SocialPlatform platform,
    ContentCategory category,
    String templateId, {
    CaptionContentType contentType = CaptionContentType.image,
  }) async {
    final key = '${platform.name}_${category.name}_${contentType.name}';
    final all = _defaults()..[key] = templateId;
    await _prefs.setString(_defaultsKey, jsonEncode(all));
  }
}

final platformSettingsRepositoryProvider =
    Provider<PlatformSettingsRepository>((ref) => PlatformSettingsRepository(ref));
