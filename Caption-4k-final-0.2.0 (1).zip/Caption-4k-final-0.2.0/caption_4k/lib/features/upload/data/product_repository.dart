import '../../operations/data/waiting_job_expiry.dart';
import 'dart:convert';
import 'dart:io';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../../core/storage/preferences.dart';
import 'product.dart';
import '../../operations/data/processing_job.dart';

class ProductRepository {
  ProductRepository(Ref ref) : _prefs = ref.read(sharedPreferencesProvider);
  final SharedPreferences _prefs;
  static const _key = 'caption4k_products_v1';

  Future<List<Product>> getAll() async {
    final raw = _prefs.getString(_key);
    if (raw == null || raw.isEmpty) return [];
    try {
      final decoded = jsonDecode(raw) as List<dynamic>;
      final products = decoded.map((item) => Product.fromJson(item as Map<String, dynamic>)).toList();
      products.sort((a, b) => b.createdAt.compareTo(a.createdAt));
      return products;
    } catch (_) {
      // Preserve unreadable data for recovery instead of silently overwriting it.
      if (!_prefs.containsKey('${_key}_corrupt_backup')) {
        await _prefs.setString('${_key}_corrupt_backup', raw);
      }
      return [];
    }
  }

  Future<void> save(Product product) async {
    final products = await getAll();
    Product? previous;
    for (final item in products) {
      if (item.id == product.id) { previous = item; break; }
    }
    products.removeWhere((item) => item.id == product.id);
    products.insert(0, product);

    // Editing a product detaches removed images; it never shortens their
    // independent 30-day retention period. Track before writing the product
    // list so a crash cannot leave a detached file untracked.
    if (previous != null) {
      final retained = product.imagePaths.toSet();
      final referenced = products.expand((item) => item.imagePaths).toSet();
      final detached = <String, DateTime>{};
      for (final path in previous.imagePaths) {
        if (!retained.contains(path) && !referenced.contains(path)) {
          detached[path] = previous.imageAddedAt[path] ?? previous.createdAt;
        }
      }
      await _trackDetachedImages(detached, productId: product.id);
    }
    await _prefs.setString(_key, jsonEncode(products.map((item) => item.toJson()).toList()));
  }

  Future<void> delete(String id) async {
    final products = await getAll();
    final removed = products.where((item) => item.id == id).toList();
    products.removeWhere((item) => item.id == id);
    final stillReferenced = products.expand((item) => item.imagePaths).toSet();
    // The product's photos are detached, not deleted: each keeps its own
    // 30-day retention and is removed by the image sweep when that ends.
    final detached = <String, DateTime>{};
    for (final product in removed) {
      for (final path in product.imagePaths) {
        if (stillReferenced.contains(path)) continue;
        detached[path] = product.imageAddedAt[path] ?? product.createdAt;
      }
    }
    // Track the files first so a crash can never leave an untracked image.
    await _trackDetachedImages(detached, productId: id);
    await _prefs.setString(_key, jsonEncode(products.map((item) => item.toJson()).toList()));
  }

  Future<void> _trackDetachedImages(
    Map<String, DateTime> images, {String? productId}) async {
    if (images.isEmpty) return;
    const datesKey = 'caption4k_orphan_images_v1';
    const ownersKey = 'caption4k_orphan_image_owners_v1';
    final dates = <String, String>{};
    final owners = <String, String>{};
    final rawDates = _prefs.getString(datesKey);
    final rawOwners = _prefs.getString(ownersKey);
    try {
      if (rawDates != null && rawDates.isNotEmpty) {
        (jsonDecode(rawDates) as Map<String, dynamic>).forEach(
          (path, value) => dates[path] = value.toString(),
        );
      }
    } catch (_) {
      await _prefs.setString('${datesKey}_corrupt_backup', rawDates ?? '');
      throw StateError('Detached image date index is unreadable; refusing to overwrite it.');
    }
    try {
      if (rawOwners != null && rawOwners.isNotEmpty) {
        (jsonDecode(rawOwners) as Map<String, dynamic>).forEach(
          (path, value) => owners[path] = value.toString(),
        );
      }
    } catch (_) {
      await _prefs.setString('${ownersKey}_corrupt_backup', rawOwners ?? '');
      throw StateError('Detached image owner index is unreadable; refusing to overwrite it.');
    }
    images.forEach((path, addedAt) {
      dates.putIfAbsent(path, () => addedAt.toIso8601String());
      if (productId != null) owners.putIfAbsent(path, () => productId);
    });
    await _prefs.setString(datesKey, jsonEncode(dates));
    await _prefs.setString(ownersKey, jsonEncode(owners));
  }


  /// Product IDs with active operations. Their referenced and detached images
  /// stay protected while work is active; unreadable job data fails closed.
  Future<Set<String>> _protectedProductIds(List<Product> products) async {
    final raw = _prefs.getString('caption4k_processing_jobs_v1');
    if (raw == null || raw.isEmpty) return <String>{};
    try {
      return (jsonDecode(raw) as List)
          .map((e) => ProcessingJob.fromJson(e as Map<String, dynamic>))
          .where((job) => job.status.isActive)
          .map((job) => job.productId)
          .toSet();
    } catch (_) {
      // If operations cannot be read, protect every known product and every
      // detached-image owner. Losing an image is worse than retaining it.
      final protected = <String>{'*', ...products.map((p) => p.id)};
      final ownersRaw = _prefs.getString('caption4k_orphan_image_owners_v1');
      if (ownersRaw != null && ownersRaw.isNotEmpty) {
        try {
          protected.addAll((jsonDecode(ownersRaw) as Map<String, dynamic>)
              .values.map((value) => value.toString()));
        } catch (_) {
          // If both indexes are corrupt, the orphan cleanup below will also
          // fail closed and preserve the files.
        }
      }
      return protected;
    }
  }

  /// Removes product text and historical operations older than three calendar
  /// months. Image files continue to follow the independent 30-day policy.
  Future<int> expireOldRecords({DateTime? now, int retentionMonths = 3}) async {
    final current = now ?? DateTime.now();
    final monthIndex = current.year * 12 + current.month - 1 - retentionMonths;
    final cutoffYear = monthIndex ~/ 12;
    final cutoffMonth = monthIndex % 12 + 1;
    final lastDay = DateTime(cutoffYear, cutoffMonth + 1, 0).day;
    final cutoff = DateTime(
      cutoffYear, cutoffMonth, current.day > lastDay ? lastDay : current.day,
      current.hour, current.minute, current.second, current.millisecond,
      current.microsecond,
    );

    await expireStaleWaitingJobs(_prefs, now: now);
    final rawJobs = _prefs.getString('caption4k_processing_jobs_v1');
    List<ProcessingJob> jobs = [];
    if (rawJobs != null && rawJobs.isNotEmpty) {
      try {
        jobs = (jsonDecode(rawJobs) as List)
            .map((e) => ProcessingJob.fromJson(e as Map<String, dynamic>))
            .toList();
      } catch (_) {
        // Never prune product data if its operation history cannot be read.
        return 0;
      }
    }

    final products = await getAll();
    final protectedIds = await _protectedProductIds(products);
    final expiredProducts = products
        .where((product) =>
            product.createdAt.isBefore(cutoff) &&
            !protectedIds.contains('*') &&
            !protectedIds.contains(product.id))
        .toList();

    // Detach image metadata before deleting old product text. This lets each
    // image keep its own original 30-day expiry even if its product record is
    // removed at the three-month mark.
    final removableProducts = expiredProducts;
    final orphanRaw = _prefs.getString('caption4k_orphan_images_v1');
    final orphanDates = <String, String>{};
    final orphanOwners = <String, String>{};
    final ownersRaw = _prefs.getString('caption4k_orphan_image_owners_v1');
    if (ownersRaw != null && ownersRaw.isNotEmpty) {
      try {
        (jsonDecode(ownersRaw) as Map<String, dynamic>).forEach(
          (path, value) => orphanOwners[path] = value.toString(),
        );
      } catch (_) {
        await _prefs.setString('caption4k_orphan_image_owners_corrupt_backup', ownersRaw);
        return 0;
      }
    }
    if (orphanRaw != null && orphanRaw.isNotEmpty) {
      try {
        final decoded = jsonDecode(orphanRaw) as Map<String, dynamic>;
        for (final entry in decoded.entries) {
          if (entry.value is String) orphanDates[entry.key] = entry.value as String;
        }
      } catch (_) {
        // A corrupt orphan index is preserved separately for recovery. Do not
        // prune records because doing so could orphan image files permanently.
        await _prefs.setString('caption4k_orphan_images_corrupt_backup', orphanRaw);
        return 0;
      }
    }
    for (final product in removableProducts) {
      for (final path in product.imagePaths) {
        final addedAt = product.imageAddedAt[path] ?? product.createdAt;
        orphanDates[path] = addedAt.toIso8601String();
        orphanOwners.putIfAbsent(path, () => product.id);
      }
    }

    final removableIds = removableProducts.map((p) => p.id).toSet();
    final remainingProducts = products.where((p) => !removableIds.contains(p.id)).toList();
    // Retain each operation by its own creation timestamp. A product may
    // expire while a newer operation referencing its snapshot is still within
    // the three-month history window.
    final remainingJobs = jobs.where((job) {
      if (job.status.isActive) return true;
      return !job.createdAt.isBefore(cutoff);
    }).toList();

    if (removableIds.isEmpty && remainingJobs.length == jobs.length) return 0;
    // Persist detached-image metadata before removing its product record.
    await _prefs.setString('caption4k_orphan_images_v1', jsonEncode(orphanDates));
    await _prefs.setString('caption4k_orphan_image_owners_v1', jsonEncode(orphanOwners));
    await _prefs.setString(_key,
        jsonEncode(remainingProducts.map((item) => item.toJson()).toList()));
    await _prefs.setString('caption4k_processing_jobs_v1',
        jsonEncode(remainingJobs.map((item) => item.toJson()).toList()));

    return removableIds.length;
  }

  /// Deletes image files older than [retention] independently of the product
  /// text/history retention period.
  Future<int> expireOldImages({Duration retention = const Duration(days: 30), DateTime? now}) async {
    await expireStaleWaitingJobs(_prefs, now: now);
    final products = await getAll();
    final cutoff = (now ?? DateTime.now()).subtract(retention);
    final protectedIds = await _protectedProductIds(products);

    // Load both orphan indexes before changing product metadata or deleting a
    // file. Corrupt indexes fail closed so an active operation cannot lose an
    // image merely because its owner mapping could not be read.
    final ownersRaw = _prefs.getString('caption4k_orphan_image_owners_v1');
    final orphanOwners = <String, String>{};
    if (ownersRaw != null && ownersRaw.isNotEmpty) {
      try {
        (jsonDecode(ownersRaw) as Map<String, dynamic>).forEach(
          (path, value) => orphanOwners[path] = value.toString(),
        );
      } catch (_) {
        await _prefs.setString('caption4k_orphan_image_owners_corrupt_backup', ownersRaw);
        return 0;
      }
    }

    final orphanRaw = _prefs.getString('caption4k_orphan_images_v1');
    final orphanDates = <String, String>{};
    if (orphanRaw != null && orphanRaw.isNotEmpty) {
      try {
        (jsonDecode(orphanRaw) as Map<String, dynamic>).forEach(
          (path, value) => orphanDates[path] = value.toString(),
        );
      } catch (_) {
        await _prefs.setString('caption4k_orphan_images_corrupt_backup', orphanRaw);
        return 0;
      }
    }

    var deletedCount = 0;
    var changedProducts = false;
    final expiredPaths = <String, DateTime>{};
    for (var index = 0; index < products.length; index++) {
      final product = products[index];
      if (product.imagePaths.isEmpty) continue;
      if (protectedIds.contains('*') || protectedIds.contains(product.id)) continue;
      final keptPaths = <String>[];
      final keptDates = <String, DateTime>{};
      for (final path in product.imagePaths) {
        final addedAt = product.imageAddedAt[path] ?? product.createdAt;
        if (addedAt.isBefore(cutoff)) {
          expiredPaths[path] = addedAt;
          changedProducts = true;
        } else {
          keptPaths.add(path);
          keptDates[path] = addedAt;
        }
      }
      if (keptPaths.length != product.imagePaths.length) {
        products[index] = product.copyWith(
          imagePaths: keptPaths,
          imageAddedAt: keptDates,
        );
      }
    }

    // Persist expired-image metadata before touching the files. If deletion
    // fails or the app stops midway, the orphan index allows a later retry.
    for (final entry in expiredPaths.entries) {
      orphanDates.putIfAbsent(entry.key, () => entry.value.toIso8601String());
    }
    if (expiredPaths.isNotEmpty) {
      await _prefs.setString('caption4k_orphan_images_v1', jsonEncode(orphanDates));
    }
    if (changedProducts) {
      await _prefs.setString(_key, jsonEncode(products.map((item) => item.toJson()).toList()));
    }

    final stillReferenced = products.expand((item) => item.imagePaths).toSet();
    final remainingOrphans = <String, String>{};
    for (final entry in orphanDates.entries) {
      final addedAt = DateTime.tryParse(entry.value);
      if (addedAt == null) {
        remainingOrphans[entry.key] = entry.value;
        continue;
      }
      final ownerId = orphanOwners[entry.key];
      if (!addedAt.isBefore(cutoff) ||
          stillReferenced.contains(entry.key) ||
          protectedIds.contains('*') ||
          (ownerId != null && protectedIds.contains(ownerId))) {
        if (stillReferenced.contains(entry.key)) {
          // The path is safely tracked by a live product again.
          orphanOwners.remove(entry.key);
        } else {
          remainingOrphans[entry.key] = entry.value;
        }
        continue;
      }

      final file = File(entry.key);
      try {
        if (await file.exists()) {
          await file.delete();
          deletedCount++;
        }
        orphanOwners.remove(entry.key);
      } catch (_) {
        // Keep the original date and owner so a later sweep can retry safely.
        remainingOrphans[entry.key] = entry.value;
      }
    }

    await _prefs.setString('caption4k_orphan_images_v1', jsonEncode(remainingOrphans));
    orphanOwners.removeWhere((path, _) => !remainingOrphans.containsKey(path));
    await _prefs.setString('caption4k_orphan_image_owners_v1', jsonEncode(orphanOwners));
    return deletedCount;
  }

}

final productRepositoryProvider = Provider<ProductRepository>((ref) => ProductRepository(ref));
final productsProvider = FutureProvider<List<Product>>((ref) => ref.watch(productRepositoryProvider).getAll());
