import '../../../domain/analytics.dart';

class Product {
  const Product({
    required this.id,
    required this.name,
    this.description = '',
    this.specialInstructions = '',
    required this.category,
    required this.imagePaths,
    this.imageAddedAt = const {},
    required this.platforms,
    required this.createdAt,
  });

  final String id;
  final String name;
  final String description;
  /// Optional user guidance that will be included in future AI generation requests.
  final String specialInstructions;
  final ContentCategory category;
  final List<String> imagePaths;
  /// The upload time for each image, independent of the product's creation date.
  final Map<String, DateTime> imageAddedAt;
  final List<SocialPlatform> platforms;
  final DateTime createdAt;

  Product copyWith({
    String? name,
    String? description,
    String? specialInstructions,
    ContentCategory? category,
    List<String>? imagePaths,
    Map<String, DateTime>? imageAddedAt,
    List<SocialPlatform>? platforms,
  }) => Product(
        id: id,
        name: name ?? this.name,
        description: description ?? this.description,
        specialInstructions: specialInstructions ?? this.specialInstructions,
        category: category ?? this.category,
        imagePaths: imagePaths ?? this.imagePaths,
        imageAddedAt: imageAddedAt ?? this.imageAddedAt,
        platforms: platforms ?? this.platforms,
        createdAt: createdAt,
      );

  Map<String, Object?> toJson() => {
        'id': id,
        'name': name,
        'description': description,
        'specialInstructions': specialInstructions,
        'category': category.name,
        'imagePaths': imagePaths,
        'imageAddedAt': {
          for (final entry in imageAddedAt.entries)
            entry.key: entry.value.toIso8601String(),
        },
        'platforms': platforms.map((e) => e.name).toList(),
        'createdAt': createdAt.toIso8601String(),
      };

  factory Product.fromJson(Map<String, dynamic> json) {
    final createdAt =
        DateTime.tryParse(json['createdAt'] as String? ?? '') ?? DateTime.now();
    final paths = (json['imagePaths'] as List? ?? const []).cast<String>();
    final rawImageDates = json['imageAddedAt'];
    final imageDates = <String, DateTime>{};
    if (rawImageDates is Map) {
      for (final entry in rawImageDates.entries) {
        final parsed = DateTime.tryParse(entry.value?.toString() ?? '');
        if (parsed != null) imageDates[entry.key.toString()] = parsed;
      }
    }
    // Backward compatibility: images from older app versions inherit the
    // product creation date as their best available upload timestamp.
    for (final path in paths) {
      imageDates.putIfAbsent(path, () => createdAt);
    }

    return Product(
      id: json['id'] as String,
      name: json['name'] as String,
      description: json['description'] as String? ?? '',
      specialInstructions: json['specialInstructions'] as String? ?? '',
      category: ContentCategory.values.firstWhere(
        (e) => e.name == json['category'],
        orElse: () => ContentCategory.outfit,
      ),
      imagePaths: paths,
      imageAddedAt: imageDates,
      platforms: (json['platforms'] as List? ?? const []).map((value) =>
          SocialPlatform.values.firstWhere(
            (e) => e.name == value,
            orElse: () => SocialPlatform.instagram,
          )).toList(),
      createdAt: createdAt,
    );
  }
}
