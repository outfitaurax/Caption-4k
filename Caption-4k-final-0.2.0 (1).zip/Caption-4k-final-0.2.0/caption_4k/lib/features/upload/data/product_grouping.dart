/// Splits selected images into product groups.
/// [oneProduct] true  -> one group holding every image.
/// [oneProduct] false -> one group per image (each image is its own product).
List<List<T>> groupForProducts<T>(List<T> items, {required bool oneProduct}) {
  if (items.isEmpty) return const [];
  if (oneProduct) return [List<T>.of(items)];
  return [for (final item in items) [item]];
}

/// Name for the product at [index] of [total]. Separate products are numbered.
String productNameFor(String base, int index, int total) =>
    total <= 1 ? base : '$base ${index + 1}';
