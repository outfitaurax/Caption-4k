import 'package:material_ui/material_ui.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_tokens.dart';
import '../../../domain/analytics.dart';
import '../data/caption_template.dart';
import '../data/platform_settings_repository.dart';
import '../data/template_repository.dart';
import 'templates_screen.dart';

/// Opened by long-pressing a platform: template library, default, AI Select.
Future<void> showPlatformSettingsSheet(
  BuildContext context,
  SocialPlatform platform,
  ContentCategory category, {
  CaptionContentType contentType = CaptionContentType.image,
}) {
  final c = context.colors;
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    backgroundColor: c.card,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(AppRadius.card)),
    ),
    builder: (_) => _PlatformSettingsSheet(
      platform: platform, category: category, contentType: contentType),
  );
}

class _PlatformSettingsSheet extends ConsumerStatefulWidget {
  const _PlatformSettingsSheet({required this.platform, required this.category, required this.contentType});
  final SocialPlatform platform;
  final ContentCategory category;
  final CaptionContentType contentType;

  @override
  ConsumerState<_PlatformSettingsSheet> createState() => _PlatformSettingsSheetState();
}

class _PlatformSettingsSheetState extends ConsumerState<_PlatformSettingsSheet> {
  List<CaptionTemplate>? _templates;
  bool _ai = false;
  String _defaultId = '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final all = await ref.read(templateRepositoryProvider).getAll();
    final settings = ref.read(platformSettingsRepositoryProvider);
    if (!mounted) return;
    setState(() {
      _templates = all
          .where((t) => t.platform == widget.platform &&
              t.category == widget.category && t.contentType == widget.contentType)
          .toList();
      _ai = settings.isAiSelect(widget.platform);
      _defaultId = settings.defaultTemplateId(
          widget.platform, widget.category, contentType: widget.contentType);
    });
  }

  Future<void> _chooseTemplate(CaptionTemplate t) async {
    final settings = ref.read(platformSettingsRepositoryProvider);
    await settings.setDefaultTemplate(
      widget.platform, widget.category, t.id, contentType: widget.contentType);
    await settings.setAiSelect(widget.platform, false);
    if (mounted) setState(() { _defaultId = t.id; _ai = false; });
  }

  Future<void> _chooseAi() async {
    await ref.read(platformSettingsRepositoryProvider).setAiSelect(widget.platform, true);
    if (mounted) setState(() => _ai = true);
  }

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    final templates = _templates;
    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(20, 20, 20, 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text('${widget.platform.label} ${widget.contentType.name} templates',
                    style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700)
                        .copyWith(color: c.text)),
                const Spacer(),
                Text(widget.category.label,
                    style: AppText.caption.copyWith(color: c.textSecondary)),
              ],
            ),
            const SizedBox(height: AppSpacing.sm),
            if (templates == null)
              const Padding(
                padding: EdgeInsets.all(24),
                child: Center(child: CircularProgressIndicator.adaptive()),
              )
            else ...[
              _OptionRow(
                title: 'AI Select',
                subtitle: 'Chooses from your saved templates once AI is connected. Not active yet.',
                selected: _ai,
                onTap: _chooseAi,
              ),
              for (final t in templates)
                _OptionRow(
                  title: t.name,
                  subtitle: 'Default template',
                  showSubtitle: false,
                  selected: !_ai && t.id == _defaultId,
                  onTap: () => _chooseTemplate(t),
                ),
              if (templates.isEmpty)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  child: Text('No templates for this platform and type yet.',
                      style: AppText.caption.copyWith(color: c.textSecondary)),
                ),
            ],
            const SizedBox(height: AppSpacing.sm),
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                Navigator.of(context).push(
                  MaterialPageRoute<void>(builder: (_) => const TemplatesScreen()),
                );
              },
              child: const Text('Manage templates'),
            ),
          ],
        ),
      ),
    );
  }
}

class _OptionRow extends StatelessWidget {
  const _OptionRow({
    required this.title,
    required this.subtitle,
    required this.selected,
    required this.onTap,
    this.showSubtitle = true,
  });

  final String title;
  final String subtitle;
  final bool showSubtitle;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(border: Border(top: BorderSide(color: c.border))),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: AppText.body.copyWith(color: c.text)),
                  if (showSubtitle)
                    Text(subtitle, style: AppText.caption.copyWith(color: c.textSecondary)),
                ],
              ),
            ),
            if (selected) Icon(Icons.check, color: c.success, size: 20),
          ],
        ),
      ),
    );
  }
}
