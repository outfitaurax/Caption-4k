import 'dart:io';

import 'package:material_ui/material_ui.dart';

import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_tokens.dart';

class ImageStripItem {
  const ImageStripItem({required this.id, required this.path});
  final int id;
  final String path;
}

/// Large dashed drop area when empty; reorderable thumbnails once images exist.
class ImageStrip extends StatelessWidget {
  const ImageStrip({
    super.key,
    required this.items,
    required this.onAdd,
    required this.onRemove,
    required this.onReorder,
  });

  final List<ImageStripItem> items;
  final VoidCallback onAdd;
  final ValueChanged<int> onRemove;
  final void Function(int oldIndex, int newIndex) onReorder;

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    if (items.isEmpty) return _Dropzone(onTap: onAdd);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          height: 96,
          child: ReorderableListView(
            scrollDirection: Axis.horizontal,
            onReorderItem: onReorder,
            children: [
              for (var i = 0; i < items.length; i++)
                Padding(
                  key: ValueKey(items[i].id),
                  padding: const EdgeInsets.only(right: 8, top: 4),
                  child: _Thumb(path: items[i].path, onRemove: () => onRemove(i)),
                ),
            ],
          ),
        ),
        const SizedBox(height: AppSpacing.sm),
        Row(
          children: [
            GestureDetector(
              onTap: onAdd,
              child: Text('Add more images',
                  style: AppText.body.copyWith(color: c.text, fontWeight: FontWeight.w600)),
            ),
            const Spacer(),
            if (items.length > 1)
              Text('Long-press to reorder',
                  style: AppText.caption.copyWith(color: c.textSecondary)),
          ],
        ),
      ],
    );
  }
}

class _Thumb extends StatelessWidget {
  const _Thumb({required this.path, required this.onRemove});
  final String path;
  final VoidCallback onRemove;

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    return Stack(
      clipBehavior: Clip.none,
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(16),
          child: Image.file(
            File(path),
            width: 84,
            height: 90,
            fit: BoxFit.cover,
            cacheWidth: 260,
            errorBuilder: (_, __, ___) => Container(
              width: 84,
              height: 90,
              color: c.muted,
              child: Icon(Icons.broken_image_outlined, color: c.textSecondary),
            ),
          ),
        ),
        Positioned(
          top: -8,
          right: -8,
          child: Material(
            color: c.selected,
            shape: const CircleBorder(),
            child: InkWell(
              customBorder: const CircleBorder(),
              onTap: onRemove,
              child: SizedBox(
                width: 40,
                height: 40,
                child: Center(child: Icon(Icons.close, size: 16, color: c.onSelected)),
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class _Dropzone extends StatelessWidget {
  const _Dropzone({required this.onTap});
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    return GestureDetector(
      onTap: onTap,
      child: CustomPaint(
        painter: _DashedPainter(c.muted, AppRadius.card),
        child: Container(
          height: 150,
          width: double.infinity,
          decoration: BoxDecoration(
            color: c.card,
            borderRadius: BorderRadius.circular(AppRadius.card),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.ios_share_outlined, size: 32, color: c.textSecondary),
              const SizedBox(height: AppSpacing.sm),
              Text('Add images',
                  style: AppText.body.copyWith(color: c.text, fontWeight: FontWeight.w600)),
              const SizedBox(height: 2),
              Text('Choose one photo or several',
                  style: AppText.caption.copyWith(color: c.textSecondary)),
            ],
          ),
        ),
      ),
    );
  }
}

class _DashedPainter extends CustomPainter {
  _DashedPainter(this.color, this.radius);
  final Color color;
  final double radius;

  @override
  void paint(Canvas canvas, Size size) {
    final path = Path()
      ..addRRect(RRect.fromRectAndRadius(Offset.zero & size, Radius.circular(radius)));
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;
    for (final metric in path.computeMetrics()) {
      var d = 0.0;
      while (d < metric.length) {
        canvas.drawPath(metric.extractPath(d, d + 6), paint);
        d += 10;
      }
    }
  }

  @override
  bool shouldRepaint(covariant _DashedPainter old) => old.color != color;
}
