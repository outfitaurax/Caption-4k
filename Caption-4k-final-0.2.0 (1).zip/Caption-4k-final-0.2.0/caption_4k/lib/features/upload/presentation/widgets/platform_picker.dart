import 'package:material_ui/material_ui.dart';
import 'package:simple_icons/simple_icons.dart';

import '../../../../core/theme/app_colors.dart';
import '../../../../domain/analytics.dart';
import '../../../analytics/presentation/platform_style.dart';

/// Platform tiles. Tap toggles selection, long press opens platform settings.
/// Brand marks use the Simple Icons brand glyphs and remain locally bundled.
class PlatformPicker extends StatelessWidget {
  const PlatformPicker({
    super.key,
    required this.selected,
    required this.onToggle,
    required this.onLongPress,
  });

  final Set<SocialPlatform> selected;
  final ValueChanged<SocialPlatform> onToggle;
  final ValueChanged<SocialPlatform> onLongPress;

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    return LayoutBuilder(
      builder: (context, constraints) {
        final gap = constraints.maxWidth < 360 ? 5.0 : 8.0;
        final tileWidth = (constraints.maxWidth -
                gap * (SocialPlatform.values.length - 1)) /
            SocialPlatform.values.length;
        final iconSize = (tileWidth * 0.62).clamp(20.0, 27.0);

        return Row(
          children: [
            for (var i = 0; i < SocialPlatform.values.length; i++) ...[
              if (i > 0) SizedBox(width: gap),
              Expanded(
                child: AspectRatio(
                  aspectRatio: 1,
                  child: Semantics(
                    button: true,
                    selected: selected.contains(SocialPlatform.values[i]),
                    label: SocialPlatform.values[i].label,
                    child: GestureDetector(
                      behavior: HitTestBehavior.opaque,
                      onTap: () => onToggle(SocialPlatform.values[i]),
                      onLongPress: () => onLongPress(SocialPlatform.values[i]),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 150),
                        decoration: BoxDecoration(
                          color: c.card,
                          borderRadius: BorderRadius.circular(18),
                          border: Border.all(
                            color: selected.contains(SocialPlatform.values[i])
                                ? c.selected
                                : c.border,
                            width: selected.contains(SocialPlatform.values[i])
                                ? 2
                                : 1,
                          ),
                        ),
                        child: Center(
                          child: _PlatformIcon(
                            platform: SocialPlatform.values[i],
                            active: selected.contains(SocialPlatform.values[i]),
                            size: iconSize,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ],
        );
      },
    );
  }
}

class _PlatformIcon extends StatelessWidget {
  const _PlatformIcon({
    required this.platform,
    required this.active,
    required this.size,
  });

  final SocialPlatform platform;
  final bool active;
  final double size;

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    final color = active ? platform.color(c) : c.textSecondary;
    final icon = switch (platform) {
      SocialPlatform.instagram => SimpleIcons.instagram,
      SocialPlatform.pinterest => SimpleIcons.pinterest,
      SocialPlatform.tiktok => SimpleIcons.tiktok,
      SocialPlatform.facebook => SimpleIcons.facebook,
      SocialPlatform.x => SimpleIcons.x,
      SocialPlatform.website => Icons.language_rounded,
    };

    return Icon(icon, size: size, color: color);
  }
}
