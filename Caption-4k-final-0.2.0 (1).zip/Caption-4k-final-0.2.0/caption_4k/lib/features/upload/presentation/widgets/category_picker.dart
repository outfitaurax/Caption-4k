import 'package:material_ui/material_ui.dart';

import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_tokens.dart';
import '../../../../domain/analytics.dart';

/// Category cards. One selected at a time.
class CategoryPicker extends StatelessWidget {
  const CategoryPicker({super.key, required this.value, required this.onChanged});

  final ContentCategory value;
  final ValueChanged<ContentCategory> onChanged;

  static const _icons = {
    ContentCategory.outfit: Icons.checkroom_outlined,
    ContentCategory.decor: Icons.home_outlined,
    ContentCategory.prompt: Icons.auto_fix_high_outlined,
    ContentCategory.products: Icons.inventory_2_outlined,
  };

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final columns = constraints.maxWidth < 520 ? 2 : 4;
        final itemWidth = (constraints.maxWidth - (columns - 1) * 10) / columns;
        return Wrap(
          spacing: 10, runSpacing: 10,
          children: [
        for (var i = 0; i < ContentCategory.values.length; i++)
          SizedBox(
            width: itemWidth,
            child: AspectRatio(
              aspectRatio: 1,
              child: Semantics(
                button: true,
                selected: ContentCategory.values[i] == value,
                label: ContentCategory.values[i].label,
                child: GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: () => onChanged(ContentCategory.values[i]),
                  child: _Card(category: ContentCategory.values[i], selected: ContentCategory.values[i] == value),
                ),
              ),
            ),
          ),
        ],
        );
      },
    );
  }
}

class _Card extends StatelessWidget {
  const _Card({required this.category, required this.selected});
  final ContentCategory category;
  final bool selected;

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    return AnimatedContainer(
      duration: const Duration(milliseconds: 150),
      decoration: BoxDecoration(
        color: c.card,
        borderRadius: BorderRadius.circular(AppRadius.card),
        border: Border.all(color: selected ? c.selected : c.border, width: selected ? 2 : 1),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(CategoryPicker._icons[category], size: AppSizes.iconLarge,
              color: selected ? c.text : c.textSecondary),
          const SizedBox(height: AppSpacing.sm),
          Text(
            category.label,
            style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w600,
              color: selected ? c.text : c.textSecondary,
            ),
          ),
        ],
      ),
    );
  }
}
