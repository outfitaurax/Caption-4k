import 'dart:io';

import 'package:material_ui/material_ui.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_tokens.dart';
import '../../../domain/analytics.dart';
import '../../../shared/widgets/app_card.dart';
import '../../../shared/widgets/app_segmented.dart';
import '../../../shared/widgets/screen_scaffold.dart';
import '../../operations/data/processing_job_repository.dart';
import '../data/product.dart';
import '../data/product_grouping.dart';
import '../data/product_repository.dart';
import 'platform_settings_sheet.dart';
import 'widgets/category_picker.dart';
import 'widgets/image_strip.dart';
import 'widgets/platform_picker.dart';

class UploadScreen extends ConsumerStatefulWidget {
  const UploadScreen({super.key, this.product});
  final Product? product;

  @override
  ConsumerState<UploadScreen> createState() => _UploadScreenState();
}

class _ImageItem {
  _ImageItem.existing(this.path) : isNew = false;
  _ImageItem.picked(this.path) : isNew = true;

  static int _counter = 0;
  final int uid = _counter++;
  final String path;
  final bool isNew;
}

class _UploadScreenState extends ConsumerState<UploadScreen> {
  final _nameController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _specialInstructionsController = TextEditingController();
  final _picker = ImagePicker();
  final List<_ImageItem> _items = [];
  ContentCategory _category = ContentCategory.outfit;
  final Set<SocialPlatform> _platforms = {SocialPlatform.instagram};
  bool _oneProduct = true;
  bool _saving = false;

  bool get _editing => widget.product != null;
  bool get _showMode => !_editing && _items.length > 1;

  @override
  void initState() {
    super.initState();
    final product = widget.product;
    if (product != null) {
      _nameController.text = product.name;
      _descriptionController.text = product.description;
      _specialInstructionsController.text = product.specialInstructions;
      _category = product.category;
      _platforms
        ..clear()
        ..addAll(product.platforms);
      _items.addAll(product.imagePaths.map(_ImageItem.existing));
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    _descriptionController.dispose();
    _specialInstructionsController.dispose();
    super.dispose();
  }

  Future<void> _pickImages() async {
    try {
      final picked = await _picker.pickMultiImage(
        imageQuality: 90,
        maxWidth: 2400,
        maxHeight: 2400,
      );
      if (!mounted || picked.isEmpty) return;
      setState(() => _items.addAll(picked.map((f) => _ImageItem.picked(f.path))));
    } catch (_) {
      _message('Could not open your photos. Please try again.');
    }
  }

  void _reorder(int oldIndex, int newIndex) {
    setState(() {
      // ReorderableListView.onReorderItem already supplies the final index.
      _items.insert(newIndex, _items.removeAt(oldIndex));
    });
  }

  void _togglePlatform(SocialPlatform p) {
    setState(() {
      if (!_platforms.remove(p)) _platforms.add(p);
    });
  }

  void _message(String value) {
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(value)));
    }
  }

  /// Saves one product from [items]. Copies new images into app storage and
  /// removes those copies again if the product itself could not be saved.
  Future<bool> _saveGroup(
    List<_ImageItem> items,
    String name,
    int index,
    Directory imageDirectory, {
    required bool createOperations,
  }) async {
    final id = widget.product?.id ??
        '${DateTime.now().microsecondsSinceEpoch}_$index';
    final copied = <String>[];
    var persisted = false;
    late final Product product;
    try {
      final paths = <String>[];
      final addedAt = <String, DateTime>{...?widget.product?.imageAddedAt};
      for (var i = 0; i < items.length; i++) {
        final item = items[i];
        if (!item.isNew) {
          paths.add(item.path);
          continue;
        }
        final extension = item.path.contains('.')
            ? item.path.substring(item.path.lastIndexOf('.'))
            : '.jpg';
        final destination =
            '${imageDirectory.path}${Platform.pathSeparator}${id}_${DateTime.now().microsecondsSinceEpoch}_$i$extension';
        await File(item.path).copy(destination);
        copied.add(destination);
        paths.add(destination);
        addedAt[destination] = DateTime.now();
      }
      addedAt.removeWhere((path, _) => !paths.contains(path));
      product = Product(
        id: id,
        name: name,
        description: _descriptionController.text.trim(),
        specialInstructions: _specialInstructionsController.text.trim(),
        category: _category,
        imagePaths: paths,
        imageAddedAt: addedAt,
        platforms: _platforms.toList(),
        createdAt: widget.product?.createdAt ?? DateTime.now(),
      );
      await ref.read(productRepositoryProvider).save(product);
      persisted = true;
    } catch (_) {
      if (!persisted) {
        for (final path in copied) {
          try {
            final file = File(path);
            if (await file.exists()) await file.delete();
          } catch (_) {}
        }
      }
      rethrow;
    }

    // Product persistence is the commit point. If operation creation fails,
    // keep the saved product and tell the user; never leave its images in the
    // upload list where retrying would create a duplicate product.
    if (!createOperations && widget.product == null) return true;
    try {
      await ref
          .read(processingJobRepositoryProvider)
          .createForProduct(product, previousProduct: widget.product);
      return true;
    } catch (_) {
      return false;
    }
  }

  Future<void> _save({required bool generate}) async {
    final base = _nameController.text.trim();
    if (base.isEmpty) {
      _message('Enter a product name first.');
      return;
    }
    if (_items.isEmpty) {
      _message('Add at least one product image.');
      return;
    }
    if (generate && _platforms.isEmpty) {
      _message('Choose at least one platform to generate captions.');
      return;
    }
    setState(() => _saving = true);
    var saved = 0;
    var queueFailures = 0;
    final total = _editing
        ? 1
        : groupForProducts(_items, oneProduct: _oneProduct).length;
    try {
      final appDirectory = await getApplicationDocumentsDirectory();
      final imageDirectory = Directory(
          '${appDirectory.path}${Platform.pathSeparator}product_images');
      await imageDirectory.create(recursive: true);
      final groups = _editing
          ? [List<_ImageItem>.of(_items)]
          : groupForProducts(_items, oneProduct: _oneProduct);
      for (var g = 0; g < groups.length; g++) {
        final queued = await _saveGroup(
          groups[g], productNameFor(base, g, groups.length), g, imageDirectory,
          createOperations: generate || _editing);
        if (!queued) queueFailures++;
        saved++;
        // Saved images leave the list so a retry only repeats what failed.
        if (!_editing && mounted) {
          setState(() => _items.removeWhere(groups[g].contains));
        }
      }
      ref.invalidate(processingJobsProvider);
      ref.invalidate(productsProvider);
      if (!mounted) return;
      if (_editing) {
        _message('Product updated successfully.');
        Navigator.of(context).pop();
        return;
      }
      setState(() {
        _nameController.clear();
        _descriptionController.clear();
        _specialInstructionsController.clear();
        _items.clear();
        _category = ContentCategory.outfit;
        _platforms
          ..clear()
          ..add(SocialPlatform.instagram);
        _oneProduct = true;
      });
      _message(!generate
          ? (total > 1 ? '$total draft products saved on this device.' : 'Draft saved on this device.')
          : (queueFailures > 0
              ? '$saved products saved; $queueFailures operation queue(s) could not be created.'
              : 'Saved locally. Waiting for AI connection.'));
    } catch (_) {
      ref.invalidate(productsProvider);
      ref.invalidate(processingJobsProvider);
      _message(saved > 0
          ? 'Saved $saved of $total products. The rest failed; try again.'
          : 'Could not save this product. Please try again.');
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  InputDecoration _decoration(String label, {String? hint, String? helper}) {
    final c = context.colors;
    OutlineInputBorder border(Color color, [double width = 1]) => OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: color, width: width),
        );
    return InputDecoration(
      labelText: label,
      hintText: hint,
      helperText: helper,
      helperMaxLines: 2,
      alignLabelWithHint: true,
      filled: true,
      fillColor: c.background,
      border: border(c.border),
      enabledBorder: border(c.border),
      focusedBorder: border(c.selected, 1.5),
    );
  }

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    return ScreenScaffold(
      title: _editing ? 'Edit Product' : 'Upload',
      children: [
        ImageStrip(
          items: [for (final i in _items) ImageStripItem(id: i.uid, path: i.path)],
          onAdd: _pickImages,
          onRemove: (index) => setState(() => _items.removeAt(index)),
          onReorder: _reorder,
        ),
        if (_showMode) ...[
          const SizedBox(height: AppSpacing.md),
          AppSegmented<bool>(
            options: const [(true, 'One product'), (false, 'Separate products')],
            value: _oneProduct,
            onChanged: (v) => setState(() => _oneProduct = v),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(4, 8, 4, 0),
            child: Text(
              _oneProduct
                  ? '1 product with ${_items.length} images'
                  : '${_items.length} separate products, numbered from the name below',
              style: AppText.caption.copyWith(color: c.textSecondary),
            ),
          ),
        ],
        const SizedBox(height: AppSpacing.lg),
        CategoryPicker(
          value: _category,
          onChanged: (v) => setState(() => _category = v),
        ),
        const SizedBox(height: AppSpacing.lg),
        PlatformPicker(
          selected: _platforms,
          onToggle: _togglePlatform,
          onLongPress: (p) => showPlatformSettingsSheet(context, p, _category),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(4, 8, 4, AppSpacing.lg),
          child: Text(
            'Tap to select. Long press for templates.',
            textAlign: TextAlign.center,
            style: AppText.caption.copyWith(color: c.textSecondary),
          ),
        ),
        AppCard(
          child: Column(
            children: [
              TextField(
                controller: _nameController,
                textCapitalization: TextCapitalization.words,
                decoration: _decoration('Product name'),
              ),
              const SizedBox(height: AppSpacing.md),
              TextField(
                controller: _descriptionController,
                minLines: 2,
                maxLines: 4,
                decoration: _decoration('Details (optional)',
                    hint: 'Anything you know about this product'),
              ),
              const SizedBox(height: AppSpacing.md),
              TextField(
                controller: _specialInstructionsController,
                minLines: 2,
                maxLines: 5,
                textCapitalization: TextCapitalization.sentences,
                decoration: _decoration(
                  'Special Instructions (optional)',
                  hint: 'What to focus on or how it should sound',
                  helper: 'Saved with this product and used when AI is connected.',
                ),
              ),
            ],
          ),
        ),
        if (_editing)
          SizedBox(
            height: 52,
            child: FilledButton(
              style: FilledButton.styleFrom(backgroundColor: c.selected, foregroundColor: c.onSelected, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
              onPressed: _saving ? null : () => _save(generate: false),
              child: _saving ? const CircularProgressIndicator() : const Text('Save Changes'),
            ),
          )
        else ...[
          SizedBox(
            height: 52,
            child: FilledButton(
              style: FilledButton.styleFrom(backgroundColor: c.selected, foregroundColor: c.onSelected, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
              onPressed: _saving ? null : () => _save(generate: true),
              child: _saving ? const CircularProgressIndicator() : const Text('Generate Captions'),
            ),
          ),
          const SizedBox(height: 10),
          SizedBox(
            height: 48,
            child: OutlinedButton(
              onPressed: _saving ? null : () => _save(generate: false),
              child: const Text('Save Draft'),
            ),
          ),
        ],
        Padding(
          padding: const EdgeInsets.fromLTRB(4, 8, 4, AppSpacing.lg),
          child: Text(
            'Generate Captions saves the product and creates one waiting task per selected platform. Save Draft stores it without creating tasks.',
            textAlign: TextAlign.center,
            style: AppText.caption.copyWith(color: c.textSecondary),
          ),
        ),
      ],
    );
  }
}

