import 'package:material_ui/material_ui.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../domain/analytics.dart';
import '../data/caption_template.dart';
import '../data/template_repository.dart';

class TemplatesScreen extends ConsumerStatefulWidget {
  const TemplatesScreen({super.key});
  @override
  ConsumerState<TemplatesScreen> createState() => _TemplatesScreenState();
}
class _TemplatesScreenState extends ConsumerState<TemplatesScreen> {
  SocialPlatform _platform = SocialPlatform.pinterest;
  ContentCategory _category = ContentCategory.outfit;
  CaptionContentType _contentType = CaptionContentType.image;
  bool _loading = true;
  List<CaptionTemplate> _items = [];
  @override
  void initState() { super.initState(); _load(); }
  Future<void> _load() async { final items = await ref.read(templateRepositoryProvider).getAll(); if (mounted) setState(() { _items = items; _loading = false; }); }
  Future<void> _edit([CaptionTemplate? item]) async {
    final name = TextEditingController(text: item?.name ?? '');
    final instructions = TextEditingController(text: item?.instructions ?? defaultTemplateInstructions(_platform, _category, _contentType));
    var platform = item?.platform ?? _platform;
    var category = item?.category ?? _category;
    var contentType = item?.contentType ?? _contentType;
    final result = await showDialog<CaptionTemplate>(context: context, builder: (dialogContext) => StatefulBuilder(builder: (context, setDialog) => AlertDialog(
      title: Text(item == null ? 'New template' : 'Edit template'),
      content: SizedBox(width: 440, child: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: name, decoration: const InputDecoration(labelText: 'Template name')),
        const SizedBox(height: 12),
        DropdownButtonFormField<SocialPlatform>(initialValue: platform, decoration: const InputDecoration(labelText: 'Platform'), items: SocialPlatform.values.map((e) => DropdownMenuItem(value: e, child: Text(e.label))).toList(), onChanged: (v) { if (v != null) setDialog(() { platform = v; if (item == null) instructions.text = defaultTemplateInstructions(v, category, contentType); }); }),
        const SizedBox(height: 12),
        DropdownButtonFormField<ContentCategory>(initialValue: category, decoration: const InputDecoration(labelText: 'Content category'), items: ContentCategory.values.map((e) => DropdownMenuItem(value: e, child: Text(e.label))).toList(), onChanged: (v) { if (v != null) setDialog(() { category = v; if (item == null) instructions.text = defaultTemplateInstructions(platform, v, contentType); }); }),
        const SizedBox(height: 12),
        DropdownButtonFormField<CaptionContentType>(initialValue: contentType, decoration: const InputDecoration(labelText: 'Content type'), items: CaptionContentType.values.map((e) => DropdownMenuItem(value: e, child: Text(e.name.toUpperCase()))).toList(), onChanged: (v) { if (v != null) setDialog(() { contentType = v; if (item == null) instructions.text = defaultTemplateInstructions(platform, category, v); }); }),
        const SizedBox(height: 12),
        TextField(controller: instructions, minLines: 6, maxLines: 12, decoration: const InputDecoration(labelText: 'Writing instructions', alignLabelWithHint: true, border: OutlineInputBorder())),
      ]))),
      actions: [
        TextButton(onPressed: () => showDialog<void>(context: dialogContext, builder: (previewContext) => AlertDialog(title: const Text('Template preview'), content: SingleChildScrollView(child: Text(instructions.text)), actions: [TextButton(onPressed: () => Navigator.pop(previewContext), child: const Text('Close'))])), child: const Text('Preview')),
        TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Cancel')),
        FilledButton(onPressed: () { if (name.text.trim().isEmpty || instructions.text.trim().isEmpty) return; final copyDefault = item?.isDefault ?? false; Navigator.pop(dialogContext, CaptionTemplate(id: item == null || copyDefault ? DateTime.now().microsecondsSinceEpoch.toString() : item.id, name: name.text.trim(), platform: platform, category: category, contentType: contentType, instructions: instructions.text.trim(), isDefault: false)); }, child: const Text('Save as Template'))
      ],
    )));
    name.dispose(); instructions.dispose();
    if (result != null) { await ref.read(templateRepositoryProvider).save(result); await _load(); }
  }
  @override
  Widget build(BuildContext context) {
    final visible = _items.where((e) => e.platform == _platform && e.category == _category && e.contentType == _contentType).toList();
    return Scaffold(appBar: AppBar(title: const Text('Templates'), actions: [IconButton(onPressed: () => _edit(), icon: const Icon(Icons.add), tooltip: 'Add template')]),
      body: _loading ? const Center(child: CircularProgressIndicator()) : ListView(padding: const EdgeInsets.all(16), children: [
        const Text('Platform'), const SizedBox(height: 8), Wrap(spacing: 8, children: [for (final p in SocialPlatform.values) ChoiceChip(label: Text(p.label), selected: _platform == p, onSelected: (_) => setState(() => _platform = p))]),
        const SizedBox(height: 18), const Text('Content category'), const SizedBox(height: 8), Wrap(spacing: 8, children: [for (final c in ContentCategory.values) ChoiceChip(label: Text(c.label), selected: _category == c, onSelected: (_) => setState(() => _category = c))]),
        const SizedBox(height: 18), const Text('Content type'), const SizedBox(height: 8),
        Wrap(spacing: 8, children: [for (final type in CaptionContentType.values) ChoiceChip(label: Text(type.name.toUpperCase()), selected: _contentType == type, onSelected: (_) => setState(() => _contentType = type))]),
        const SizedBox(height: 18),
        for (final item in visible) Card(child: ListTile(title: Text(item.name), subtitle: Text(item.instructions, maxLines: 3, overflow: TextOverflow.ellipsis), isThreeLine: true, trailing: PopupMenuButton<String>(onSelected: (v) async { if (v == 'edit') { await _edit(item); } else if (v == 'delete' && !item.isDefault) { await ref.read(templateRepositoryProvider).delete(item.id); await _load(); } }, itemBuilder: (_) => [const PopupMenuItem(value: 'edit', child: Text('Edit')), if (!item.isDefault) const PopupMenuItem(value: 'delete', child: Text('Delete'))]))),
        if (visible.isEmpty) const Padding(padding: EdgeInsets.all(24), child: Text('No templates yet. Add one to get started.')),
      ]));
  }
}
