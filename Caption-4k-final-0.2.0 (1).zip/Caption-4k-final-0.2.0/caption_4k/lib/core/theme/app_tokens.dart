import 'package:material_ui/material_ui.dart';

class AppSpacing {
  const AppSpacing._();
  static const double xs = 4;
  static const double sm = 8;
  static const double md = 12;
  static const double lg = 16;
  static const double xl = 20;
  static const double xxl = 24;
}

class AppRadius {
  const AppRadius._();
  static const double card = 24;
  static const double chip = 14;
  static const double navTop = 28;
}

class AppSizes {
  const AppSizes._();
  static const double icon = 24;
  static const double iconLarge = 28;
  static const double navLabel = 12;
}

class AppText {
  const AppText._();
  static const TextStyle screenTitle = TextStyle(
    fontSize: 32,
    fontWeight: FontWeight.w700,
    letterSpacing: -0.5,
  );
  static const TextStyle sectionTitle = TextStyle(
    fontSize: 22,
    fontWeight: FontWeight.w700,
  );
  static const TextStyle statValue = TextStyle(
    fontSize: 34,
    fontWeight: FontWeight.w700,
  );
  static const TextStyle body = TextStyle(fontSize: 15);
  static const TextStyle caption = TextStyle(fontSize: 13);
}
