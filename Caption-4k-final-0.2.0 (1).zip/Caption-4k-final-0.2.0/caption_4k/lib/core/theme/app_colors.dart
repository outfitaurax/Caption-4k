import 'package:material_ui/material_ui.dart';

/// Colour tokens taken from the approved HTML design reference.
@immutable
class AppColors extends ThemeExtension<AppColors> {
  const AppColors({
    required this.background,
    required this.card,
    required this.text,
    required this.textSecondary,
    required this.border,
    required this.selected,
    required this.onSelected,
    required this.success,
    required this.muted,
    required this.pill,
  });

  final Color background;
  final Color card;
  final Color text;
  final Color textSecondary;
  final Color border;
  final Color selected;
  final Color onSelected;
  final Color success;
  final Color muted;
  final Color pill;

  static const light = AppColors(
    background: Color(0xFFF8F8FC),
    card: Color(0xFFFFFFFF),
    text: Color(0xFF0B0D1A),
    textSecondary: Color(0xFF6B6D80),
    border: Color(0xFFEBEBF4),
    selected: Color(0xFF14172B),
    onSelected: Color(0xFFFFFFFF),
    success: Color(0xFF1F9D55),
    muted: Color(0xFFE6E6F1),
    pill: Color(0xFFE8E5FB),
  );

  static const dark = AppColors(
    background: Color(0xFF121214),
    card: Color(0xFF1C1C20),
    text: Color(0xFFF5F5F7),
    textSecondary: Color(0xFF8E8E98),
    border: Color(0xFF2A2A30),
    selected: Color(0xFFF5F5F7),
    onSelected: Color(0xFF121214),
    success: Color(0xFF4FAE73),
    muted: Color(0xFF33333A),
    pill: Color(0xFF33333A),
  );

  @override
  AppColors copyWith({
    Color? background,
    Color? card,
    Color? text,
    Color? textSecondary,
    Color? border,
    Color? selected,
    Color? onSelected,
    Color? success,
    Color? muted,
    Color? pill,
  }) {
    return AppColors(
      background: background ?? this.background,
      card: card ?? this.card,
      text: text ?? this.text,
      textSecondary: textSecondary ?? this.textSecondary,
      border: border ?? this.border,
      selected: selected ?? this.selected,
      onSelected: onSelected ?? this.onSelected,
      success: success ?? this.success,
      muted: muted ?? this.muted,
      pill: pill ?? this.pill,
    );
  }

  @override
  AppColors lerp(ThemeExtension<AppColors>? other, double t) {
    if (other is! AppColors) return this;
    return AppColors(
      background: Color.lerp(background, other.background, t)!,
      card: Color.lerp(card, other.card, t)!,
      text: Color.lerp(text, other.text, t)!,
      textSecondary: Color.lerp(textSecondary, other.textSecondary, t)!,
      border: Color.lerp(border, other.border, t)!,
      selected: Color.lerp(selected, other.selected, t)!,
      onSelected: Color.lerp(onSelected, other.onSelected, t)!,
      success: Color.lerp(success, other.success, t)!,
      muted: Color.lerp(muted, other.muted, t)!,
      pill: Color.lerp(pill, other.pill, t)!,
    );
  }
}

extension AppColorsContext on BuildContext {
  AppColors get colors => Theme.of(this).extension<AppColors>()!;
}
