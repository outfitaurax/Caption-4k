import 'package:material_ui/material_ui.dart';

import 'app_colors.dart';

class AppTheme {
  const AppTheme._();

  static ThemeData light() => _build(Brightness.light, AppColors.light);
  static ThemeData dark() => _build(Brightness.dark, AppColors.dark);

  static ThemeData _build(Brightness brightness, AppColors c) {
    final base = ThemeData(brightness: brightness, useMaterial3: true);
    return base.copyWith(
      scaffoldBackgroundColor: c.background,
      colorScheme: ColorScheme.fromSeed(
        seedColor: c.selected,
        brightness: brightness,
      ).copyWith(
        primary: c.selected,
        onPrimary: c.onSelected,
        surface: c.card,
        onSurface: c.text,
        outline: c.border,
      ),
      textTheme: base.textTheme.apply(bodyColor: c.text, displayColor: c.text),
      dividerColor: c.border,
      splashFactory: NoSplash.splashFactory,
      highlightColor: Colors.transparent,
      extensions: <ThemeExtension<dynamic>>[c],
    );
  }
}
