import 'dart:io';

import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../navigation/app_navigator.dart';

/// Device-local notifications for completed or failed local processing jobs.
/// Remote/push notifications are intentionally outside this app-only stage.
class LocalNotificationService {
  LocalNotificationService({FlutterLocalNotificationsPlugin? plugin})
      : _plugin = plugin ?? FlutterLocalNotificationsPlugin();

  final FlutterLocalNotificationsPlugin _plugin;
  bool _initialized = false;
  String? _initialPayload;

  static const _channel = AndroidNotificationChannel(
    'caption4k_operations',
    'Caption 4K operations',
    description: 'Updates when a local Caption 4K operation finishes.',
    importance: Importance.defaultImportance,
  );

  Future<void> initialize() async {
    if (_initialized) return;
    const settings = InitializationSettings(
      android: AndroidInitializationSettings('@mipmap/ic_launcher'),
      iOS: DarwinInitializationSettings(),
    );
    final launchDetails = await _plugin.getNotificationAppLaunchDetails();
    if (launchDetails?.didNotificationLaunchApp == true) {
      _initialPayload = launchDetails?.notificationResponse?.payload;
    }
    await _plugin.initialize(
      settings,
      onDidReceiveNotificationResponse: (response) {
        final jobId = response.payload;
        if (jobId == null || jobId.isEmpty) return;
        appNavigatorKey.currentState?.pushNamed('/operation', arguments: jobId);
      },
    );
    final android = _plugin.resolvePlatformSpecificImplementation<
        AndroidFlutterLocalNotificationsPlugin>();
    await android?.createNotificationChannel(_channel);
    _initialized = true;
  }

  String? takeInitialPayload() {
    final payload = _initialPayload;
    _initialPayload = null;
    return payload;
  }

  Future<bool> requestPermission() async {
    if (Platform.isAndroid) {
      final android = _plugin.resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>();
      return await android?.requestNotificationsPermission() ?? false;
    }
    if (Platform.isIOS) {
      final ios = _plugin.resolvePlatformSpecificImplementation<
          IOSFlutterLocalNotificationsPlugin>();
      return await ios?.requestPermissions(
            alert: true, badge: true, sound: true) ?? false;
    }
    // Desktop/other platforms do not expose the mobile permission request.
    return false;
  }

  Future<void> showJobCompleted({
    required String jobId,
    required String productName,
    required String platform,
  }) async {
    await _show(
      id: jobId.hashCode & 0x7fffffff,
      title: 'Caption ready',
      body: '$productName · $platform',
      payload: jobId,
    );
  }

  Future<void> showJobFailed({
    required String jobId,
    required String productName,
    required String platform,
  }) async {
    await _show(
      id: jobId.hashCode & 0x7fffffff,
      title: 'Caption operation failed',
      body: '$productName · $platform',
      payload: jobId,
    );
  }

  Future<void> _show({
    required int id,
    required String title,
    required String body,
    required String payload,
  }) async {
    if (!_initialized) return;
    const details = NotificationDetails(
      android: AndroidNotificationDetails(
        'caption4k_operations',
        'Caption 4K operations',
        channelDescription: 'Updates when a local Caption 4K operation finishes.',
        importance: Importance.defaultImportance,
        priority: Priority.defaultPriority,
        icon: '@mipmap/ic_launcher',
      ),
      iOS: DarwinNotificationDetails(),
    );
    try {
      await _plugin.show(id, title, body, details, payload: payload);
    } catch (_) {
      // Notification failures must never break saving a result or job state.
    }
  }
}

final localNotificationServiceProvider = Provider<LocalNotificationService>(
  (ref) => LocalNotificationService(),
);
