import 'dart:io';
import 'dart:ui' show DartPluginRegistrant;

import 'package:material_ui/material_ui.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:workmanager/workmanager.dart';

import 'app/app.dart';
import 'core/storage/preferences.dart';
import 'features/upload/data/product_repository.dart';
import 'features/ai/data/ai_chat_repository.dart';
import 'core/notifications/local_notification_service.dart';
import 'core/navigation/app_navigator.dart';

const _retentionCleanupTask = 'caption4kRetentionCleanup';

@pragma('vm:entry-point')
void caption4kBackgroundDispatcher() {
  Workmanager().executeTask((task, inputData) async {
    if (task != _retentionCleanupTask) return true;
    try {
      DartPluginRegistrant.ensureInitialized();
      WidgetsFlutterBinding.ensureInitialized();
      final prefs = await SharedPreferences.getInstance();
      final container = ProviderContainer(overrides: [
        sharedPreferencesProvider.overrideWithValue(prefs),
      ]);
      try {
        final repository = container.read(productRepositoryProvider);
        await repository.expireOldImages();
        await repository.expireOldRecords();
        await container.read(aiChatRepositoryProvider).expireOldConversations();
      } finally {
        container.dispose();
      }
      return true;
    } catch (_) {
      return false;
    }
  });
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final prefs = await SharedPreferences.getInstance();
  if (Platform.isAndroid) {
    try {
      await Workmanager().initialize(caption4kBackgroundDispatcher);
      await Workmanager().registerPeriodicTask(
        'caption4k-retention-cleanup',
        _retentionCleanupTask,
        frequency: const Duration(hours: 24),
      );
    } catch (_) {
      // Startup/resume cleanup remains available if background scheduling fails.
    }
  }
  final notifications = LocalNotificationService();
  try {
    await notifications.initialize();
  } catch (_) {
    // The app remains usable if notification permission or platform setup fails.
  }
  final container = ProviderContainer(
    overrides: [
      sharedPreferencesProvider.overrideWithValue(prefs),
      localNotificationServiceProvider.overrideWithValue(notifications),
    ],
  );
  // Run both retention sweeps at startup; WorkManager repeats them daily
  // in the background on Android when the operating system permits.
  try {
    final repository = container.read(productRepositoryProvider);
    await repository.expireOldImages();
    await repository.expireOldRecords();
    await container.read(aiChatRepositoryProvider).expireOldConversations();
  } catch (_) {
    // Cleanup is best-effort and must never prevent the app from opening.
  }
  runApp(
    UncontrolledProviderScope(
      container: container,
      child: const CaptionApp(),
    ),
  );
  WidgetsBinding.instance.addPostFrameCallback((_) {
    final jobId = notifications.takeInitialPayload();
    if (jobId != null && jobId.isNotEmpty) {
      appNavigatorKey.currentState?.pushNamed('/operation', arguments: jobId);
    }
  });
}
