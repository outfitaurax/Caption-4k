package com.caption4k.caption_4k

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
